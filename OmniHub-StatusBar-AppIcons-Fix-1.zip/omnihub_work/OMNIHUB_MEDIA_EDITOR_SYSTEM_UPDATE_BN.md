# OmniHub — Media, Editor ও System Hub Update

## এই আপডেটে
- Home dashboard-এ তিনটি নতুন swipeable section: **Media**, **Editor**, **System** যোগ করা হয়েছে। দৃশ্যমান UI-তে “Stage” শব্দ নেই।
- নতুন swipe order: **Local → Library → Network → Utilities → Privacy → Media → Editor → System**। ট্যাপ ও horizontal swipe—দুইভাবেই section বদলানো যায়।
- Page indicator ৫ থেকে ৮টি করা হয়েছে; আগের active section local storage-এ সংরক্ষিত থাকার আচরণ বজায় আছে।
- Media section-এ Media Lab, Photo Library, Video Library, Audio Library এবং compatibility note/shortcuts যোগ করা হয়েছে। বিদ্যমান Media Lab-এর thumbnail previews ও full-library actions ব্যবহার করা হয়।
- Editor section-এ New Document, Open in Editor, Notepad এবং JSON Tools-এর দ্রুত প্রবেশপথ যোগ করা হয়েছে। বিদ্যমান Code Studio-র autosave, text/code editing, JSON formatting/validation, HTML runner এবং save/export ব্যবহৃত হয়।
- System section-এ System Hub, Recycle Bin, Shizuku Access, App Manager, Permissions এবং Global Search-এর দ্রুত প্রবেশপথ যোগ করা হয়েছে। সুরক্ষিত Android action-এ প্রয়োজনীয় permission/authorization আগের মতোই প্রয়োজন।
- Media Lab-এর বর্ণনা ও all-media shortcuts উন্নত করা হয়েছে। `prefers-reduced-motion` চালু থাকলে animation/transition কমানোর CSS যোগ করা হয়েছে।

## যাচাই
- Inline JavaScript: `node --check` — PASS
- Dashboard tab/pane order ও 8 page indicator — PASS
- UI-তে “Stage” label নেই — PASS
- `app/src/main`-এর XML ফাইল parse — PASS
- ZIP integrity — PASS (প্যাকেজ করার পরে যাচাই)

## Build সীমাবদ্ধতা
`./gradlew assembleDebug --no-daemon` চালানো হয়েছে, কিন্তু Gradle wrapper `services.gradle.org`-এ DNS `UnknownHostException`-এর কারণে Gradle 9.0.0 ডাউনলোড করতে পারেনি। ফলে এখানে Android APK build বা device runtime test নিশ্চিত করা যায়নি। AndroidIDE-তে প্রজেক্ট import করে build ও device test করতে হবে।
