package com.example.omnihub

import android.content.Context
import java.io.File

/**
 * Most-recently-used folders: folders the user opened ("visited") and folders where something was
 * changed (paste, move, delete, extract, compress, rename, new folder...). Stored in SharedPreferences.
 */
object RecentFolders {
    data class Entry(val path: String, val changed: Boolean, val time: Long)

    private const val PREFS = "omnihub_recent_folders"
    private const val KEY = "list_v1"
    private const val MAX = 40

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun list(ctx: Context): List<Entry> {
        val raw = try { prefs(ctx).getString(KEY, "") ?: "" } catch (_: Throwable) { "" }
        return raw.lineSequence().mapNotNull { line ->
            val p = line.split('\t')
            if (p.size < 3 || p[0].isBlank()) null else Entry(p[0], p[1] == "1", p[2].toLongOrNull() ?: 0L)
        }.toList()
    }

    private fun save(ctx: Context, items: List<Entry>) {
        try { prefs(ctx).edit().putString(KEY, items.take(MAX).joinToString("\n") { it.path + "\t" + (if (it.changed) "1" else "0") + "\t" + it.time }).apply() } catch (_: Throwable) { }
    }

    @Synchronized private fun touch(ctx: Context, dir: File, changed: Boolean) {
        val path = dir.absolutePath
        if (path.isBlank()) return
        val old = list(ctx)
        val keepChanged = changed || (old.firstOrNull { it.path == path }?.changed ?: false)
        save(ctx, listOf(Entry(path, keepChanged, System.currentTimeMillis())) + old.filter { it.path != path })
    }

    fun visit(ctx: Context, dir: File) = touch(ctx, dir, false)

    /** Marks the folder as "something changed here" and moves it to the top. */
    fun changed(ctx: Context, dir: File?) { if (dir != null) touch(ctx, dir, true) }

    @Synchronized fun remove(ctx: Context, path: String) = save(ctx, list(ctx).filter { it.path != path })

    @Synchronized fun clear(ctx: Context) { try { prefs(ctx).edit().remove(KEY).apply() } catch (_: Throwable) { } }
}
