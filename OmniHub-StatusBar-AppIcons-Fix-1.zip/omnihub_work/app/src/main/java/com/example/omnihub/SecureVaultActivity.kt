package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Private file vault. File payloads are AES-GCM encrypted in app-private storage. */
class SecureVaultActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("omnihub_secure_vault", MODE_PRIVATE) }
    private val vaultDir by lazy { File(filesDir, "secure_vault").apply { mkdirs() } }
    private var pin: CharArray? = null
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var pendingRestoreId: String? = null
    private val bg = Color.rgb(242, 240, 247)
    private val ink = Color.rgb(30, 36, 48)
    private val muted = Color.rgb(106, 116, 132)
    private val accent = Color.rgb(102, 80, 196)
    private val maxBytes = 64 * 1024 * 1024

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = Color.rgb(252, 251, 254)
        if (android.os.Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        authenticateOrCreate()
    }

    override fun onDestroy() { pin?.fill('\u0000'); pin = null; super.onDestroy() }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(12)); setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(button("‹") { finish() }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(8) })
        header.addView(TextView(this).apply { text = "Secure Vault"; textSize = 23f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(header)
        root.addView(TextView(this).apply { text = "Your files are encrypted on this device. The PIN is never sent anywhere."; textSize = 13f; setTextColor(muted); setPadding(0, dp(6), 0, dp(12)) })
        root.addView(button("＋  Add files to vault") { openPicker() }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        status = TextView(this).apply { textSize = 12f; setTextColor(muted); setPadding(dp(2), dp(4), dp(2), dp(8)) }
        root.addView(status)
        val scroller = ScrollView(this).apply { isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(list)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply { text = "Restore creates a decrypted copy at the location you choose. Keep your PIN safe; forgotten PINs cannot be recovered."; textSize = 11f; setTextColor(muted); setPadding(2, dp(10), 2, 0) })
        setContentView(root); InsetsUtil.apply(this, root)
    }

    private fun authenticateOrCreate() {
        val existing = prefs.getString("pin_salt", null)
        val title = if (existing == null) "Create vault PIN" else "Unlock vault"
        val input = EditText(this).apply { hint = if (existing == null) "Create a 6–12 digit PIN" else "Enter vault PIN"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; setSingleLine(true) }
        val dlg = AlertDialog.Builder(this).setTitle(title).setMessage(if (existing == null) "Use a PIN you can remember. Vault files cannot be recovered if you forget it." else "Enter your PIN to decrypt your private files.").setView(input).setCancelable(false)
            .setNegativeButton("Exit") { _, _ -> finish() }
            .setPositiveButton(if (existing == null) "Create" else "Unlock", null).create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = input.text.toString()
                if (value.length !in 6..12 || !value.all { it.isDigit() }) { input.error = "Use 6–12 digits"; return@setOnClickListener }
                if (existing == null) {
                    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                    prefs.edit().putString("pin_salt", hex(salt)).putString("pin_check", hex(derive(value.toCharArray(), salt))).apply()
                    pin = value.toCharArray(); dlg.dismiss(); renderFiles()
                } else {
                    val salt = unhex(existing)
                    val expected = unhex(prefs.getString("pin_check", "") ?: "")
                    val actual = derive(value.toCharArray(), salt)
                    if (expected.isNotEmpty() && MessageDigest.isEqual(expected, actual)) { pin = value.toCharArray(); dlg.dismiss(); renderFiles() }
                    else { input.error = "Incorrect PIN"; input.text?.clear() }
                }
            }
        }
        dlg.show()
    }

    private fun openPicker() {
        if (pin == null) { authenticateOrCreate(); return }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true) }
        try { startActivityForResult(i, 501) } catch (_: Exception) { toast("No file picker is available") }
    }

    @Deprecated("Legacy result API retained for Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == 501) {
            val uris = mutableListOf<Uri>()
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
            if (uris.isEmpty()) data.data?.let { uris.add(it) }
            var added = 0
            uris.forEach { uri -> try { encryptUri(uri); added++ } catch (e: Exception) { toast("Could not encrypt a file: ${e.localizedMessage ?: "read error"}") } }
            if (added > 0) toast("Added $added encrypted file(s)")
            renderFiles()
        } else if (requestCode == 502) {
            val id = pendingRestoreId; pendingRestoreId = null
            val uri = data.data
            if (id != null && uri != null) try {
                val bytes = decryptFile(File(vaultDir, "$id.vlt"))
                contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: throw IllegalStateException("Destination cannot be written")
                toast("File restored")
            } catch (e: Exception) { toast("Restore failed: ${e.localizedMessage ?: "decryption error"}") }
        }
    }

    private fun encryptUri(uri: Uri) {
        val keyPin = pin ?: throw IllegalStateException("Vault locked")
        val name = queryName(uri) ?: "private-file"
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot read file")
        val bytes = input.use { readLimited(it, maxBytes) }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(derive(keyPin, salt), "AES"), GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(bytes)
        val id = java.util.UUID.randomUUID().toString()
        File(vaultDir, "$id.vlt").outputStream().use { out -> out.write(salt); out.write(iv); out.write(encrypted) }
        prefs.edit().putString("name_$id", name).apply()
    }

    private fun decryptFile(file: File): ByteArray {
        val keyPin = pin ?: throw IllegalStateException("Vault locked")
        val all = file.readBytes()
        if (all.size < 16 + 12 + 16) throw IllegalStateException("Encrypted file is damaged")
        val salt = all.copyOfRange(0, 16); val iv = all.copyOfRange(16, 28); val payload = all.copyOfRange(28, all.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(derive(keyPin, salt), "AES"), GCMParameterSpec(128, iv))
        return cipher.doFinal(payload)
    }

    private fun renderFiles() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val files = vaultDir.listFiles()?.filter { it.isFile && it.extension == "vlt" }?.sortedByDescending { it.lastModified() }.orEmpty()
        status.text = "${files.size} encrypted file(s) · Stored privately on this device"
        if (files.isEmpty()) {
            list.addView(TextView(this).apply { text = "Your vault is empty\nTap “Add files to vault” to encrypt files."; gravity = Gravity.CENTER; textSize = 14f; setTextColor(muted); setPadding(dp(18), dp(42), dp(18), dp(42)) })
        }
        files.forEach { file ->
            val id = file.name.removeSuffix(".vlt")
            val name = prefs.getString("name_$id", "Private file") ?: "Private file"
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12)); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(252, 251, 254)); cornerRadius = dp(15).toFloat(); setStroke(dp(1), Color.rgb(226, 230, 238)) } }
            card.addView(TextView(this).apply { text = "▣  $name"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
            card.addView(TextView(this).apply { text = "Encrypted · ${formatBytes(file.length())}"; textSize = 11f; setTextColor(muted); setPadding(0, dp(4), 0, dp(9)) })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(button("Preview") { previewFile(id, name) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(5) })
            actions.addView(button("Restore") { promptRestore(id, name) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(5) })
            actions.addView(button("Delete") { confirmDelete(id, name) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            card.addView(actions); list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
    }

    private fun previewFile(id: String, name: String) {
        val ext = name.substringAfterLast('.', "").lowercase()
        val textTypes = setOf("txt", "md", "csv", "json", "xml", "html", "htm", "css", "js", "log", "ini", "yaml", "yml", "kt", "java", "py", "sql")
        if (ext !in textTypes) {
            AlertDialog.Builder(this).setTitle(name).setMessage("This file type does not have an in-vault preview yet. Use Restore to save a decrypted copy to a location you choose, then open it with a compatible app.").setPositiveButton("OK", null).show()
            return
        }
        try {
            val bytes = decryptFile(File(vaultDir, "$id.vlt"))
            val preview = String(bytes, Charsets.UTF_8).take(32_000)
            val view = TextView(this).apply { text = preview; textSize = 12f; setTextColor(ink); setPadding(dp(12), dp(10), dp(12), dp(10)); setTextIsSelectable(true) }
            val scroll = ScrollView(this).apply { addView(view) }
            AlertDialog.Builder(this).setTitle(name).setView(scroll).setPositiveButton("Close", null).show()
        } catch (e: Exception) { toast("Could not preview this file: ${e.localizedMessage ?: "decryption error"}") }
    }

    private fun promptRestore(id: String, name: String) {
        val mime = contentMime(name)
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime; putExtra(Intent.EXTRA_TITLE, name) }
        pendingRestoreId = id
        try { startActivityForResult(intent, 502) } catch (_: Exception) { pendingRestoreId = null; toast("No save location picker is available") }
    }

    private fun confirmDelete(id: String, name: String) {
        AlertDialog.Builder(this).setTitle("Delete from vault?").setMessage("“$name” will be permanently removed from the encrypted vault.").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
            File(vaultDir, "$id.vlt").delete(); prefs.edit().remove("name_$id").apply(); renderFiles(); toast("Removed from vault")
        }.show()
    }

    private fun queryName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try { cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null); if (cursor != null && cursor.moveToFirst()) cursor.getString(0)?.take(180) else null } catch (_: Exception) { null } finally { cursor?.close() }
    }

    private fun readLimited(input: java.io.InputStream, max: Int): ByteArray {
        val out = ByteArrayOutputStream(); val buffer = ByteArray(8192); var total = 0
        while (true) { val n = input.read(buffer); if (n < 0) break; total += n; if (total > max) throw IllegalStateException("Files over 64 MB are not supported yet"); out.write(buffer, 0, n) }
        return out.toByteArray()
    }

    private fun derive(pin: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin, salt, 120_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }
    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String): ByteArray = try { if (s.length % 2 != 0) byteArrayOf() else s.chunked(2).map { it.toInt(16).toByte() }.toByteArray() } catch (_: Exception) { byteArrayOf() }
    private fun contentMime(name: String): String { val ext = name.substringAfterLast('.', "").lowercase(); return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream" }
    private fun formatBytes(size: Long): String { if (size < 1024) return "$size B"; val units = arrayOf("KB", "MB", "GB"); var v = size.toDouble() / 1024; var i = 0; while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }; return "%.1f %s".format(v, units[i]) }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; textSize = 12f; setTextColor(if (label.contains("Add files")) Color.WHITE else ink); backgroundTintList = android.content.res.ColorStateList.valueOf(if (label.contains("Add files")) accent else Color.WHITE); setOnClickListener { action() } }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
