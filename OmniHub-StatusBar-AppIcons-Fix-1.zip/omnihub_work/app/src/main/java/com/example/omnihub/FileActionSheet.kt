package com.example.omnihub

import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** Compact, accessible two-column action sheet for one or multiple selected filesystem entries. */
object FileActionSheet {
    private data class Item(val key: String, val icon: String, val title: Int, val label: String? = null, val singleOnly: Boolean = false, val archiveOnly: Boolean = false)


    private val iconRes = mapOf(
        "open" to Pair(R.drawable.ia_open, 0xFF5B6FD8.toInt()), "open_with" to Pair(R.drawable.ia_open_with, 0xFF7A7390.toInt()),
        "share" to Pair(R.drawable.ia_share, 0xFF3FA3C9.toInt()), "copy" to Pair(R.drawable.ia_copy, 0xFF9A6BC9.toInt()),
        "move" to Pair(R.drawable.ia_move, 0xFFE8A043.toInt()), "rename" to Pair(R.drawable.ia_rename, 0xFF2FA89A.toInt()),
        "delete" to Pair(R.drawable.ia_delete, 0xFFE5677A.toInt()), "delete_permanent" to Pair(R.drawable.ia_delete_forever, 0xFFC94458.toInt()),
        "details" to Pair(R.drawable.ia_info, 0xFF5B6FD8.toInt()), "copy_path" to Pair(R.drawable.ia_link, 0xFF7A7390.toInt()),
        "favorite" to Pair(R.drawable.ia_star, 0xFFE8A043.toInt()), "hide" to Pair(R.drawable.ia_hide, 0xFF7A7390.toInt()),
        "shortcut" to Pair(R.drawable.ia_shortcut, 0xFF58AD7F.toInt()), "compress" to Pair(R.drawable.ia_compress, 0xFFEE8A6B.toInt()),
        "extract" to Pair(R.drawable.ia_extract, 0xFF58AD7F.toInt()), "extract_named" to Pair(R.drawable.ia_extract, 0xFF58AD7F.toInt()),
        "extract_to" to Pair(R.drawable.ia_extract, 0xFF58AD7F.toInt()), "set_wallpaper" to Pair(R.drawable.ia_wallpaper, 0xFF9A6BC9.toInt()),
        "set_ringtone" to Pair(R.drawable.ia_ringtone, 0xFFE5677A.toInt())
    )

    fun show(context: Context, files: List<File>, onAction: (String) -> Unit) {
        if (files.isEmpty()) return
        val items = mutableListOf(
            Item("open", "↗", R.string.action_open, singleOnly = true),
            Item("open_with", "◉", R.string.action_open_with, singleOnly = true),
            Item("share", "↗", R.string.action_share),
            Item("copy", "▢", R.string.action_copy),
            Item("move", "⇢", R.string.action_move),
            Item("rename", "✎", R.string.action_rename, singleOnly = true),
            Item("delete", "⌫", R.string.action_delete),
            Item("delete_permanent", "×", R.string.action_permanent_delete),
            Item("details", "ⓘ", R.string.action_details, singleOnly = true),
            Item("copy_path", "⧉", R.string.action_copy_path, singleOnly = true),
            Item("favorite", "☆", R.string.action_favorite_add),
            Item("hide", "◌", R.string.action_hide, singleOnly = true),
            Item("shortcut", "⌁", R.string.action_shortcut, singleOnly = true),
            Item("compress", "▤", R.string.archive_compress),
        )
        if (files.size == 1 && ArchiveManager.isArchive(files.first())) items += Item("extract", "⇩", R.string.archive_extract, singleOnly = true, archiveOnly = true)
        if (files.size == 1 && SetAs.canSetWallpaper(files.first().name)) items += Item("set_wallpaper", "▣", R.string.action_set_wallpaper, singleOnly = true)
        if (files.size == 1 && SetAs.canSetRingtone(files.first().name)) items += Item("set_ringtone", "♪", R.string.action_set_ringtone, singleOnly = true)
        if (files.size == 1 && ArchiveManager.isArchive(files.first())) {
            val f = files.first()
            val folder = f.name.substringBeforeLast('.', f.name).removeSuffix(".tar")
            items += Item("extract_named", "⇩", R.string.archive_extract_named, label = "Extract to $folder/", singleOnly = true, archiveOnly = true)
        }
        if (files.size == 1 && ArchiveManager.isArchive(files.first())) items += Item("extract_to", "⇩", R.string.action_extract_to, singleOnly = true, archiveOnly = true)

        val dialog = Dialog(context)
        val surface = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 16), dp(context, 9), dp(context, 16), dp(context, 18))
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(dp(context, 24).toFloat(), dp(context, 24).toFloat(), dp(context, 24).toFloat(), dp(context, 24).toFloat(), 0f, 0f, 0f, 0f)
                setColor(Color.rgb(252, 251, 254))
                setStroke(dp(context, 1), Color.rgb(218, 213, 230))
            }
        }
        surface.addView(View(context).apply { background = rounded(Color.rgb(199, 203, 211), dp(context, 18)); contentDescription = context.getString(R.string.action_sheet_handle) }, LinearLayout.LayoutParams(dp(context, 42), dp(context, 4)).apply { gravity = Gravity.CENTER; bottomMargin = dp(context, 12) })
        surface.addView(TextView(context).apply {
            text = context.getString(R.string.action_selected_count, files.size)
            textSize = 16f; setTextColor(Color.rgb(37, 34, 47)); typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            contentDescription = text
            setPadding(dp(context, 2), 0, dp(context, 2), dp(context, 9))
        }, LinearLayout.LayoutParams(-1, dp(context, 38)))

        val scroll = ScrollView(context).apply { isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        var index = 0
        while (index < items.size) {
            val line = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            for (slot in 0..1) {
                if (index >= items.size) {
                    line.addView(View(context), LinearLayout.LayoutParams(0, dp(context, 58), 1f))
                } else {
                    val item = items[index++]
                    val label = item.label ?: context.getString(item.title)
                    val enabled = !item.singleOnly || files.size == 1
                    val cell = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        minimumHeight = dp(context, 58)
                        setPadding(dp(context, 10), dp(context, 8), dp(context, 7), dp(context, 8))
                        alpha = if (enabled) 1f else 0.48f
                        background = RippleDrawable(ColorStateList.valueOf(Color.argb(38, 102, 80, 196)), rounded(Color.rgb(242, 240, 247), dp(context, 14)), null)
                        contentDescription = label
                        isClickable = enabled
                        isFocusable = enabled
                        setOnClickListener { if (enabled) { dialog.dismiss(); onAction(item.key) } }
                    }
                    val meta = iconRes[item.key]
                    cell.addView(android.widget.ImageView(context).apply {
                        setImageResource(meta?.first ?: R.drawable.ia_info)
                        setColorFilter(Color.WHITE)
                        setPadding(dp(context, 7), dp(context, 7), dp(context, 7), dp(context, 7))
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(meta?.second ?: Color.rgb(102, 80, 196)) }
                        contentDescription = label
                    }, LinearLayout.LayoutParams(dp(context, 34), dp(context, 34)))
                    cell.addView(TextView(context).apply {
                        text = label; textSize = 12f; setTextColor(Color.rgb(37, 34, 47)); maxLines = 2
                        gravity = Gravity.CENTER_VERTICAL
                    }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(context, 5) })
                    line.addView(cell, LinearLayout.LayoutParams(0, dp(context, 58), 1f).apply {
                        leftMargin = if (slot == 0) 0 else dp(context, 5)
                        rightMargin = if (slot == 0) dp(context, 5) else 0
                        bottomMargin = dp(context, 7)
                    })
                }
            }
            column.addView(line, LinearLayout.LayoutParams(-1, -2))
        }
        scroll.addView(column)
        surface.addView(scroll, LinearLayout.LayoutParams(-1, -2).apply { weight = 1f })
        surface.addView(TextView(context).apply {
            text = context.getString(R.string.action_cancel)
            textSize = 14f; setTextColor(Color.rgb(102, 80, 196)); gravity = Gravity.CENTER
            minHeight = dp(context, 48); contentDescription = text; isClickable = true; isFocusable = true
            background = RippleDrawable(ColorStateList.valueOf(Color.argb(38, 102, 80, 196)), rounded(Color.TRANSPARENT, dp(context, 12)), null)
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(-1, dp(context, 48)).apply { topMargin = dp(context, 2) })
        dialog.setContentView(surface)
        dialog.window?.setWindowAnimations(R.style.OmniSheetAnim)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.let { window ->
            window.setBackgroundDrawableResource(android.R.color.transparent)
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            window.attributes = window.attributes.apply { gravity = Gravity.BOTTOM; dimAmount = .35f }
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dialog.show()
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.window?.attributes = dialog.window?.attributes?.apply { gravity = Gravity.BOTTOM; dimAmount = .35f }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply { cornerRadius = radius.toFloat(); setColor(color) }
    private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
}
