package com.example.omnihub

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player

/** Shared link between the players (which live in activities) and the background-playback service. */
object PlaybackHub {
    @Volatile var player: Player? = null
    @Volatile var title: () -> String = { "OmniHub" }
    @Volatile var openIntent: Intent? = null
    @Volatile var service: PlaybackService? = null
    private var askedNotifications = false

    /** Call when a player starts playing: keeps the app alive in the background and shows a notification. */
    fun attach(ctx: Context, p: Player, open: Intent, titleProvider: () -> String) {
        player = p
        title = titleProvider
        openIntent = open
        if (Build.VERSION.SDK_INT >= 33 && ctx is Activity && !askedNotifications &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askedNotifications = true
            try { ctx.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7301) } catch (_: Throwable) { }
        }
        val s = service
        if (s != null) s.refresh()
        else try {
            val app = ctx.applicationContext
            ContextCompat.startForegroundService(app, Intent(app, PlaybackService::class.java))
        } catch (_: Throwable) { }
    }

    fun detach(p: Player) {
        if (player === p) {
            player = null
            service?.shutdown()
        }
    }
}

/**
 * Foreground "media playback" service. It keeps the process (and therefore the player) alive while music or a
 * video's sound plays in the background. Swiping OmniHub away from Recents stops playback.
 */
class PlaybackService : Service() {
    private var listened: Player? = null
    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { refresh() }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { refresh() }
        override fun onPlaybackStateChanged(playbackState: Int) { refresh() }
    }

    override fun onCreate() {
        super.onCreate()
        PlaybackHub.service = this
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Background playback", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        PlaybackHub.service = this
        when (intent?.action) {
            ACTION_TOGGLE -> PlaybackHub.player?.let { p ->
                try {
                    if (p.isPlaying) p.pause() else {
                        if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
                        p.play()
                    }
                } catch (_: Throwable) { }
            }
            ACTION_STOP -> {
                try { PlaybackHub.player?.pause() } catch (_: Throwable) { }
                AudioKeeper.discard()
                shutdown()
                return START_NOT_STICKY
            }
        }
        // Must be called promptly after startForegroundService(), even if we stop right away.
        goForeground(buildNotification())
        if (PlaybackHub.player == null) { shutdown(); return START_NOT_STICKY }
        listen()
        return START_NOT_STICKY
    }

    /** Called when the user swipes the app out of Recents: stop everything. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        try { PlaybackHub.player?.pause() } catch (_: Throwable) { }
        AudioKeeper.discard()
        shutdown()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        unlisten()
        if (PlaybackHub.service === this) PlaybackHub.service = null
        super.onDestroy()
    }

    fun refresh() {
        if (PlaybackHub.player == null) { shutdown(); return }
        listen()
        try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification()) } catch (_: Throwable) { }
    }

    fun shutdown() {
        unlisten()
        if (PlaybackHub.service === this) PlaybackHub.service = null
        try { stopForeground(true) } catch (_: Throwable) { }
        stopSelf()
    }

    private fun listen() {
        val p = PlaybackHub.player
        if (p === listened) return
        unlisten()
        if (p != null) { try { p.addListener(listener); listened = p } catch (_: Throwable) { } }
    }

    private fun unlisten() {
        try { listened?.removeListener(listener) } catch (_: Throwable) { }
        listened = null
    }

    private fun goForeground(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, n)
        } catch (_: Throwable) { }
    }

    private fun pending(action: String, code: Int): PendingIntent =
        PendingIntent.getService(this, code, Intent(this, PlaybackService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun buildNotification(): Notification {
        val playing = try { PlaybackHub.player?.isPlaying == true } catch (_: Throwable) { false }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        val open = (PlaybackHub.openIntent ?: packageManager.getLaunchIntentForPackage(packageName) ?: Intent())
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        b.setSmallIcon(R.drawable.ic_music)
            .setContentTitle(try { PlaybackHub.title() } catch (_: Throwable) { "OmniHub" })
            .setContentText(if (playing) "Playing in background" else "Paused")
            .setContentIntent(PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, if (playing) R.drawable.ic_pause else R.drawable.ic_play), if (playing) "Pause" else "Play", pending(ACTION_TOGGLE, 1)).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close), "Close", pending(ACTION_STOP, 2)).build())
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1))
        return b.build()
    }

    companion object {
        private const val CHANNEL = "omnihub_playback"
        private const val NOTIF_ID = 7302
        const val ACTION_TOGGLE = "com.example.omnihub.PLAYBACK_TOGGLE"
        const val ACTION_STOP = "com.example.omnihub.PLAYBACK_STOP"
    }
}
