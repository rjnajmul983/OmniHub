package com.example.omnihub

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

/** Single source of truth for which extensions count as video / audio / image. */
object MediaKinds {
    val video = setOf(
        "mp4", "m4v", "mkv", "webm", "avi", "mov", "wmv", "flv", "f4v", "3gp", "3gpp", "3g2",
        "mpg", "mpeg", "mpe", "ts", "m2ts", "mts", "vob", "ogv", "asf", "divx", "rm", "rmvb", "mxf", "dv"
    )
    val audio = setOf(
        "mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "wma", "amr", "awb", "mid", "midi",
        "mka", "aiff", "aif", "ac3", "eac3", "dts", "ape", "wv", "mp2", "m4b", "weba", "caf", "3ga"
    )
    val image = setOf(
        "jpg", "jpeg", "jpe", "jfif", "png", "webp", "gif", "bmp", "wbmp", "ico",
        "heic", "heif", "avif", "svg", "dng"
    )

    fun ext(name: String): String = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
    fun isVideo(name: String) = ext(name) in video
    fun isAudio(name: String) = ext(name) in audio
    fun isImage(name: String) = ext(name) in image

    /** Files next to [file] of the same kind, sorted by name (used for next/previous). */
    fun siblings(file: File, kind: (String) -> Boolean): List<File> {
        val parent = file.parentFile ?: return listOf(file)
        val list = try { parent.listFiles() } catch (_: Exception) { null } ?: return listOf(file)
        val filtered = list.filter { it.isFile && !it.name.startsWith(".") && kind(it.name) }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        return if (filtered.any { it.absolutePath == file.absolutePath }) filtered else listOf(file)
    }
}

object MediaFmt {
    fun time(ms: Long): String {
        if (ms < 0) return "--:--"
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    fun size(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%.2f GB", mb / 1024.0)
    }
}

object MediaShare {
    /** Content URI that other apps can read; file:// URIs are wrapped with FileProvider. */
    fun shareableUri(activity: Activity, uri: Uri): Uri =
        if (uri.scheme == "file") {
            FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", File(uri.path ?: ""))
        } else uri

    fun share(activity: Activity, uri: Uri, mime: String) {
        try {
            val send = Intent(Intent.ACTION_SEND)
                .setType(mime.ifBlank { "*/*" })
                .putExtra(Intent.EXTRA_STREAM, shareableUri(activity, uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            activity.startActivity(Intent.createChooser(send, "Share"))
        } catch (e: Exception) {
            Toast.makeText(activity, "Share failed: ${e.localizedMessage ?: "unknown"}", Toast.LENGTH_LONG).show()
        }
    }

    fun openWithOtherApp(activity: Activity, uri: Uri, mime: String) {
        try {
            val view = Intent(Intent.ACTION_VIEW)
                .setDataAndType(shareableUri(activity, uri), mime.ifBlank { "*/*" })
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            activity.startActivity(Intent.createChooser(view, "Open with"))
        } catch (_: Exception) {
            Toast.makeText(activity, "No app found to open this file", Toast.LENGTH_LONG).show()
        }
    }
}
