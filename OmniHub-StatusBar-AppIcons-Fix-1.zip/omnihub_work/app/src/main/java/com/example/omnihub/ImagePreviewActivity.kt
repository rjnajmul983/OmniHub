package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.TextUtils
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.WebView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Full-screen image viewer: pinch / double-tap zoom, pan, swipe to next/previous image in the same folder,
 * rotate, slideshow, info, share. Handles JPEG, PNG, WebP, GIF (animated), BMP, ICO, HEIC/HEIF, AVIF (Android 12+), SVG.
 */
class ImagePreviewActivity : Activity() {
    private val accent = Color.rgb(98, 228, 211)
    private val handler = Handler(Looper.getMainLooper())
    private var loader: ExecutorService? = null
    @Volatile private var generation = 0

    private lateinit var zoom: ZoomImageView
    private lateinit var svgView: WebView
    private lateinit var spinner: ProgressBar
    private lateinit var errorBox: LinearLayout
    private lateinit var errorText: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var counterView: TextView
    private lateinit var slideshowBtn: ImageButton

    private var uris: List<Uri> = emptyList()
    private var names: List<String> = emptyList()
    private var index = 0
    private var barsVisible = true
    private var slideshow = false
    private var infoText = ""
    private var currentDrawable: Drawable? = null

    private val slideshowTick = object : Runnable {
        override fun run() {
            if (!slideshow) return
            if (uris.size > 1) show(index + 1)
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data ?: run { finish(); return }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        buildPlaylist(uri, intent.getStringExtra("name"))
        buildUi()
        loader = Executors.newSingleThreadExecutor()
        show(index)
    }

    private fun buildPlaylist(uri: Uri, name: String?) {
        if (uri.scheme == "file") {
            val f = File(uri.path ?: "")
            val sib = MediaKinds.siblings(f) { MediaKinds.isImage(it) }
            uris = sib.map { Uri.fromFile(it) }
            names = sib.map { it.name }
            index = sib.indexOfFirst { it.absolutePath == f.absolutePath }.coerceAtLeast(0)
        } else {
            uris = listOf(uri)
            names = listOf(name ?: queryName(uri) ?: "Image")
            index = 0
        }
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) { null }

    // ---------------------------------------------------------------- UI
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun iconButton(res: Int, desc: String, flip: Boolean = false, onClick: () -> Unit): ImageButton = ImageButton(this).apply {
        setImageResource(res)
        contentDescription = desc
        background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), null, GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) })
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(11), dp(11), dp(11), dp(11))
        if (flip) scaleX = -1f
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        zoom = ZoomImageView(this).apply {
            onTap = { toggleBars() }
            onSwipe = { dir -> if (uris.size > 1) { stopSlideshow(); show(index + dir) } }
        }
        root.addView(zoom, FrameLayout.LayoutParams(-1, -1))

        svgView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = false
            settings.allowFileAccess = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            visibility = View.GONE
        }
        root.addView(svgView, FrameLayout.LayoutParams(-1, -1))

        spinner = ProgressBar(this).apply { isIndeterminate = true; indeterminateTintList = ColorStateList.valueOf(accent) }
        root.addView(spinner, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))

        errorBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE; setPadding(dp(32), 0, dp(32), 0) }
        errorText = TextView(this).apply { setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); gravity = Gravity.CENTER }
        errorBox.addView(errorText)
        errorBox.addView(Button(this).apply {
            text = "Open with other app"
            setOnClickListener { MediaShare.openWithOtherApp(this@ImagePreviewActivity, uris[index], mimeFor(names[index])) }
        }, LinearLayout.LayoutParams(-2, dp(48)).apply { topMargin = dp(16) })
        root.addView(errorBox, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))

        topBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0))
        }
        topBar.addView(iconButton(R.drawable.ic_back, "Back") { finish() })
        topBar.addView(HomeNavigation.makeHomeButton(this), LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(2); rightMargin = dp(2) })
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            isSingleLine = true; ellipsize = TextUtils.TruncateAt.MIDDLE; setPadding(dp(6), 0, dp(6), 0)
        }
        topBar.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
        counterView = TextView(this).apply { setTextColor(Color.rgb(180, 190, 210)); setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f); setPadding(dp(6), 0, dp(6), 0) }
        topBar.addView(counterView)
        topBar.addView(iconButton(R.drawable.ic_info, "Info") { showInfo() })
        topBar.addView(iconButton(R.drawable.ic_share, "Share") { MediaShare.share(this, uris[index], mimeFor(names[index])) })
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        bottomBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(24), dp(8), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xCC000000.toInt(), 0))
        }
        bottomBar.addView(iconButton(R.drawable.ic_rotate_right, "Rotate left", flip = true) { zoom.rotate(-1) })
        bottomBar.addView(iconButton(R.drawable.ic_rotate_right, "Rotate right") { zoom.rotate(1) })
        bottomBar.addView(iconButton(R.drawable.ic_fit, "Reset zoom") { zoom.resetZoom() })
        slideshowBtn = iconButton(R.drawable.ic_slideshow, "Slideshow") { toggleSlideshow() }
        bottomBar.addView(slideshowBtn)
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
        InsetsUtil.applyOverlay(this, root) { i ->
            topBar.setPadding(dp(8) + i.left, dp(8) + i.top, dp(8) + i.right, dp(24))
            bottomBar.setPadding(dp(8) + i.left, dp(24), dp(8) + i.right, dp(12) + i.bottom)
        }
    }

    private fun toggleBars() {
        barsVisible = !barsVisible
        for (v in listOf<View>(topBar, bottomBar)) {
            v.animate().alpha(if (barsVisible) 1f else 0f).setDuration(160).withEndAction { v.visibility = if (barsVisible) View.VISIBLE else View.GONE }.start()
            if (barsVisible) v.visibility = View.VISIBLE
        }
        applyImmersiveMode(!barsVisible)
    }

    @Suppress("DEPRECATION")
    private fun applyImmersiveMode(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(!on)
            window.insetsController?.let {
                if (on) { it.hide(WindowInsets.Type.systemBars()); it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
                else it.show(WindowInsets.Type.systemBars())
            }
        } else {
            window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) else 0
        }
    }

    private fun toggleSlideshow() {
        slideshow = !slideshow
        slideshowBtn.imageTintList = ColorStateList.valueOf(if (slideshow) accent else Color.WHITE)
        handler.removeCallbacks(slideshowTick)
        if (slideshow) {
            if (uris.size < 2) { slideshow = false; slideshowBtn.imageTintList = ColorStateList.valueOf(Color.WHITE); return }
            handler.postDelayed(slideshowTick, 3000)
        }
    }

    private fun stopSlideshow() {
        if (!slideshow) return
        slideshow = false
        handler.removeCallbacks(slideshowTick)
        slideshowBtn.imageTintList = ColorStateList.valueOf(Color.WHITE)
    }

    // ---------------------------------------------------------------- loading
    private fun mimeFor(name: String): String = when (MediaKinds.ext(name)) {
        "jpg", "jpeg", "jpe", "jfif" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "bmp" -> "image/bmp"
        "heic" -> "image/heic"
        "heif" -> "image/heif"
        "avif" -> "image/avif"
        "svg" -> "image/svg+xml"
        else -> "image/*"
    }

    private fun show(i: Int) {
        if (uris.isEmpty()) return
        index = ((i % uris.size) + uris.size) % uris.size
        val uri = uris[index]
        val name = names[index]
        val gen = ++generation
        titleView.text = name
        counterView.text = if (uris.size > 1) "${index + 1}/${uris.size}" else ""
        spinner.visibility = View.VISIBLE
        errorBox.visibility = View.GONE

        if (MediaKinds.ext(name) == "svg") { showSvg(uri); return }
        svgView.visibility = View.GONE
        zoom.visibility = View.VISIBLE

        loader?.execute {
            var drawable: Drawable? = null
            var error: String? = null
            var dims = ""
            try {
                val d = decode(uri)
                drawable = d.first
                dims = d.second
            } catch (t: Throwable) {
                error = t.localizedMessage ?: t.javaClass.simpleName
            }
            val result = drawable
            val message = error
            val dimText = dims
            runOnUiThread {
                if (isFinishing || isDestroyed || gen != generation) return@runOnUiThread
                spinner.visibility = View.GONE
                if (result != null) {
                    currentDrawable = result
                    zoom.showDrawable(result)
                    if (result is AnimatedImageDrawable) result.start()
                    infoText = buildInfo(uri, name, dimText)
                } else {
                    zoom.showDrawable(null)
                    errorText.text = "ছবি খোলা যায়নি।\n${message ?: ""}"
                    errorBox.visibility = View.VISIBLE
                    infoText = buildInfo(uri, name, dimText)
                }
            }
        }
    }

    private fun showSvg(uri: Uri) {
        zoom.visibility = View.GONE
        svgView.visibility = View.VISIBLE
        spinner.visibility = View.GONE
        try {
            if (uri.scheme == "file") svgView.loadUrl("file://" + uri.path)
            else {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: throw IllegalStateException("Image could not be read")
                svgView.loadDataWithBaseURL(null, text, "image/svg+xml", "UTF-8", null)
            }
            infoText = buildInfo(uri, names[index], "vector (SVG)")
        } catch (t: Throwable) {
            errorText.text = "SVG খোলা যায়নি।\n${t.localizedMessage ?: ""}"
            errorBox.visibility = View.VISIBLE
        }
    }

    private fun openStream(uri: Uri): InputStream =
        if (uri.scheme == "file") FileInputStream(File(uri.path ?: throw IllegalStateException("Bad path")))
        else contentResolver.openInputStream(uri) ?: throw IllegalStateException("Image could not be read (no stream)")

    /** Returns the decoded drawable (down-sampled to a safe size) and a text with the ORIGINAL dimensions. */
    private fun decode(uri: Uri): Pair<Drawable, String> {
        // 1) read the real size. NOTE: decodeStream() returns null in bounds mode by design — never treat that as an error.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try { openStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) } } catch (_: Exception) { }
        val origW = bounds.outWidth
        val origH = bounds.outHeight
        val dims = if (origW > 0) "${origW} × ${origH}" else ""

        // 2) ImageDecoder (API 28+): HEIC/HEIF, animated GIF/WebP, EXIF rotation, AVIF on 31+
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val src = if (uri.scheme == "file") ImageDecoder.createSource(File(uri.path ?: "")) else ImageDecoder.createSource(contentResolver, uri)
                val d = ImageDecoder.decodeDrawable(src) { decoder, info, _ ->
                    var s = 1
                    val w = info.size.width
                    val h = info.size.height
                    while (max(w, h) / s > MAX_DIM || (w.toLong() / s) * (h.toLong() / s) > MAX_PIXELS) s *= 2
                    if (s > 1) decoder.setTargetSampleSize(s)
                }
                val realDims = if (dims.isNotEmpty()) dims else "${(d.intrinsicWidth)} × ${(d.intrinsicHeight)}"
                return Pair(d, realDims)
            } catch (t: Throwable) {
                // fall through to BitmapFactory (also covers OutOfMemoryError on huge images)
            }
        }

        // 3) BitmapFactory fallback
        if (origW <= 0 || origH <= 0) throw IllegalArgumentException("Unsupported or corrupted image")
        var sample = 1
        while (max(origW, origH) / sample > MAX_DIM || (origW.toLong() / sample) * (origH.toLong() / sample) > MAX_PIXELS) sample *= 2
        var bmp: Bitmap? = null
        var attempts = 0
        while (bmp == null && attempts < 4) {
            try {
                bmp = openStream(uri).use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
            } catch (_: OutOfMemoryError) { sample *= 2 }
            attempts++
        }
        val decoded = bmp ?: throw IllegalStateException("Image decode failed")
        val rotated = applyExif(uri, decoded)
        return Pair(BitmapDrawable(resources, rotated), dims)
    }

    private fun applyExif(uri: Uri, bmp: Bitmap): Bitmap {
        return try {
            val exif = if (uri.scheme == "file") ExifInterface(uri.path ?: return bmp)
            else if (Build.VERSION.SDK_INT >= 24) openStream(uri).use { ExifInterface(it) } else return bmp
            val m = Matrix()
            when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
                else -> return bmp
            }
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (_: Throwable) { bmp }
    }

    private fun buildInfo(uri: Uri, name: String, dims: String): String {
        val sb = StringBuilder()
        sb.append("Name: ").append(name).append('\n')
        if (dims.isNotEmpty()) sb.append("Size: ").append(dims).append(" px\n")
        if (uri.scheme == "file") {
            val f = File(uri.path ?: "")
            sb.append("File size: ").append(MediaFmt.size(f.length())).append('\n')
            sb.append("Modified: ").append(DateFormat.getDateTimeInstance().format(Date(f.lastModified()))).append('\n')
            sb.append("Folder: ").append(f.parentFile?.name ?: "")
        }
        return sb.toString()
    }

    private fun showInfo() {
        AlertDialog.Builder(this).setTitle("Image info").setMessage(infoText.ifBlank { names.getOrNull(index) ?: "" })
            .setPositiveButton("OK", null)
            .also { b -> if (SetAs.canSetWallpaper(names.getOrNull(index).orEmpty())) b.setNeutralButton("Set as wallpaper") { _, _ -> SetAs.wallpaper(this, uris[index]) } }
            .show()
    }

    override fun onPause() {
        super.onPause()
        stopSlideshow()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        generation++
        try { loader?.shutdownNow() } catch (_: Exception) { }
        loader = null
        try { (currentDrawable as? AnimatedImageDrawable)?.stop() } catch (_: Exception) { }
        try { svgView.destroy() } catch (_: Exception) { }
        super.onDestroy()
    }

    companion object {
        private const val MAX_DIM = 4096
        private const val MAX_PIXELS = 16_000_000L
    }
}

/** ImageView with pinch zoom, double-tap zoom, pan and 90° rotation. Reports taps and horizontal swipes. */
class ZoomImageView(context: Context) : ImageView(context) {
    var onTap: (() -> Unit)? = null
    var onSwipe: ((Int) -> Unit)? = null   // +1 next, -1 previous

    private val base = Matrix()
    private val user = Matrix()
    private val combined = Matrix()
    private val rect = RectF()
    private var quarter = 0
    private var userScale = 1f
    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0f
    private var startY = 0f
    private var multi = false
    private val swipeThreshold = (80 * resources.displayMetrics.density)

    init { scaleType = ScaleType.MATRIX }

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val target = (userScale * detector.scaleFactor).coerceIn(1f, MAX_ZOOM)
            val f = target / userScale
            user.postScale(f, f, detector.focusX, detector.focusY)
            userScale = target
            clampAndApply()
            return true
        }
    })

    private val tapDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (userScale > 1.05f) resetZoom()
            else {
                val target = 3f
                user.postScale(target, target, e.x, e.y)
                userScale = target
                clampAndApply()
            }
            return true
        }
    })

    fun showDrawable(d: Drawable?) {
        quarter = 0
        user.reset(); userScale = 1f
        setImageDrawable(d)
        fit()
    }

    fun rotate(dir: Int) {
        if (drawable == null) return
        quarter = (quarter + dir + 4) % 4
        user.reset(); userScale = 1f
        fit()
    }

    fun resetZoom() {
        user.reset(); userScale = 1f
        clampAndApply()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        user.reset(); userScale = 1f
        fit()
    }

    private fun fit() {
        val d = drawable ?: run { imageMatrix = Matrix(); return }
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (dw <= 0 || dh <= 0 || vw <= 0 || vh <= 0) return
        val rw = if (quarter % 2 == 0) dw else dh
        val rh = if (quarter % 2 == 0) dh else dw
        val s = min(vw / rw, vh / rh)
        base.reset()
        base.postTranslate(-dw / 2f, -dh / 2f)
        base.postRotate(quarter * 90f)
        base.postScale(s, s)
        base.postTranslate(vw / 2f, vh / 2f)
        clampAndApply()
    }

    private fun clampAndApply() {
        val d = drawable ?: return
        combined.set(base)
        combined.postConcat(user)
        rect.set(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        combined.mapRect(rect)
        var dx = 0f
        var dy = 0f
        if (rect.width() <= width) dx = width / 2f - rect.centerX()
        else if (rect.left > 0) dx = -rect.left
        else if (rect.right < width) dx = width - rect.right
        if (rect.height() <= height) dy = height / 2f - rect.centerY()
        else if (rect.top > 0) dy = -rect.top
        else if (rect.bottom < height) dy = height - rect.bottom
        if (dx != 0f || dy != 0f) { user.postTranslate(dx, dy); combined.postTranslate(dx, dy) }
        imageMatrix = combined
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        tapDetector.onTouchEvent(ev)
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = ev.x; lastY = ev.y; startX = ev.x; startY = ev.y; multi = false }
            MotionEvent.ACTION_POINTER_DOWN -> multi = true
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (ev.actionIndex == 0) 1 else 0
                lastX = ev.getX(i); lastY = ev.getY(i)
            }
            MotionEvent.ACTION_MOVE -> {
                if (ev.pointerCount == 1 && !scaleDetector.isInProgress && userScale > 1.01f) {
                    user.postTranslate(ev.x - lastX, ev.y - lastY)
                    clampAndApply()
                }
                if (ev.pointerCount == 1) { lastX = ev.x; lastY = ev.y }
            }
            MotionEvent.ACTION_UP -> {
                if (!multi && userScale <= 1.01f) {
                    val dx = ev.x - startX
                    val dy = ev.y - startY
                    if (abs(dx) > swipeThreshold && abs(dx) > abs(dy) * 2) onSwipe?.invoke(if (dx < 0) 1 else -1)
                }
            }
        }
        return true
    }

    companion object { private const val MAX_ZOOM = 8f }
}
