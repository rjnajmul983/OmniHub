package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/** Recycle Bin for items moved by OmniHub's file manager. Restore and permanent delete are explicit. */
class RecycleBinActivity : Activity() {
    private val bg = Color.rgb(242, 240, 247)
    private val white = Color.rgb(252, 251, 254)
    private val line = Color.rgb(218, 213, 230)
    private val ink = Color.rgb(37, 34, 47)
    private val muted = Color.rgb(94, 88, 112)
    private val accent = Color.rgb(102, 80, 196)
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    @Volatile private var items: List<File> = emptyList()
    @Volatile private var itemSizes: Map<String, Long> = emptyMap()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = white
        if (android.os.Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)); setBackgroundColor(white) }
        top.addView(btn("‹", white) { finish() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        val title = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        title.addView(text("Recycle Bin", 20f, ink, true)); title.addView(text("Restore or permanently remove files", 11f, muted, false))
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(btn("Empty", white) { confirmEmpty() }, LinearLayout.LayoutParams(dp(66), dp(40)))
        root.addView(top); root.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
        status = text("Looking for items…", 11f, muted, false).apply { setPadding(dp(16), dp(8), dp(16), dp(4)) }
        root.addView(status)
        val scroll = ScrollView(this).apply { setPadding(dp(14), dp(8), dp(14), dp(20)) }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
        scan()
    }

    private fun scan() {
        status.text = "Looking for recycled files…"
        io.execute {
            val base = Environment.getExternalStorageDirectory()
            val found = ArrayList<File>()
            val sizes = HashMap<String, Long>()
            var visited = 0
            try {
                val sequence = base.walkTopDown().onEnter { dir ->
                    if (dir.name == ".omnihub_trash") true
                    else {
                        val rel = try { dir.relativeTo(base).path.replace('\\', '/') } catch (_: Exception) { "" }
                        dir == base || (!dir.name.startsWith(".") && !rel.startsWith("Android/data") && !rel.startsWith("Android/obb") && dir.canRead())
                    }
                }
                for (file in sequence) {
                    if (Thread.currentThread().isInterrupted || isFinishing) break
                    visited++
                    if (file.parentFile?.name == ".omnihub_trash" && file.exists()) found.add(file)
                    // Aggregate trashed directories while already traversing on this worker thread,
                    // so rendering the list never recursively scans folders on the UI thread.
                    if (file.isFile) {
                        var item: File? = file
                        var trashItem: File? = null
                        while (true) {
                            val current = item ?: break
                            val parent = current.parentFile ?: break
                            if (parent.name == ".omnihub_trash") { trashItem = current; break }
                            item = parent
                        }
                        if (trashItem != null) sizes[trashItem.absolutePath] = (sizes[trashItem.absolutePath] ?: 0L) + file.length()
                    }
                    if (visited > 120_000 || found.size >= 5000) break
                }
            } catch (_: Throwable) { }
            val result = found.sortedByDescending { it.lastModified() }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                items = result
                itemSizes = sizes
                render(result, visited >= 120_000 || found.size >= 5000)
            }
        }
    }

    private fun render(entries: List<File>, capped: Boolean) {
        list.removeAllViews()
        val bytes = entries.sumOf { itemSizes[it.absolutePath] ?: if (it.isFile) it.length() else 0L }
        status.text = "${entries.size} item(s) · ${human(bytes)}${if (capped) " · scan limit reached" else ""}"
        if (entries.isEmpty()) {
            card {
                addView(text("Recycle Bin is empty", 16f, ink, true))
                addView(text("When you choose Move to Recycle Bin from OmniHub's file manager, the items will appear here.", 12f, muted, false).apply { setPadding(0, dp(6), 0, 0) })
            }
            return
        }
        entries.forEach { file ->
            card {
                addView(text(file.name, 14f, ink, true))
                val itemSize = itemSizes[file.absolutePath] ?: if (file.isFile) file.length() else 0L
                addView(text("${if (file.isDirectory) "Folder · ${human(itemSize)}" else human(file.length())} · ${file.parentFile?.parentFile?.absolutePath.orEmpty()}", 10f, muted, false).apply { setPadding(0, dp(4), 0, dp(10)) })
                val actions = LinearLayout(this@RecycleBinActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                actions.addView(btn("Restore", accent) { restore(file) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(7) })
                actions.addView(btn("Delete permanently", white) { confirmPermanent(file) }, LinearLayout.LayoutParams(0, dp(40), 1f))
                addView(actions)
            }
        }
    }

    private fun restore(file: File) {
        val trashDir = file.parentFile ?: return
        val originalParent = trashDir.parentFile ?: return
        if (!originalParent.exists() || !originalParent.isDirectory) {
            Toast.makeText(this, "Original folder is no longer available", Toast.LENGTH_LONG).show(); return
        }
        var target = File(originalParent, file.name)
        var i = 1
        while (target.exists()) { target = File(originalParent, "${file.nameWithoutExtension} (restored $i)${if (file.extension.isBlank()) "" else ".${file.extension}"}"); i++ }
        io.execute {
            val ok = try { file.renameTo(target) } catch (_: Throwable) { false }
            runOnUiThread { if (ok) { Toast.makeText(this, "Restored: ${target.name}", Toast.LENGTH_SHORT).show(); scan() } else Toast.makeText(this, "Could not restore this item", Toast.LENGTH_LONG).show() }
        }
    }

    private fun confirmPermanent(file: File) {
        AlertDialog.Builder(this).setTitle("Delete permanently?")
            .setMessage("${file.name} will be removed permanently and cannot be restored.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete permanently") { _, _ ->
                io.execute {
                    val ok = try { if (file.isDirectory) file.deleteRecursively() else file.delete() } catch (_: Throwable) { false }
                    runOnUiThread { if (ok) scan() else Toast.makeText(this, "Could not delete this item", Toast.LENGTH_LONG).show() }
                }
            }.show()
    }

    private fun confirmEmpty() {
        if (items.isEmpty()) { Toast.makeText(this, "Recycle Bin is already empty", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Empty Recycle Bin?")
            .setMessage("Permanently delete all ${items.size} item(s) in OmniHub's Recycle Bin?")
            .setNegativeButton("Cancel", null).setPositiveButton("Empty permanently") { _, _ ->
                io.execute {
                    var removed = 0
                    items.forEach { f -> try { if (if (f.isDirectory) f.deleteRecursively() else f.delete()) removed++ } catch (_: Throwable) { } }
                    runOnUiThread { Toast.makeText(this, "Removed $removed item(s)", Toast.LENGTH_LONG).show(); scan() }
                }
            }.show()
    }

    private fun human(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024L * 1024 -> String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0); bytes < 1024L * 1024 * 1024 -> String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024)); else -> String.format(Locale.ROOT, "%.2f GB", bytes / (1024.0 * 1024 * 1024)) }
    private fun text(t: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER_VERTICAL; setLineSpacing(dp(2).toFloat(), 1f) }
    private fun btn(t: String, color: Int, action: () -> Unit) = Button(this).apply { text = t; textSize = 11f; isAllCaps = false; setTextColor(if (color == accent) Color.WHITE else ink); backgroundTintList = android.content.res.ColorStateList.valueOf(color); minHeight = dp(36); minimumHeight = dp(36); setPadding(dp(4), 0, dp(4), 0); setOnClickListener { action() } }
    private fun card(block: LinearLayout.() -> Unit) { val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = android.graphics.drawable.GradientDrawable().apply { setColor(white); cornerRadius = dp(16).toFloat(); setStroke(dp(1), line) } }; c.block(); list.addView(c, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }) }
    override fun onDestroy() { io.shutdownNow(); super.onDestroy() }
}
