package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/** Finds exact-content duplicates using SHA-256 and conservative junk candidates. No auto-deletion. */
class DuplicateCleanerActivity : Activity() {
    private val bg=Color.rgb(242, 240, 247);private val white=Color.rgb(252, 251, 254);private val ink=Color.rgb(37, 34, 47);private val muted=Color.rgb(94, 88, 112);private val line=Color.rgb(218, 213, 230);private val accent=Color.rgb(102, 80, 196)
    private val io=Executors.newSingleThreadExecutor();private lateinit var list:LinearLayout;private lateinit var status:TextView;private lateinit var scanBtn:Button
    private data class Candidate(val file:File,val reason:String,val bytes:Long,val duplicate:Boolean)
    private var candidates:List<Candidate> = emptyList();private val selected=linkedSetOf<String>();private var scanning=false
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);window.statusBarColor=bg;window.navigationBarColor=white;if(android.os.Build.VERSION.SDK_INT>=23)window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)};val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(8),dp(14),dp(8));setBackgroundColor(white)};top.addView(btn("‹",white){finish()},LinearLayout.LayoutParams(dp(44),dp(44)));val title=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)};title.addView(txt("Duplicate & Junk Cleaner",19f,ink,true));title.addView(txt("Verify first · remove only after review",11f,muted,false));top.addView(title,LinearLayout.LayoutParams(0,-2,1f));root.addView(top);root.addView(View(this).apply{setBackgroundColor(line)},LinearLayout.LayoutParams(-1,dp(1)))
        status=txt("Ready to scan accessible shared storage.",11f,muted,false).apply{setPadding(dp(16),dp(10),dp(16),dp(6))};root.addView(status)
        val scroll=ScrollView(this).apply{clipToPadding=false;setPadding(dp(14),dp(8),dp(14),dp(18))};list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));val bottom=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(14),dp(8),dp(14),dp(12));setBackgroundColor(white)};scanBtn=btn("Scan",accent){scan()};bottom.addView(scanBtn,LinearLayout.LayoutParams(0,dp(48),1f).apply{rightMargin=dp(8)});bottom.addView(btn("Remove selected",Color.rgb(190,55,65)){confirmDelete()},LinearLayout.LayoutParams(0,dp(48),1f));root.addView(bottom);setContentView(root);intro()
    }
    private fun intro(){list.removeAllViews();card{addView(txt("Exact duplicate detection",15f,ink,true));addView(txt("Candidates are grouped by file size, then verified by SHA-256 content hash. Same name or same size alone is never enough to mark a duplicate.",12f,muted,false).apply{setPadding(0,dp(6),0,0)})};card{addView(txt("Conservative junk candidates",15f,ink,true));addView(txt("Only old standalone APK installers (90+ days) and empty directories are suggested. Cache, thumbnails, app data, and unknown files are not automatically classified as junk.",12f,muted,false).apply{setPadding(0,dp(6),0,0)})}}
    private fun scan(){if(scanning)return;scanning=true;scanBtn.isEnabled=false;selected.clear();candidates=emptyList();status.text="Scanning and verifying content hashes…";list.removeAllViews();card{addView(txt("Working in background",15f,ink,true));addView(txt("Large libraries may take time. The scan is limited to 60,000 entries and skips protected/hidden folders.",12f,muted,false).apply{setPadding(0,dp(5),0,0)})}
        io.execute{val base=Environment.getExternalStorageDirectory();val sizeGroups=HashMap<Long,MutableList<File>>();val junk=ArrayList<Candidate>();var visited=0;val now=System.currentTimeMillis();val cutoff=now-90L*24*60*60*1000
            try{for(f in base.walkTopDown().onEnter{d->val rel=try{d.relativeTo(base).path.replace('\\','/')}catch(_:Throwable){""};d==base||(d.name!=".omnihub_trash"&&!d.name.startsWith(".")&&!rel.startsWith("Android/data")&&!rel.startsWith("Android/obb")&&d.canRead())}){if(Thread.currentThread().isInterrupted)break;visited++;if(visited>60000)break
                if(f.isFile&&f.canRead()){val size=try{f.length()}catch(_:Throwable){-1L};if(size>0)sizeGroups.getOrPut(size){mutableListOf()}.add(f);if(f.extension.equals("apk",true)&&f.lastModified() in 1 until cutoff)junk.add(Candidate(f,"Old APK installer · older than 90 days",size,false))}
                else if(f.isDirectory&&f!=base&&f.name!="Android"&&f.name!="Download"&&f.name!="DCIM"&&f.name!="Pictures"&&f.name!="Movies"&&f.name!="Music"&&f.name!="Documents"&&f.name!="Android"&&f.canRead()&&f.listFiles()?.isEmpty()==true)junk.add(Candidate(f,"Empty directory",0,false))
            }}catch(_:Throwable){}
            val exact=ArrayList<Candidate>();var hashOps=0
            try{for((_,files) in sizeGroups){if(files.size<2)continue;val hashes=HashMap<String,MutableList<File>>();for(f in files){if(Thread.currentThread().isInterrupted)break;val h=FileContentHash.sha256(f)?:continue;hashes.getOrPut(h){mutableListOf()}.add(f);hashOps++};for(group in hashes.values.filter{it.size>1}){val ordered=group.sortedByDescending{it.lastModified()};ordered.drop(1).forEach{exact.add(Candidate(it,"Exact duplicate of ${ordered.first().name}",it.length(),true))}}}}catch(_:Throwable){}
            val out=(exact+junk).distinctBy{it.file.absolutePath}.take(1000)
            runOnUiThread{scanning=false;scanBtn.isEnabled=true;candidates=out;render(visited>=60000,exact.size,junk.size,hashOps)}
        }
    }

    private fun render(capped:Boolean, duplicateCount:Int, junkCount:Int, hashOps:Int){
        list.removeAllViews()
        status.text="${candidates.size} candidate(s) · $duplicateCount duplicate file(s) · $junkCount junk suggestion(s)${if(capped)" · scan limit reached" else ""}"
        card {
            addView(txt("Scan summary",15f,ink,true))
            addView(txt("Checked $hashOps file hash(es). Select only items you have reviewed; deletion is permanent.",12f,muted,false).apply{setPadding(0,dp(5),0,0)})
        }
        if(candidates.isEmpty()){
            card { addView(txt("No candidates found",15f,ink,true)); addView(txt("No exact duplicates or conservative junk suggestions were found in the accessible files scanned.",12f,muted,false).apply{setPadding(0,dp(5),0,0)}) }
            return
        }
        candidates.forEach { candidate ->
            card {
                val check=CheckBox(this@DuplicateCleanerActivity).apply {
                    text=candidate.file.name.ifBlank { candidate.file.absolutePath }
                    textSize=14f
                    setTextColor(ink)
                    isChecked=selected.contains(candidate.file.absolutePath)
                    setOnCheckedChangeListener { _, checked ->
                        if(checked) selected.add(candidate.file.absolutePath) else selected.remove(candidate.file.absolutePath)
                    }
                }
                addView(check)
                addView(txt(candidate.reason,12f,if(candidate.duplicate) accent else muted,false).apply{setPadding(dp(32),0,0,dp(3))})
                addView(txt("${human(candidate.bytes)} · ${candidate.file.absolutePath}",10f,muted,false).apply{setPadding(dp(32),0,0,0)})
            }
        }
    }

    private fun confirmDelete(){val chosen=candidates.filter{selected.contains(it.file.absolutePath)};if(chosen.isEmpty()){Toast.makeText(this,"Select items to remove",Toast.LENGTH_SHORT).show();return};AlertDialog.Builder(this).setTitle("Permanently remove ${chosen.size} item(s)?").setMessage("This operation cannot be undone. Review the selected paths carefully. Estimated size: ${human(chosen.sumOf{it.bytes})}. No files will be removed unless you confirm.").setNegativeButton("Cancel",null).setPositiveButton("Delete permanently"){_,_->io.execute{var removed=0;var failed=0;for(c in chosen){try{val ok=if(c.file.isDirectory)c.file.delete() else c.file.delete();if(ok)removed++ else failed++}catch(_:Throwable){failed++}};runOnUiThread{Toast.makeText(this,"Removed $removed · failed $failed",Toast.LENGTH_LONG).show();scan()}}}.show()}
    private fun card(block:LinearLayout.()->Unit){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(12),dp(13),dp(12));background=android.graphics.drawable.GradientDrawable().apply{setColor(white);cornerRadius=dp(15).toFloat();setStroke(dp(1),line)}};c.block();list.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})}
    private fun txt(t:String,s:Float,c:Int,b:Boolean)=TextView(this).apply{text=t;textSize=s;setTextColor(c);if(b)typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER_VERTICAL;setLineSpacing(dp(2).toFloat(),1f)}
    private fun btn(t:String,color:Int,action:()->Unit)=Button(this).apply{text=t;textSize=11f;isAllCaps=false;setTextColor(if(color==accent||color==Color.rgb(190,55,65))Color.WHITE else ink);backgroundTintList=android.content.res.ColorStateList.valueOf(color);minHeight=dp(36);minimumHeight=dp(36);setPadding(dp(5),0,dp(5),0);setOnClickListener{action()}}
    private fun human(n:Long)=when{n<1024->"$n B";n<1024L*1024->String.format(Locale.ROOT,"%.1f KB",n/1024.0);n<1024L*1024*1024->String.format(Locale.ROOT,"%.1f MB",n/(1024.0*1024));else->String.format(Locale.ROOT,"%.2f GB",n/(1024.0*1024*1024))}
    override fun onDestroy(){io.shutdownNow();super.onDestroy()}
}
