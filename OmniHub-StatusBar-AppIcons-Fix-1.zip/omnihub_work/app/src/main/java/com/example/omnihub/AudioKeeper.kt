package com.example.omnihub

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.MediaMetadataRetriever
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs
import kotlin.math.sin

/** Application subclass: lets the mini player bar appear on top of any OmniHub screen while audio keeps playing. */
class OmniHubApp : Application() {
    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(MiniPlayerHost)
    }
}

/**
 * Holds an audio player after its full-screen MediaActivity was closed with Back, so the music keeps playing
 * until the user stops it (mini player / notification) or the app is closed.
 */
object AudioKeeper {
    class Session(
        val player: ExoPlayer,
        var playlist: List<Uri>,
        var names: List<String>,
        var index: Int,
        var repeatMode: Int,
        var shuffle: Boolean,
        var speed: Float,
        var equalizer: Equalizer?
    )

    @Volatile var session: Session? = null
        private set
    var displayTitle: String = "OmniHub"
        private set
    var artist: String = ""
        private set
    var art: Bitmap? = null
        private set

    private var appContext: Context? = null
    private val handler = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<() -> Unit>()

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) onEnded()
            changed()
        }
        override fun onIsPlayingChanged(isPlaying: Boolean) { changed() }
        override fun onPlayerError(error: PlaybackException) { changed() }
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun changed() { listeners.toList().forEach { try { it() } catch (_: Throwable) { } } }

    val isPlaying: Boolean get() = try { session?.player?.isPlaying == true } catch (_: Throwable) { false }
    val currentUri: Uri? get() = session?.let { it.playlist.getOrNull(it.index) }
    val currentName: String get() = session?.let { it.names.getOrNull(it.index) } ?: ""

    /** Called by MediaActivity when it is closed with Back while audio is playing/paused. */
    fun keep(ctx: Context, s: Session) {
        discard()
        appContext = ctx.applicationContext
        session = s
        s.player.addListener(playerListener)
        updateTitle()
        loadMeta()
        val open = Intent(appContext, MediaActivity::class.java)
            .setDataAndType(currentUri, "audio/*")
            .putExtra("adopt", true)
            .putExtra("mime", "audio/*")
            .putExtra("name", currentName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        PlaybackHub.openIntent = open
        PlaybackHub.title = { displayTitle }
        PlaybackHub.service?.refresh()
        changed()
    }

    /**
     * MediaActivity start-up: if a kept session exists and the activity wants to adopt it, hand it over;
     * otherwise stop the old one (a different file is about to play).
     */
    fun takeForActivity(adopt: Boolean): Session? {
        val s = session ?: return null
        if (!adopt) { discard(); return null }
        try { s.player.removeListener(playerListener) } catch (_: Throwable) { }
        session = null
        art = null
        changed()
        return s
    }

    /** Stops playback for good: releases the player, equalizer and the notification. */
    fun discard() {
        val s = session ?: return
        session = null
        art = null
        try { s.player.removeListener(playerListener) } catch (_: Throwable) { }
        try { s.player.pause() } catch (_: Throwable) { }
        PlaybackHub.detach(s.player)
        try { s.equalizer?.release() } catch (_: Throwable) { }
        try { s.player.release() } catch (_: Throwable) { }
        changed()
    }

    fun toggle() {
        val p = session?.player ?: return
        try {
            if (p.playbackState == Player.STATE_ENDED) { p.seekTo(0L); p.play() }
            else if (p.isPlaying) p.pause() else p.play()
        } catch (_: Throwable) { }
    }

    fun next() {
        val s = session ?: return
        if (s.playlist.size > 1) loadItem(if (s.shuffle) randomOther(s) else s.index + 1)
        else try { s.player.seekTo(0L) } catch (_: Throwable) { }
    }

    fun previous() {
        val s = session ?: return
        if (s.player.currentPosition > 4000 || s.playlist.size <= 1) s.player.seekTo(0L) else loadItem(s.index - 1)
    }

    private fun randomOther(s: Session): Int {
        var r = s.index
        while (r == s.index) r = (Math.random() * s.playlist.size).toInt().coerceAtMost(s.playlist.size - 1)
        return r
    }

    private fun onEnded() {
        val s = session ?: return
        when {
            s.repeatMode == 2 -> { s.player.seekTo(0L); s.player.play() }
            s.shuffle && s.playlist.size > 1 -> loadItem(randomOther(s))
            s.playlist.size > 1 && (s.repeatMode == 1 || s.index < s.playlist.size - 1) -> loadItem(s.index + 1)
        }
    }

    private fun loadItem(i: Int) {
        val s = session ?: return
        val n = s.playlist.size
        if (n == 0) return
        s.index = ((i % n) + n) % n
        val p = s.player
        p.setMediaItem(MediaItem.fromUri(s.playlist[s.index]))
        p.setPlaybackSpeed(s.speed)
        p.repeatMode = if (s.repeatMode == 2) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        p.prepare()
        p.playWhenReady = true
        updateTitle()
        art = null
        loadMeta()
        PlaybackHub.openIntent = Intent(appContext, MediaActivity::class.java)
            .setDataAndType(currentUri, "audio/*")
            .putExtra("adopt", true).putExtra("mime", "audio/*").putExtra("name", currentName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        PlaybackHub.service?.refresh()
        changed()
    }

    private fun updateTitle() {
        displayTitle = currentName.substringBeforeLast('.').ifBlank { "OmniHub" }
        artist = ""
    }

    private fun loadMeta() {
        val uri = currentUri ?: return
        val ctx = appContext ?: return
        Thread {
            var title: String? = null
            var art2: String? = null
            var bmp: Bitmap? = null
            val r = MediaMetadataRetriever()
            try {
                if (uri.scheme == "file") r.setDataSource(uri.path) else r.setDataSource(ctx, uri)
                title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                art2 = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                r.embeddedPicture?.let { bytes ->
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var sample = 1
                    while (o.outWidth / sample > 256 || o.outHeight / sample > 256) sample *= 2
                    bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                }
            } catch (_: Throwable) {
            } finally { try { r.release() } catch (_: Exception) { } }
            handler.post {
                if (currentUri != uri) return@post
                if (!title.isNullOrBlank()) displayTitle = title!!
                artist = art2?.takeIf { it.isNotBlank() } ?: ""
                art = bmp
                PlaybackHub.service?.refresh()
                changed()
            }
        }.start()
    }
}

/** Adds the mini player bar to the main OmniHub screens while an audio session is being kept. */
object MiniPlayerHost : Application.ActivityLifecycleCallbacks {
    private val allowed: Set<Class<*>> = setOf(
        MainActivity::class.java, FileManagerActivity::class.java, StorageToolsActivity::class.java,
        GlobalSearchActivity::class.java, DuplicateCleanerActivity::class.java, RecycleBinActivity::class.java,
        SecureVaultActivity::class.java, AppLockerActivity::class.java
    )
    private val bars = HashMap<Activity, MiniPlayerBar>()

    override fun onActivityResumed(activity: Activity) {
        if (activity.javaClass !in allowed || bars.containsKey(activity)) return
        val decor = activity.window?.decorView as? ViewGroup ?: return
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val bar = MiniPlayerBar(activity)
        val basePad = intArrayOf(content.paddingLeft, content.paddingTop, content.paddingRight, content.paddingBottom)
        bar.onVisibilityChange = { shown ->
            content.setPadding(basePad[0], basePad[1], basePad[2], basePad[3] + if (shown) bar.barHeight else 0)
        }
        bar.restorePadding = { content.setPadding(basePad[0], basePad[1], basePad[2], basePad[3]) }
        decor.addView(bar, FrameLayout.LayoutParams(-1, bar.barHeight, Gravity.BOTTOM))
        ViewCompat.setOnApplyWindowInsetsListener(bar) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            (v.layoutParams as? FrameLayout.LayoutParams)?.let { if (it.bottomMargin != b) { it.bottomMargin = b; v.layoutParams = it } }
            insets
        }
        ViewCompat.requestApplyInsets(bar)
        bars[activity] = bar
    }

    override fun onActivityPaused(activity: Activity) {
        val bar = bars.remove(activity) ?: return
        bar.restorePadding?.invoke()
        (bar.parent as? ViewGroup)?.removeView(bar)
    }

    override fun onActivityCreated(a: Activity, b: Bundle?) {}
    override fun onActivityStarted(a: Activity) {}
    override fun onActivityStopped(a: Activity) {}
    override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
    override fun onActivityDestroyed(a: Activity) { bars.remove(a) }
}

/** Decorative animated equaliser bars (not a real spectrum analyser). */
class MiniEqView(context: Context) : View(context) {
    var active = false
        set(v) { field = v; startTick() }
    private val n = 18
    private val levels = FloatArray(n) { 0.12f }
    private val phase = FloatArray(n) { it * 0.85f }
    private val speed = FloatArray(n) { 0.004f + (it % 5) * 0.0013f }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            val t = SystemClock.uptimeMillis().toDouble()
            var moving = false
            for (i in 0 until n) {
                val target = if (active) 0.22f + 0.78f * abs(sin(t * speed[i] + phase[i])).toFloat() else 0.1f
                levels[i] += (target - levels[i]) * 0.3f
                if (levels[i] > 0.13f) moving = true
            }
            invalidate()
            if (isAttachedToWindow && (active || moving)) postDelayed(this, 40) else running = false
        }
    }
    private fun startTick() { if (!running && isAttachedToWindow) { running = true; post(tick) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); startTick() }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        paint.shader = LinearGradient(0f, h.toFloat(), 0f, 0f, Color.rgb(98, 228, 211), Color.rgb(140, 120, 255), Shader.TileMode.CLAMP)
    }
    override fun onDraw(canvas: Canvas) {
        val gap = width / n.toFloat()
        val bw = gap * 0.56f
        for (i in 0 until n) {
            val h = (levels[i] * height).coerceAtLeast(bw)
            val x = i * gap + (gap - bw) / 2
            canvas.drawRoundRect(x, height - h, x + bw, height.toFloat(), bw / 2, bw / 2, paint)
        }
    }
}

/** Floating "now playing" card: album art, title, animated equaliser, play/pause, next, close and a thin progress line. */
class MiniPlayerBar(private val activity: Activity) : FrameLayout(activity) {
    private val accent = Color.rgb(98, 228, 211)
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    val barHeight = dp(84)
    var onVisibilityChange: ((Boolean) -> Unit)? = null
    var restorePadding: (() -> Unit)? = null
    private var shown = false

    private val art = ImageView(context)
    private val title = TextView(context)
    private val eq = MiniEqView(context)
    private val timeText = TextView(context)
    private val playBtn = ImageButton(context)
    private val progress = View(context)
    private val card = FrameLayout(context)
    private val handler = Handler(Looper.getMainLooper())

    private val keeperListener: () -> Unit = { refresh() }
    private val ticker = object : Runnable {
        override fun run() { updateProgress(); if (isAttachedToWindow) handler.postDelayed(this, 500) }
    }

    init {
        clipChildren = false
        clipToPadding = false
        setPadding(dp(8), dp(6), dp(8), dp(8))
        visibility = View.GONE

        card.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(22, 30, 58), Color.rgb(14, 56, 68))).apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.argb(90, 98, 228, 211))
        }
        card.elevation = dp(10).toFloat()
        card.outlineProvider = ViewOutlineProvider.BACKGROUND
        card.clipToOutline = true
        card.isClickable = true
        card.setOnClickListener { openPlayer() }

        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(6), dp(3)) }

        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat()) }
        }
        art.clipToOutline = true
        row.addView(art, LinearLayout.LayoutParams(dp(52), dp(52)))

        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(6), 0) }
        title.apply {
            setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); typeface = Typeface.DEFAULT_BOLD
            isSingleLine = true; ellipsize = TextUtils.TruncateAt.MARQUEE; marqueeRepeatLimit = -1; isSelected = true
        }
        col.addView(title, LinearLayout.LayoutParams(-1, -2))
        val eqRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        eqRow.addView(eq, LinearLayout.LayoutParams(dp(86), dp(16)))
        timeText.apply { setTextColor(Color.rgb(160, 176, 205)); setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f); setPadding(dp(10), 0, 0, 0) }
        eqRow.addView(timeText, LinearLayout.LayoutParams(-2, -2))
        col.addView(eqRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))

        playBtn.apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
            imageTintList = ColorStateList.valueOf(Color.rgb(8, 16, 24))
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(9), dp(9), dp(9), dp(9))
            contentDescription = "Play/Pause"
            setOnClickListener { AudioKeeper.toggle() }
        }
        row.addView(playBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(4) })
        row.addView(smallButton(R.drawable.ic_next, "Next") { AudioKeeper.next() }, LinearLayout.LayoutParams(dp(38), dp(38)))
        row.addView(smallButton(R.drawable.ic_close, "Close") { AudioKeeper.discard() }, LinearLayout.LayoutParams(dp(36), dp(36)))
        card.addView(row, LayoutParams(-1, -1))

        progress.setBackgroundColor(accent)
        card.addView(progress, LayoutParams(0, dp(3), Gravity.BOTTOM or Gravity.START))
        addView(card, LayoutParams(-1, -1))
    }

    private fun smallButton(res: Int, desc: String, onClick: () -> Unit) = ImageButton(context).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(Color.WHITE)
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(9), dp(9), dp(9), dp(9))
        contentDescription = desc
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), null, mask)
        setOnClickListener { onClick() }
    }

    private fun openPlayer() {
        val uri = AudioKeeper.currentUri ?: return
        try {
            activity.startActivity(
                Intent(activity, MediaActivity::class.java)
                    .setDataAndType(uri, "audio/*")
                    .putExtra("adopt", true)
                    .putExtra("mime", "audio/*")
                    .putExtra("name", AudioKeeper.currentName)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Throwable) { }
    }

    private fun updateProgress() {
        val p = AudioKeeper.session?.player ?: return
        try {
            val dur = p.duration
            val pos = p.currentPosition
            if (dur != C.TIME_UNSET && dur > 0) {
                timeText.text = MediaFmt.time(pos) + " / " + MediaFmt.time(dur)
                val w = ((card.width) * (pos.coerceIn(0, dur).toFloat() / dur)).toInt()
                val lp = progress.layoutParams
                if (lp.width != w) { lp.width = w; progress.layoutParams = lp }
            } else timeText.text = MediaFmt.time(pos)
        } catch (_: Throwable) { }
    }

    private fun refresh() {
        val s = AudioKeeper.session
        val show = s != null
        if (!show) {
            visibility = View.GONE
            eq.active = false
            if (shown) { shown = false; onVisibilityChange?.invoke(false) }
            return
        }
        visibility = View.VISIBLE
        if (!shown) { shown = true; onVisibilityChange?.invoke(true) }
        title.text = AudioKeeper.displayTitle
        val bmp = AudioKeeper.art
        if (bmp != null) { art.imageTintList = null; art.setPadding(0, 0, 0, 0); art.setImageBitmap(bmp) }
        else {
            art.setImageResource(R.drawable.ic_music)
            art.imageTintList = ColorStateList.valueOf(Color.argb(210, 147, 197, 253))
            art.setPadding(dp(13), dp(13), dp(13), dp(13))
            art.setBackgroundColor(Color.rgb(30, 41, 75))
        }
        val playing = AudioKeeper.isPlaying
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        eq.active = playing
        updateProgress()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        AudioKeeper.addListener(keeperListener)
        refresh()
        handler.post(ticker)
    }

    override fun onDetachedFromWindow() {
        AudioKeeper.removeListener(keeperListener)
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }
}
