package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.security.MessageDigest
import java.util.Locale

class AppLockerActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("omnihub_app_locker", MODE_PRIVATE) }
    private val bg = Color.rgb(242, 240, 247)
    private val panel = Color.rgb(252, 251, 254)
    private val text = Color.rgb(37, 34, 47)
    private val muted = Color.rgb(94, 88, 112)
    private val accent = Color.rgb(102, 80, 196)
    private lateinit var status: TextView
    private lateinit var adapter: AppsAdapter
    private val apps = mutableListOf<ApplicationInfo>()
    private val locked = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = Color.rgb(252, 251, 254)
        if (android.os.Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        locked.addAll(prefs.getStringSet("locked_packages", emptySet()) ?: emptySet())
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(10)); setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(button("‹") { finish() }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(5) })
        header.addView(HomeNavigation.makeHomeButton(this), LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(10) })
        header.addView(TextView(this).apply { this.text = "App Locker"; textSize = 25f; setTextColor(this@AppLockerActivity.text); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(header, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(TextView(this).apply { this.text = "Choose apps or games to protect. Android requires you to enable OmniHub's Accessibility service for automatic lock detection."; textSize = 13f; setTextColor(muted); setPadding(0, 0, 0, dp(10)) })
        status = TextView(this).apply { textSize = 12f; setTextColor(accent); setPadding(0, 0, 0, dp(8)) }
        root.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Set / Change PIN") { promptSetPin() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(6) })
        row.addView(button("Biometric info") { showBiometricInfo() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(row)
        root.addView(button("Enable auto-lock service") { openAccessibilitySettings() }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        root.addView(button("Save selected apps") { saveSelection() }, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(8) })
        val list = ListView(this).apply { divider = android.graphics.drawable.ColorDrawable(Color.rgb(218, 213, 230)); dividerHeight = dp(1); setBackgroundColor(Color.rgb(252, 251, 254)) }
        adapter = AppsAdapter(); list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("Done") { finish() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })
        setContentView(root)
        InsetsUtil.apply(this, root)
        if (android.os.Build.VERSION.SDK_INT >= 23) androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply { isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true }
        loadApps(); updateStatus()
    }

    private fun loadApps() {
        apps.clear()
        try {
            val own = packageName
            packageManager.getInstalledApplications(0).filter { it.packageName != own && packageManager.getLaunchIntentForPackage(it.packageName) != null }
                .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase(Locale.ROOT) }.forEach { apps.add(it) }
        } catch (_: Exception) { }
        adapter.notifyDataSetChanged()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }

    private fun updateStatus() {
        val on = isServiceEnabled()
        status.setTextColor(if (on) accent else Color.rgb(255, 176, 120))
        val base = "${locked.size} app(s) selected · PIN ${if (prefs.getString("pin_hash", null).isNullOrBlank()) "not set" else "configured"}"
        status.text = if (on) "$base · auto-lock ON ✓" else "$base\n⚠ Auto-lock is OFF — selected apps are NOT protected yet. Tap \"Enable auto-lock service\" below."
    }

    private fun openAccessibilitySettings() {
        AlertDialog.Builder(this).setTitle("Turn on auto-lock")
            .setMessage("1. Open Accessibility → Installed apps (or Downloaded apps) → OmniHub App Lock Service → switch ON.\n\nIf the switch is greyed out: Settings → Apps → OmniHub → ⋮ menu → \"Allow restricted settings\", then try again.\n\nOn Oppo / Realme / Vivo / Xiaomi phones also allow OmniHub to auto-start and set battery usage to \"Unrestricted\", otherwise the system may stop the lock service.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Open settings") { _, _ -> try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) { } }
            .show()
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("AppLockAccessibilityService", true)
    }

    private fun promptSetPin() {
        val input = EditText(this).apply { hint = "Create a 4–12 digit PIN"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Set App Locker PIN").setMessage("Use a PIN you can remember. It is stored as a one-way hash on this device.").setView(input)
            .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val pin = input.text.toString()
                if (pin.length !in 4..12 || !pin.all { it.isDigit() }) Toast.makeText(this, "PIN must be 4–12 digits", Toast.LENGTH_LONG).show()
                else { prefs.edit().putString("pin_hash", hash(pin)).apply(); updateStatus(); Toast.makeText(this, "PIN saved", Toast.LENGTH_SHORT).show() }
            }.show()
    }

    private fun showBiometricInfo() {
        val msg = if (android.os.Build.VERSION.SDK_INT >= 28) "The lock screen offers Android system biometric authentication when the device has a supported biometric enrolled, plus the PIN fallback. Availability depends on Android/device security settings." else "This Android version uses the OmniHub PIN fallback. Biometric prompt support requires Android 9 or newer in this build."
        AlertDialog.Builder(this).setTitle("Biometric unlock").setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun saveSelection() {
        prefs.edit().putStringSet("locked_packages", locked.toSet()).apply()
        updateStatus()
        when {
            prefs.getString("pin_hash", null).isNullOrBlank() -> { Toast.makeText(this, "Saved — now set a PIN", Toast.LENGTH_LONG).show(); promptSetPin() }
            !isServiceEnabled() -> openAccessibilitySettings()
            else -> Toast.makeText(this, "Saved ${locked.size} protected app(s)", Toast.LENGTH_LONG).show()
        }
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = apps[position].packageName.hashCode().toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val app = getItem(position)
            val row = LinearLayout(this@AppLockerActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
            val icon = android.widget.ImageView(this@AppLockerActivity).apply {
                try { setImageDrawable(packageManager.getApplicationIcon(app)) }
                catch (_: Exception) { setImageResource(android.R.drawable.sym_def_app_icon) }
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            row.addView(TextView(this@AppLockerActivity).apply { text = packageManager.getApplicationLabel(app).toString(); setTextColor(this@AppLockerActivity.text); textSize = 14f; setPadding(dp(10), 0, dp(4), 0) }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(CheckBox(this@AppLockerActivity).apply {
                buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                isChecked = app.packageName in locked
                setOnCheckedChangeListener { _, checked -> if (checked) locked.add(app.packageName) else locked.remove(app.packageName); updateStatus() }
            })
            return row
        }
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; textSize = 12f; setTextColor(if (label == "Save selected apps") Color.WHITE else this@AppLockerActivity.text); backgroundTintList = android.content.res.ColorStateList.valueOf(if (label == "Save selected apps") accent else panel); setOnClickListener { action() } }
    private fun hash(pin: String) = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
