package com.example.omnihub

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.LruCache
import android.util.Size
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/** Lightweight MediaStore reader used by the Home music card and the Media Lab previews. */
object MediaCatalog {
    private const val THUMB = 256
    private val cache = object : LruCache<String, String>(3 * 1024 * 1024) {
        override fun sizeOf(key: String, value: String): Int = value.length
    }

    fun hasAccess(ctx: Context): Boolean = try {
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else if (Build.VERSION.SDK_INT >= 23) ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        else true
    } catch (_: Exception) { false }

    fun list(ctx: Context, kind: String, limit: Int): JSONObject {
        val out = JSONObject()
        val arr = JSONArray()
        out.put("items", arr)
        if (!hasAccess(ctx)) { out.put("access", false); out.put("total", 0); return out }
        out.put("access", true)
        val audio = kind == "audio"
        val video = kind == "video"
        val uri = when {
            audio -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            video -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val proj = ArrayList<String>()
        proj.add(MediaStore.MediaColumns._ID)
        proj.add(MediaStore.MediaColumns.DATA)
        proj.add(MediaStore.MediaColumns.DISPLAY_NAME)
        if (audio) {
            proj.add(MediaStore.Audio.Media.TITLE)
            proj.add(MediaStore.Audio.Media.ARTIST)
            proj.add(MediaStore.Audio.Media.ALBUM)
            proj.add(MediaStore.Audio.Media.ALBUM_ID)
            proj.add(MediaStore.Audio.Media.DURATION)
            proj.add(MediaStore.Audio.Media.TRACK)
        } else if (video) {
            proj.add(MediaStore.Video.Media.DURATION)
        }
        var total = 0
        fun run(selection: String?) {
            total = 0
            while (arr.length() > 0) arr.remove(arr.length() - 1)
            val cursor = ctx.contentResolver.query(uri, proj.toTypedArray(), selection, null, MediaStore.MediaColumns.DATE_ADDED + " DESC") ?: return
            cursor.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iData = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iTitle = if (audio) c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE) else -1
                val iArtist = if (audio) c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST) else -1
                val iAlbum = if (audio) c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM) else -1
                val iAlbumId = if (audio) c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID) else -1
                val iTrack = if (audio) c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK) else -1
                val iDur = if (audio) c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION) else if (video) c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION) else -1
                while (c.moveToNext()) {
                    val path = c.getString(iData) ?: continue
                    if (path.contains("/.")) continue
                    total++
                    if (arr.length() >= limit) continue
                    val fileName = (c.getString(iName) ?: File(path).name).substringBeforeLast('.')
                    val o = JSONObject()
                    o.put("id", c.getLong(iId))
                    o.put("p", path)
                    var title = if (audio) (c.getString(iTitle) ?: "") else fileName
                    if (title.isBlank()) title = fileName
                    o.put("t", title)
                    if (audio) {
                        o.put("a", clean(c.getString(iArtist), "Unknown artist"))
                        o.put("al", clean(c.getString(iAlbum), "Unknown album"))
                        o.put("alId", c.getLong(iAlbumId))
                        o.put("n", c.getInt(iTrack) % 1000)
                        val parent = File(path).parentFile
                        o.put("f", parent?.name ?: "")
                        o.put("fp", parent?.absolutePath ?: "")
                    }
                    if (iDur >= 0) o.put("d", c.getLong(iDur))
                    arr.put(o)
                }
            }
        }
        try {
            if (audio) {
                run(MediaStore.Audio.Media.IS_MUSIC + " != 0")
                if (total == 0) run(null)
            } else run(null)
        } catch (_: SecurityException) {
            out.put("access", false)
        }
        out.put("total", total)
        return out
    }

    private fun clean(v: String?, fallback: String): String =
        if (v.isNullOrBlank() || v == "<unknown>") fallback else v

    /** Returns a small JPEG data-URI or null when no artwork exists. */
    fun thumb(ctx: Context, kind: String, id: Long, path: String, albumId: Long): String? {
        val ck = kind + ":" + (if (kind == "audio" && albumId > 0) "a$albumId" else "i$id")
        val hit = cache.get(ck)
        if (hit != null) return if (hit.isEmpty()) null else hit
        val bmp = try { makeBitmap(ctx, kind, id, path) } catch (_: Throwable) { null }
        val enc = if (bmp != null) encode(bmp) else null
        cache.put(ck, enc ?: "")
        return enc
    }

    @Suppress("DEPRECATION")
    private fun makeBitmap(ctx: Context, kind: String, id: Long, path: String): Bitmap? {
        val base = when (kind) {
            "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val b = ctx.contentResolver.loadThumbnail(ContentUris.withAppendedId(base, id), Size(THUMB, THUMB), null)
                if (b != null) return b
            } catch (_: Throwable) { }
        } else if (kind != "audio") {
            try {
                val cr = ctx.contentResolver
                val b = if (kind == "video") MediaStore.Video.Thumbnails.getThumbnail(cr, id, MediaStore.Video.Thumbnails.MINI_KIND, null)
                else MediaStore.Images.Thumbnails.getThumbnail(cr, id, MediaStore.Images.Thumbnails.MINI_KIND, null)
                if (b != null) return b
            } catch (_: Throwable) { }
        }
        return when (kind) {
            "audio" -> embeddedArt(path) ?: folderCover(path)
            "video" -> videoFrame(path)
            else -> decodeFile(path)
        }
    }

    private fun embeddedArt(path: String): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            val bytes = r.embeddedPicture
            if (bytes == null) null else decodeBytes(bytes)
        } catch (_: Throwable) { null } finally { try { r.release() } catch (_: Throwable) { } }
    }

    private fun folderCover(path: String): Bitmap? {
        val dir = File(path).parentFile ?: return null
        for (n in listOf("cover.jpg", "folder.jpg", "Folder.jpg", "cover.png", "albumart.jpg", "AlbumArt.jpg", "front.jpg")) {
            val f = File(dir, n)
            if (f.isFile) { val b = decodeFile(f.absolutePath); if (b != null) return b }
        }
        return null
    }

    private fun videoFrame(path: String): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0L)
        } catch (_: Throwable) { null } finally { try { r.release() } catch (_: Throwable) { } }
    }

    private fun sampleFor(w: Int, h: Int): Int {
        var s = 1
        while (w / (s * 2) >= THUMB && h / (s * 2) >= THUMB) s *= 2
        return s
    }

    private fun decodeFile(path: String): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        val o2 = BitmapFactory.Options().apply { inSampleSize = sampleFor(o.outWidth, o.outHeight) }
        return BitmapFactory.decodeFile(path, o2)
    }

    private fun decodeBytes(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        val o2 = BitmapFactory.Options().apply { inSampleSize = sampleFor(o.outWidth, o.outHeight) }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    private fun encode(src: Bitmap): String {
        val big = maxOf(src.width, src.height)
        val bmp = if (big > THUMB) {
            val f = THUMB.toFloat() / big
            Bitmap.createScaledBitmap(src, maxOf(1, (src.width * f).toInt()), maxOf(1, (src.height * f).toInt()), true)
        } else src
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 74, bos)
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }
}
