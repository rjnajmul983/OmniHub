package com.example.omnihub

import com.github.luben.zstd.ZstdInputStream
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.FileHeader
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionLevel
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.apache.commons.compress.archivers.ArchiveEntry as CommonsArchiveEntry
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.ArchiveStreamFactory
import org.apache.commons.compress.archivers.ar.ArArchiveEntry
import org.apache.commons.compress.archivers.cpio.CpioArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.lzma.LZMACompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.zstandard.ZstdCompressorInputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.charset.Charset
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/** UI-free archive operations. Always run these functions on a worker thread. */
object ArchiveManager {
    const val MAX_ENTRIES = 50_000
    const val MAX_EXTRACTED_BYTES = 4L * 1024L * 1024L * 1024L
    const val ZIP_BOMB_RATIO_WARNING = 200L

    data class Progress(
        val completedBytes: Long = 0,
        val totalBytes: Long = -1,
        val completedEntries: Int = 0,
        val totalEntries: Int = -1,
        val currentEntry: String = ""
    )

    data class Entry(
        val name: String,
        val isDirectory: Boolean,
        val size: Long = -1L,
        val compressedSize: Long = -1L
    )

    enum class ConflictAction { REPLACE, KEEP_BOTH, SKIP }
    data class ConflictDecision(val action: ConflictAction, val applyToAll: Boolean = false, val merge: Boolean = false, val cancelled: Boolean = false)
    class CancelToken {
        @Volatile var isCancelled: Boolean = false
            private set
        fun cancel() { isCancelled = true }
        fun throwIfCancelled() { if (isCancelled || Thread.currentThread().isInterrupted) throw InterruptedException("Archive operation cancelled") }
    }

    data class Result(val completedEntries: Int, val completedBytes: Long, val skippedEntries: Int = 0)

    private data class EntryRef(val entry: Entry, val native: Any? = null)

    private val splitSevenZipCache = ConcurrentHashMap<String, File>()
    private val archiveExtensions = setOf("zip", "rar", "7z", "tar", "tgz", "gz", "bz2", "xz", "zst", "jar", "apk", "iso", "lzma", "ar", "cpio")

    fun isArchive(file: File): Boolean {
        val n = file.name.lowercase(Locale.ROOT)
        return archiveExtensions.any { n.endsWith(".$it") } ||
            n.endsWith(".tar.gz") || n.endsWith(".tar.bz2") || n.endsWith(".tar.xz") ||
            Regex(".*\\.part\\d+\\.rar$", RegexOption.IGNORE_CASE).matches(file.name) ||
            Regex(".*\\.7z\\.\\d{3}$", RegexOption.IGNORE_CASE).matches(file.name) ||
            Regex(".*\\.z\\d{2}$", RegexOption.IGNORE_CASE).matches(file.name)
    }

    /** Returns a logical listing for supported archive formats, including basic ISO-9660 images. */
    @Throws(IOException::class)
    fun listEntries(archive: File, password: String? = null): List<Entry> {
        require(archive.isFile && archive.canRead()) { "Archive is not readable" }
        val primary = resolveFirstPart(archive)
        val ext = effectiveExtension(primary)
        return when {
            ext == "iso" -> isoRefs(primary).map { it.entry }
            isZipExtension(ext) -> zipRefs(primary, password).map { it.entry }
            ext == "rar" -> rarRefs(primary, password).map { it.entry }
            ext == "7z" -> sevenZipRefs(primary, password).map { it.entry }
            isArchiveStreamExtension(ext) -> streamRefs(primary, ext).map { it.entry }
            isCompressedStreamExtension(ext) -> listOf(Entry(stripSingleCompressionSuffix(primary.name), false, -1L, primary.length()))
            else -> throw UnsupportedOperationException("Unsupported archive format: .$ext")
        }
    }

    /** Archives whose contents can be edited in place (currently ZIP-family only). */
    fun canEditInPlace(archive: File): Boolean {
        val n = archive.name.lowercase(Locale.ROOT)
        return archive.isFile && (n.endsWith(".zip") || n.endsWith(".jar")) && !Regex(".*\\.z\\d{2}$").matches(n)
    }

    /** Removes the given entries (a folder also removes everything inside it) from a ZIP. Run on a worker thread. */
    @Throws(IOException::class)
    fun deleteEntries(archive: File, entryPaths: Set<String>, password: String? = null): Int {
        require(canEditInPlace(archive)) { "Deleting inside an archive is supported for ZIP files only" }
        val charset = bestZipCharset(archive, password)
        val zip = openZip(archive, password, charset)
        var removed = 0
        try {
            val headers = zip.fileHeaders ?: emptyList<FileHeader>()
            val doomed = headers.filter { h ->
                val name = h.fileName.replace('\\', '/').trimEnd('/')
                entryPaths.any { p -> val q = p.replace('\\', '/').trimEnd('/'); name == q || name.startsWith("$q/") }
            }
            if (doomed.isNotEmpty()) { zip.removeFiles(doomed.map { it.fileName }); removed = doomed.size }
        } finally { try { zip.close() } catch (_: Exception) { } }
        return removed
    }

    /**
     * Extracts securely. Existing files default to Keep Both unless the caller provides a dialog-backed resolver.
     * ZIP paths are read through streams rather than asking the library to write files, so each output is validated here.
     */
    @Throws(IOException::class, InterruptedException::class)
    fun extract(
        archive: File,
        destDir: File,
        password: String? = null,
        onProgress: (Progress) -> Unit = {},
        cancelToken: CancelToken = CancelToken(),
        conflictResolver: ((existing: File, incoming: Entry) -> ConflictDecision)? = null,
        selectedEntryNames: Set<String>? = null,
        flattenToSelection: Boolean = false
    ): Result {
        require(archive.isFile && archive.canRead()) { "Archive is not readable" }
        if (!destDir.exists() && !destDir.mkdirs()) throw IOException("Could not create destination directory")
        require(destDir.isDirectory && destDir.canWrite()) { "Destination directory is not writable" }
        val canonicalRoot = destDir.canonicalFile
        cancelToken.throwIfCancelled()
        val primary = resolveFirstPart(archive, cancelToken)
        val ext = effectiveExtension(primary)

        // A null selection preserves full extraction. A selected directory also includes its descendants.
        fun isSelected(name: String): Boolean = selectedEntryNames == null || selectedEntryNames.any { chosen ->
            val normalized = chosen.replace('\\', '/').trimEnd('/')
            val candidate = name.replace('\\', '/')
            candidate == normalized || candidate.startsWith("$normalized/") || normalized.startsWith("$candidate/")
        }

        var totalBytes = 0L
        var completedBytes = 0L
        var completed = 0
        var skipped = 0
        var allDecision: ConflictAction? = null
        var allMerge: Boolean? = null
        // Folders the user chose to skip / merge; everything below them follows that choice without asking again.
        val skippedDirs = HashSet<String>()
        val mergedDirs = HashSet<String>()
        fun abortIfCancelled(d: ConflictDecision) {
            if (d.cancelled) { cancelToken.cancel(); throw InterruptedException("Archive operation cancelled") }
        }
        val ask: (File, Entry) -> ConflictAction = { existing, incoming ->
            if (allDecision != null) allDecision!! else {
                val decision = conflictResolver?.invoke(existing, incoming)
                    ?: ConflictDecision(ConflictAction.KEEP_BOTH)
                abortIfCancelled(decision)
                if (decision.applyToAll) allDecision = decision.action
                decision.action
            }
        }
        fun askMerge(existing: File, incoming: Entry): Boolean {
            allMerge?.let { return it }
            val d = conflictResolver?.invoke(existing, incoming) ?: ConflictDecision(ConflictAction.KEEP_BOTH, merge = true)
            abortIfCancelled(d)
            val merge = d.merge && d.action != ConflictAction.SKIP
            if (d.applyToAll) allMerge = merge
            return merge
        }
        /** Returns false when this entry sits inside (or is) an existing, non-empty folder the user chose to skip. */
        fun gate(name: String, isDir: Boolean): Boolean {
            val parts = name.replace('\\', '/').split('/').filter { it.isNotEmpty() }
            val depth = if (isDir) parts.size else parts.size - 1
            var prefix = ""
            for (i in 0 until depth) {
                prefix = if (prefix.isEmpty()) parts[i] else prefix + "/" + parts[i]
                if (prefix in skippedDirs) return false
                if (prefix in mergedDirs) return true
                val dir = File(canonicalRoot, prefix)
                if (!dir.exists()) return true
                if (dir.isDirectory && dir.list()?.isNotEmpty() == true) {
                    if (askMerge(dir, Entry(prefix, true))) { mergedDirs += prefix; return true }
                    skippedDirs += prefix
                    return false
                }
            }
            return true
        }

        // When copying chosen items out of an archive, each chosen item lands directly in the destination (no full inner path).
        fun rewriteForSelection(e: Entry): Entry? {
            val chosenList = selectedEntryNames ?: return e
            val n = e.name.replace('\\', '/')
            for (chosen in chosenList) {
                val c = chosen.replace('\\', '/').trimEnd('/')
                if (n.trimEnd('/') == c || n.startsWith("$c/")) {
                    val base = c.substringBeforeLast('/', "")
                    return e.copy(name = if (base.isEmpty()) n else n.removePrefix("$base/"))
                }
            }
            return null
        }

        fun writeEntry(rawEntry: Entry, inputFactory: (() -> InputStream)?) {
            val entry = if (flattenToSelection) (rewriteForSelection(rawEntry) ?: return) else rawEntry
            cancelToken.throwIfCancelled()
            if (isUnsafeName(entry.name)) { skipped++; completed++; return }
            if (isSymlinkNameOrNative(entry.name, null)) { skipped++; completed++; return }
            if (!gate(entry.name, entry.isDirectory)) { skipped++; completed++; return }
            if (!entry.isDirectory && entry.size > MAX_EXTRACTED_BYTES) throw IOException("Entry exceeds extraction safety limit")
            val target = safeTarget(canonicalRoot, entry.name)
            if (entry.isDirectory) {
                if (!target.exists() && !target.mkdirs()) throw IOException("Could not create directory")
                assertInside(canonicalRoot, target)
                completed++
                onProgress(Progress(completedBytes, totalBytes, completed, -1, entry.name))
                return
            }
            // totalBytes is populated from archive headers where available; actual written bytes are independently capped below.
            if (totalBytes > MAX_EXTRACTED_BYTES) throw IOException("Archive exceeds the extraction size safety limit")
            if (entry.size > 0 && entry.compressedSize > 0 && entry.size / entry.compressedSize.coerceAtLeast(1) > ZIP_BOMB_RATIO_WARNING) {
                // This is a strong warning threshold, not a hard rejection; runtime byte caps still enforce safety.
            }
            val parent = target.parentFile ?: canonicalRoot
            if (!parent.exists() && !parent.mkdirs()) throw IOException("Could not create output directory")
            assertInside(canonicalRoot, target)
            var output = target
            if (output.exists()) {
                when (ask(output, entry)) {
                    ConflictAction.SKIP -> { skipped++; completed++; return }
                    ConflictAction.REPLACE -> {
                        if (output.isDirectory && output.listFiles()?.isNotEmpty() == true) throw IOException("Cannot replace a non-empty directory with a file")
                        if (!output.delete()) throw IOException("Could not replace existing item")
                    }
                    ConflictAction.KEEP_BOTH -> output = keepBothPath(output)
                }
            }
            assertInside(canonicalRoot, output)
            val source = inputFactory?.invoke() ?: throw IOException("No stream for archive entry")
            source.use { input ->
                BufferedOutputStream(FileOutputStream(output)).use { out ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 2)
                    while (true) {
                        cancelToken.throwIfCancelled()
                        val count = input.read(buffer)
                        if (count < 0) break
                        completedBytes += count
                        if (completedBytes > MAX_EXTRACTED_BYTES) throw IOException("Archive expands beyond the extraction safety limit")
                        out.write(buffer, 0, count)
                        onProgress(Progress(completedBytes, totalBytes, completed, -1, entry.name))
                    }
                }
            }
            completed++
            onProgress(Progress(completedBytes, totalBytes, completed, -1, entry.name))
        }

        when {
            ext == "iso" -> {
                val refs = isoRefs(primary)
                enforceEntryLimit(refs.size)
                totalBytes = refs.filter { isSelected(it.entry.name) }.sumOf { it.entry.size.coerceAtLeast(0L) }
                validateDeclaredSize(totalBytes, primary.length(), destDir)
                refs.forEach { ref ->
                    cancelToken.throwIfCancelled()
                    if (!isSelected(ref.entry.name)) { skipped++; completed++; return@forEach }
                    if (ref.entry.isDirectory) writeEntry(ref.entry, null)
                    else writeEntry(ref.entry) { isoInput(primary, ref.native as IsoLocation) }
                }
            }
            isZipExtension(ext) -> {
                val zip = openZip(primary, password, bestZipCharset(primary, password))
                try {
                    val headers = zip.fileHeaders ?: emptyList<FileHeader>()
                    enforceEntryLimit(headers.size)
                    val chosenHeaders = headers.filter { isSelected(it.fileName) }
                    val declared = chosenHeaders.sumOf { (it.uncompressedSize ?: 0L).coerceAtLeast(0L) }
                    val compressed = chosenHeaders.sumOf { (it.compressedSize ?: 0L).coerceAtLeast(0L) }
                    validateDeclaredSize(declared, compressed, destDir)
                    totalBytes = declared
                    headers.forEach { h ->
                        cancelToken.throwIfCancelled()
                        val entry = Entry(h.fileName, h.isDirectory, h.uncompressedSize, h.compressedSize)
                        if (!isSelected(h.fileName)) { skipped++; completed++; return@forEach }
                        if (isSymlinkNameOrNative(h.fileName, h)) { skipped++; completed++; return@forEach }
                        writeEntry(entry) { zip.getInputStream(h) }
                    }
                } finally { zip.close() }
            }
            ext == "rar" -> {
                val refs = rarRefs(primary, password)
                enforceEntryLimit(refs.size)
                totalBytes = refs.filter { isSelected(it.entry.name) }.sumOf { it.entry.size.coerceAtLeast(0L) }
                validateDeclaredSize(totalBytes, -1L, destDir)
                refs.forEach { ref ->
                    cancelToken.throwIfCancelled()
                    val target = safeTarget(canonicalRoot, ref.entry.name)
                    if (!isSelected(ref.entry.name)) { skipped++; completed++; return@forEach }
                    if (isSymlinkNameOrNative(ref.entry.name, ref.native)) { skipped++; completed++; return@forEach }
                    writeEntry(ref.entry) { rarInput(primary, password, ref.entry.name) }
                }
            }
            ext == "7z" -> {
                val entries = mutableListOf<Entry>()
                openSevenZ(primary, password).use { scanner ->
                    for (e in scanner.getEntries()) {
                        cancelToken.throwIfCancelled()
                        entries += Entry(e.name, e.isDirectory, e.size, -1L)
                        if (entries.size > MAX_ENTRIES) throw IOException("Archive contains too many entries")
                    }
                }
                totalBytes = entries.filter { isSelected(it.name) }.sumOf { it.size.coerceAtLeast(0L) }
                validateDeclaredSize(totalBytes, primary.length(), destDir)
                // Reopen the archive and advance/read every entry in order; SevenZFile is sequential.
                openSevenZ(primary, password).use { seven ->
                    entries.forEach { listed ->
                        cancelToken.throwIfCancelled()
                        val e = seven.nextEntry ?: throw IOException("Unexpected end of 7z archive")
                        if (e.name != listed.name) throw IOException("7z entry order changed while reading")
                        val entry = Entry(e.name, e.isDirectory, e.size, -1L)
                        if (!isSelected(e.name)) {
                            drainSevenEntry(seven, cancelToken)
                            skipped++; completed++
                            return@forEach
                        }
                        if (isSymlinkNameOrNative(e.name, e)) {
                            drainSevenEntry(seven, cancelToken)
                            skipped++; completed++
                            return@forEach
                        }
                        val target = safeTarget(canonicalRoot, e.name)
                        if (entry.isDirectory) {
                            writeEntry(entry, null)
                            return@forEach
                        }
                        if (!gate(e.name, false)) { drainSevenEntry(seven, cancelToken); skipped++; completed++; return@forEach }
                        val parent = target.parentFile ?: canonicalRoot
                        if (!parent.exists() && !parent.mkdirs()) throw IOException("Could not create output directory")
                        var output = target
                        if (output.exists()) when (ask(output, entry)) {
                            ConflictAction.SKIP -> {
                                drainSevenEntry(seven, cancelToken)
                                skipped++; completed++
                                return@forEach
                            }
                            ConflictAction.REPLACE -> {
                                if (output.isDirectory && output.listFiles()?.isNotEmpty() == true) throw IOException("Cannot replace a non-empty directory with a file")
                                if (!output.delete()) throw IOException("Could not replace existing item")
                            }
                            ConflictAction.KEEP_BOTH -> output = keepBothPath(output)
                        }
                        assertInside(canonicalRoot, output)
                        BufferedOutputStream(FileOutputStream(output)).use { out ->
                            val buf = ByteArray(DEFAULT_BUFFER_SIZE * 2)
                            while (true) {
                                cancelToken.throwIfCancelled()
                                val n = seven.read(buf)
                                if (n < 0) break
                                completedBytes += n
                                if (completedBytes > MAX_EXTRACTED_BYTES) throw IOException("Archive expands beyond the extraction safety limit")
                                out.write(buf, 0, n)
                                onProgress(Progress(completedBytes, totalBytes, completed, entries.size, e.name))
                            }
                        }
                        completed++
                    }
                }
            }
            isArchiveStreamExtension(ext) -> {
                val refs = streamRefs(primary, ext)
                enforceEntryLimit(refs.size)
                totalBytes = refs.filter { isSelected(it.entry.name) }.sumOf { it.entry.size.coerceAtLeast(0L) }
                validateDeclaredSize(totalBytes, -1L, destDir)
                openArchiveStream(primary, ext).use { stream ->
                    var entry = stream.nextEntry
                    while (entry != null) {
                        cancelToken.throwIfCancelled()
                        val info = commonsEntry(entry)
                        if (!isSelected(info.name)) {
                            val discard = ByteArray(DEFAULT_BUFFER_SIZE * 2)
                            while (true) { cancelToken.throwIfCancelled(); if (stream.read(discard) < 0) break }
                            skipped++; completed++; entry = stream.nextEntry; continue
                        }
                        if (isSymlinkNameOrNative(info.name, entry)) { skipped++; completed++; entry = stream.nextEntry; continue }
                        if (info.isDirectory) {
                            writeEntry(info, null)
                        } else {
                            val target = safeTarget(canonicalRoot, info.name)
                            if (!gate(info.name, false)) {
                                val discard = ByteArray(DEFAULT_BUFFER_SIZE * 2)
                                while (true) { cancelToken.throwIfCancelled(); if (stream.read(discard) < 0) break }
                                skipped++; completed++; entry = stream.nextEntry; continue
                            }
                            // Stream entries must be written now, while ArchiveInputStream is positioned at this entry.
                            val parent = target.parentFile ?: canonicalRoot
                            if (!parent.exists() && !parent.mkdirs()) throw IOException("Could not create output directory")
                            var output = target
                            if (output.exists()) when (ask(output, info)) {
                                ConflictAction.SKIP -> { skipped++; completed++; entry = stream.nextEntry; continue }
                                ConflictAction.REPLACE -> { if (!output.delete()) throw IOException("Could not replace existing item") }
                                ConflictAction.KEEP_BOTH -> output = keepBothPath(output)
                            }
                            assertInside(canonicalRoot, output)
                            BufferedOutputStream(FileOutputStream(output)).use { out ->
                                val buf = ByteArray(DEFAULT_BUFFER_SIZE * 2)
                                while (true) { cancelToken.throwIfCancelled(); val n = stream.read(buf); if (n < 0) break; completedBytes += n; if (completedBytes > MAX_EXTRACTED_BYTES) throw IOException("Archive expands beyond the extraction safety limit"); out.write(buf, 0, n); onProgress(Progress(completedBytes, totalBytes, completed, refs.size, info.name)) }
                            }
                            completed++
                        }
                        onProgress(Progress(completedBytes, totalBytes, completed, refs.size, info.name))
                        entry = stream.nextEntry
                    }
                }
            }
            isCompressedStreamExtension(ext) -> {
                val name = stripSingleCompressionSuffix(primary.name)
                val entry = Entry(name, false, -1L, primary.length())
                if (!isSelected(name)) { skipped++; completed++; return Result(completed, completedBytes, skipped) }
                val target = safeTarget(canonicalRoot, name)
                val parent = target.parentFile ?: canonicalRoot
                if (!parent.exists() && !parent.mkdirs()) throw IOException("Could not create output directory")
                var output = target
                if (output.exists()) when (ask(output, entry)) {
                    ConflictAction.SKIP -> { skipped++; completed++ }
                    ConflictAction.REPLACE -> { if (!output.delete()) throw IOException("Could not replace existing item") }
                    ConflictAction.KEEP_BOTH -> output = keepBothPath(output)
                }
                if (completed == 0 || output != target || !target.exists()) {
                    assertInside(canonicalRoot, output)
                    openCompressedStream(primary, ext).use { input -> BufferedOutputStream(FileOutputStream(output)).use { out ->
                        val buf = ByteArray(DEFAULT_BUFFER_SIZE * 2)
                        while (true) { cancelToken.throwIfCancelled(); val n = input.read(buf); if (n < 0) break; completedBytes += n; if (completedBytes > MAX_EXTRACTED_BYTES) throw IOException("Stream exceeds extraction safety limit"); out.write(buf, 0, n); onProgress(Progress(completedBytes, -1, completed, 1, name)) }
                    } }
                    completed++
                }
            }
            else -> throw UnsupportedOperationException("Unsupported archive format: .$ext")
        }
        return Result(completed, completedBytes, skipped)
    }

    /** Compresses using ZIP (optionally AES-256), 7z, or TAR.GZ. RAR creation is intentionally not implemented. */
    @Throws(IOException::class, InterruptedException::class)
    fun compress(
        files: List<File>,
        destArchive: File,
        format: String,
        level: Int = 5,
        password: String? = null,
        onProgress: (Progress) -> Unit = {},
        cancelToken: CancelToken = CancelToken(),
        splitSizeBytes: Long? = null
    ): Result {
        val inputs = files.map { it.canonicalFile }.filter { it.exists() && it.canRead() && it != destArchive.canonicalFile && !it.isSymbolicLinkCompat() }
        require(inputs.isNotEmpty()) { "No readable input files" }
        val kind = format.lowercase(Locale.ROOT).replace(".", "").replace("-", "")
        if (splitSizeBytes != null && kind != "zip") throw IOException("Split output is supported for ZIP only")
        val destinationPath = destArchive.canonicalPath
        if (inputs.any { it.isDirectory && destinationPath.startsWith(it.canonicalPath.trimEnd(File.separatorChar) + File.separator) }) {
            throw IOException("Choose a destination outside the folder being compressed")
        }
        val parent = destArchive.absoluteFile.parentFile ?: throw IOException("Destination has no parent")
        if (!parent.exists() && !parent.mkdirs()) throw IOException("Could not create destination directory")
        if (destArchive.exists()) throw IOException("Destination archive already exists")
        val total = inputs.sumOf { recursiveSize(it, cancelToken) }
        var completedBytes = 0L
        var completedEntries = 0
        when (kind) {
            "zip" -> {
                val zip = if (password.isNullOrEmpty()) ZipFile(destArchive) else ZipFile(destArchive, password.toCharArray())
                val params = ZipParameters().apply {
                    compressionMethod = CompressionMethod.DEFLATE
                    compressionLevel = when { level <= 0 -> CompressionLevel.NO_COMPRESSION; level <= 2 -> CompressionLevel.FAST; level >= 8 -> CompressionLevel.ULTRA; level >= 6 -> CompressionLevel.MAXIMUM; else -> CompressionLevel.NORMAL }
                    if (!password.isNullOrEmpty()) { isEncryptFiles = true; encryptionMethod = EncryptionMethod.AES; aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256 }
                }
                if (splitSizeBytes != null) {
                    if (splitSizeBytes < 65_536L) throw IOException("Split ZIP part size must be at least 64 KiB")
                    onProgress(Progress(0, total, 0, inputs.size, "Creating split ZIP"))
                    cancelToken.throwIfCancelled()
                    zip.createSplitZipFile(inputs, params, true, splitSizeBytes)
                    cancelToken.throwIfCancelled()
                    completedEntries = inputs.size
                    completedBytes = total
                    onProgress(Progress(completedBytes, total, completedEntries, inputs.size, destArchive.name))
                } else {
                    inputs.forEach { input ->
                        cancelToken.throwIfCancelled()
                        if (input.isDirectory) zip.addFolder(input, params) else zip.addFile(input, params)
                        completedEntries++
                        completedBytes += recursiveSize(input, cancelToken)
                        onProgress(Progress(completedBytes, total, completedEntries, inputs.size, input.name))
                    }
                }
                zip.close()
            }
            "7z" -> {
                if (!password.isNullOrEmpty()) throw UnsupportedOperationException("7z encryption is not available through Commons Compress; use AES-encrypted ZIP")
                SevenZOutputFile(destArchive).use { out ->
                    inputs.forEach { input ->
                        cancelToken.throwIfCancelled()
                        addToSevenZip(out, input, input.name, total, cancelToken) { bytes, name -> completedBytes += bytes; completedEntries++; onProgress(Progress(completedBytes, total, completedEntries, -1, name)) }
                    }
                }
            }
            "targz", "tgz" -> {
                if (!password.isNullOrEmpty()) throw UnsupportedOperationException("TAR.GZ does not support password encryption; use AES-encrypted ZIP")
                GzipCompressorOutputStream(BufferedOutputStream(FileOutputStream(destArchive))).use { gz ->
                    TarArchiveOutputStream(gz).use { tar ->
                        tar.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
                        tar.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
                        inputs.forEach { input -> addToTar(tar, input, input.name, total, cancelToken) { bytes, name -> completedBytes += bytes; completedEntries++; onProgress(Progress(completedBytes, total, completedEntries, -1, name)) } }
                    }
                }
            }
            "rar" -> throw UnsupportedOperationException("RAR archive creation is not supported; RAR extraction only")
            else -> throw UnsupportedOperationException("Compression format must be ZIP, 7z, or TAR.GZ")
        }
        return Result(completedEntries, completedBytes)
    }

    private data class IsoLocation(val extent: Long, val size: Long)

    /** Minimal ISO-9660 reader for ordinary data discs; supports recursive directory listing and file extraction. */
    private fun isoRefs(file: File): List<EntryRef> {
        val sector = 2048L
        if (file.length() < 17L * sector) throw IOException("ISO image is too small to contain a volume descriptor")
        fun readAt(offset: Long, length: Int): ByteArray {
            if (offset < 0 || length < 0 || offset + length > file.length()) throw IOException("ISO directory record points outside the image")
            val bytes = ByteArray(length)
            RandomAccessFile(file, "r").use { raf -> raf.seek(offset); raf.readFully(bytes) }
            return bytes
        }
        fun u16le(b: ByteArray, o: Int): Int = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
        fun u32le(b: ByteArray, o: Int): Long = (b[o].toLong() and 255L) or ((b[o + 1].toLong() and 255L) shl 8) or ((b[o + 2].toLong() and 255L) shl 16) or ((b[o + 3].toLong() and 255L) shl 24)
        var rootRecord: ByteArray? = null
        var descriptor = 16L
        while (descriptor * sector + sector <= file.length()) {
            val pvd = readAt(descriptor * sector, sector.toInt())
            if (String(pvd, 1, 5, Charsets.US_ASCII) != "CD001" || pvd[6].toInt() != 1) throw IOException("Invalid ISO-9660 volume descriptor")
            when (pvd[0].toInt() and 255) {
                1 -> { val len = pvd[156].toInt() and 255; if (len >= 34) rootRecord = pvd.copyOfRange(156, 156 + len); break }
                255 -> break
            }
            descriptor++
        }
        val root = rootRecord ?: throw IOException("ISO-9660 primary volume descriptor not found")
        val result = mutableListOf<EntryRef>()
        val visited = mutableSetOf<Long>()
        fun walk(path: String, record: ByteArray, depth: Int) {
            if (depth > 64) throw IOException("ISO directory nesting limit exceeded")
            val extent = u32le(record, 2); val size = u32le(record, 10); val flags = record[25].toInt() and 255
            if ((flags and 2) == 0) return
            if (!visited.add(extent)) return
            var consumed = 0L
            while (consumed < size) {
                val sectorOffset = extent * sector + consumed
                val sectorRemain = (sector - (consumed % sector)).toInt()
                val recordLen = readAt(sectorOffset, 1)[0].toInt() and 255
                if (recordLen == 0) { consumed += sectorRemain; continue }
                val rec = readAt(sectorOffset, recordLen)
                val nameLen = rec[32].toInt() and 255
                if (recordLen < 33 + nameLen || nameLen == 0) throw IOException("Malformed ISO directory record")
                val rawName = rec.copyOfRange(33, 33 + nameLen)
                val special = rawName.size == 1 && (rawName[0].toInt() == 0 || rawName[0].toInt() == 1)
                if (!special) {
                    val base = String(rawName, Charsets.US_ASCII).substringBefore(';').trimEnd('.')
                    if (base.isNotBlank()) {
                        val childPath = if (path.isEmpty()) base else "$path/$base"
                        val childExtent = u32le(rec, 2); val childSize = u32le(rec, 10); val childFlags = rec[25].toInt() and 255
                        val dir = (childFlags and 2) != 0
                        val entry = Entry(childPath, dir, if (dir) 0L else childSize, -1L)
                        result += EntryRef(entry, IsoLocation(childExtent, childSize))
                        if (result.size > MAX_ENTRIES) throw IOException("ISO image contains too many entries")
                        if (dir) walk(childPath, rec, depth + 1)
                    }
                }
                consumed += recordLen
            }
        }
        walk("", root, 0)
        return result
    }

    private fun isoInput(file: File, location: IsoLocation): InputStream {
        if (location.extent < 0 || location.size < 0 || location.extent * 2048L + location.size > file.length()) throw IOException("ISO file extent is outside the image")
        val input = FileInputStream(file)
        var remaining = location.size
        var skipped = 0L
        val target = location.extent * 2048L
        while (skipped < target) {
            val n = input.skip(target - skipped)
            if (n <= 0) { input.close(); throw IOException("Could not seek to ISO file data") }
            skipped += n
        }
        return object : java.io.FilterInputStream(input) {
            override fun read(): Int { if (remaining <= 0) return -1; val v = super.read(); if (v >= 0) remaining--; return v }
            override fun read(b: ByteArray, off: Int, len: Int): Int { if (remaining <= 0) return -1; val n = super.read(b, off, minOf(len.toLong(), remaining).toInt()); if (n > 0) remaining -= n; return n }
        }
    }

    private fun zipRefs(file: File, password: String?): List<EntryRef> {
        val charset = bestZipCharset(file, password)
        val zip = openZip(file, password, charset)
        return try {
            val headers = zip.fileHeaders ?: emptyList<FileHeader>()
            enforceEntryLimit(headers.size)
            headers.map { h -> EntryRef(Entry(h.fileName, h.isDirectory, h.uncompressedSize, h.compressedSize), h) }
        } finally { zip.close() }
    }

    /** UTF-8-flagged names stay UTF-8; charset choice affects legacy ZIP names without that flag. */
    private fun bestZipCharset(file: File, password: String?): Charset {
        val candidates = listOf(Charset.forName("CP437"), Charset.forName("GBK"), Charsets.UTF_8)
        var best = candidates.first()
        var bestScore = Int.MIN_VALUE
        var last: Exception? = null
        for (charset in candidates) {
            var zip: ZipFile? = null
            try {
                val openedZip = openZip(file, password, charset)
                zip = openedZip
                val headers = openedZip.fileHeaders ?: emptyList<FileHeader>()
                enforceEntryLimit(headers.size)
                var score = 0
                headers.take(2_000).forEach { header ->
                    val name = header.fileName.orEmpty()
                    name.forEach { ch ->
                        when {
                            ch == '\uFFFD' || ch.code < 0x20 -> score -= 20
                            ch in '\u0980'..'\u09FF' || ch in '\u3400'..'\u9FFF' || ch in '\u3040'..'\u30FF' || ch in '\uAC00'..'\uD7AF' -> score += 5
                            ch in '\u0080'..'\u009F' -> score -= 5
                            ch in "ÃÂÐÑâðïƒ" -> score -= 2
                            ch.code > 0x7F && ch.isLetter() -> score += 1
                        }
                    }
                }
                if (score > bestScore) { best = charset; bestScore = score }
            } catch (e: Exception) { last = e }
            finally { try { zip?.close() } catch (_: Exception) { } }
        }
        if (bestScore == Int.MIN_VALUE) throw IOException("Could not read ZIP listing (wrong password or unsupported encoding)", last)
        return best
    }

    private fun openZip(file: File, password: String?, charset: Charset = Charsets.UTF_8): ZipFile {
        val zip = if (password.isNullOrEmpty()) ZipFile(file) else ZipFile(file, password.toCharArray())
        try { zip.setCharset(charset) } catch (_: Exception) { }
        if (!zip.isValidZipFile) {
            try { zip.close() } catch (_: Exception) { }
            throw IOException("Invalid ZIP archive")
        }
        return zip
    }

    private fun rarRefs(file: File, password: String?): List<EntryRef> {
        val archive = createRarArchive(file, password)
        try {
            val headers = archive.javaClass.methods.firstOrNull { it.name == "getFileHeaders" && it.parameterCount == 0 }
                ?.invoke(archive) as? Iterable<*> ?: throw IOException("Unsupported RAR library API")
            val refs = ArrayList<EntryRef>()
            for (h in headers) {
                if (h == null) continue
                if (refs.size >= MAX_ENTRIES) throw IOException("Archive contains too many entries")
                val name = invokeValue(h, "getFileNameString")?.toString()
                    ?: invokeValue(h, "getFileName")?.toString() ?: continue
                val dir = (invokeValue(h, "isDirectory") as? Boolean) ?: false
                val size = (invokeValue(h, "getFullUnpackSize") as? Number)?.toLong()
                    ?: (invokeValue(h, "getUnpSize") as? Number)?.toLong() ?: -1L
                refs += EntryRef(Entry(name, dir, size, -1L), h)
            }
            return refs
        } finally { try { archive.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(archive) } catch (_: Exception) {} }
    }

    private fun createRarArchive(file: File, password: String?): Any {
        val c = try { Class.forName("com.github.junrar.Archive") } catch (e: Exception) { throw IOException("RAR extractor is unavailable", e) }
        return try {
            if (password.isNullOrEmpty()) c.getConstructor(File::class.java).newInstance(file)
            else c.getConstructor(File::class.java, String::class.java).newInstance(file, password)
        } catch (e: Exception) { throw IOException("Could not open RAR archive (check password or multipart files)", e) }
    }

    private fun rarInput(file: File, password: String?, entryName: String): InputStream {
        val archive = createRarArchive(file, password)
        val pipe = java.io.PipedInputStream(256 * 1024)
        val pipeOut = java.io.PipedOutputStream(pipe)
        val failure = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        Thread({
            try {
                val headers = archive.javaClass.methods.first { it.name == "getFileHeaders" && it.parameterCount == 0 }.invoke(archive) as Iterable<*>
                val header = headers.firstOrNull { h -> h != null && (invokeValue(h, "getFileNameString")?.toString() == entryName || invokeValue(h, "getFileName")?.toString() == entryName) }
                    ?: throw IOException("RAR entry not found: $entryName")
                archive.javaClass.methods.first { it.name == "extractFile" && it.parameterTypes.size == 2 }.invoke(archive, header, pipeOut)
            } catch (t: Throwable) {
                failure.set(t.cause ?: t)
            } finally {
                try { pipeOut.close() } catch (_: Exception) {}
                try { archive.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(archive) } catch (_: Exception) {}
            }
        }, "OmniHub-RAR-extract").apply { isDaemon = true; start() }
        return object : java.io.FilterInputStream(pipe) {
            private fun checkFailure() { failure.get()?.let { throw IOException("RAR extraction failed for $entryName", it) } }
            override fun read(): Int {
                val value = super.read()
                if (value < 0) checkFailure()
                return value
            }
            override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
                val count = super.read(buffer, offset, length)
                if (count < 0) checkFailure()
                return count
            }
        }
    }

    private fun sevenZipRefs(file: File, password: String?): List<EntryRef> {
        val result = mutableListOf<EntryRef>()
        openSevenZ(file, password).use { seven ->
            while (true) {
                val entry = seven.nextEntry ?: break
                if (result.size >= MAX_ENTRIES) throw IOException("Archive contains too many entries")
                result += EntryRef(Entry(entry.name, entry.isDirectory, entry.size, -1L), entry)
            }
        }
        return result
    }

    private fun openSevenZ(file: File, password: String?): SevenZFile {
        val builder = SevenZFile.builder().setFile(file).setMaxMemoryLimitKiB(128 * 1024)
        if (!password.isNullOrEmpty()) builder.setPassword(password.toCharArray())
        return builder.get()
    }

    private fun drainSevenEntry(seven: SevenZFile, cancelToken: CancelToken) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 2)
        while (true) {
            cancelToken.throwIfCancelled()
            if (seven.read(buffer) < 0) return
        }
    }

    private fun streamRefs(file: File, ext: String): List<EntryRef> {
        val refs = mutableListOf<EntryRef>()
        openArchiveStream(file, ext).use { stream ->
            while (true) {
                val e = stream.nextEntry ?: break
                if (refs.size >= MAX_ENTRIES) throw IOException("Archive contains too many entries")
                refs += EntryRef(commonsEntry(e), e)
            }
        }
        return refs
    }

    private fun commonsEntry(e: CommonsArchiveEntry): Entry = Entry(e.name, e.isDirectory, e.size, -1L)

    private fun openArchiveStream(file: File, ext: String): ArchiveInputStream<out CommonsArchiveEntry> {
        val input: InputStream = when (ext) {
            "tgz", "tar.gz" -> GzipCompressorInputStream(BufferedInputStream(FileInputStream(file)))
            "tar.bz2", "tbz2" -> BZip2CompressorInputStream(BufferedInputStream(FileInputStream(file)), true)
            "tar.xz" -> XZCompressorInputStream(BufferedInputStream(FileInputStream(file)), true)
            else -> BufferedInputStream(FileInputStream(file))
        }
        return try { ArchiveStreamFactory().createArchiveInputStream(input) }
        catch (e: Exception) { input.close(); throw IOException("Unsupported archive stream", e) }
    }

    private fun openCompressedStream(file: File, ext: String): InputStream = when (ext) {
        "gz" -> GzipCompressorInputStream(BufferedInputStream(FileInputStream(file)), true)
        "bz2" -> BZip2CompressorInputStream(BufferedInputStream(FileInputStream(file)), true)
        "xz" -> XZCompressorInputStream(BufferedInputStream(FileInputStream(file)), true)
        "lzma" -> LZMACompressorInputStream(BufferedInputStream(FileInputStream(file)))
        "zst" -> ZstdCompressorInputStream(BufferedInputStream(FileInputStream(file)))
        else -> ZstdInputStream(BufferedInputStream(FileInputStream(file)))
    }

    private fun isArchiveStreamExtension(ext: String) = ext in setOf("tar", "tgz", "tar.gz", "tar.bz2", "tar.xz", "ar", "cpio")
    private fun isCompressedStreamExtension(ext: String) = ext in setOf("gz", "bz2", "xz", "zst", "lzma")
    private fun isZipExtension(ext: String) = ext in setOf("zip", "jar", "apk")

    private fun effectiveExtension(file: File): String {
        val n = file.name.lowercase(Locale.ROOT)
        return when {
            n.endsWith(".tar.gz") -> "tar.gz"
            n.endsWith(".tar.bz2") -> "tar.bz2"
            n.endsWith(".tar.xz") -> "tar.xz"
            n.endsWith(".tgz") -> "tgz"
            n.endsWith(".part1.rar") || n.endsWith(".rar") -> "rar"
            n.endsWith(".7z.001") -> "7z"
            n.endsWith(".zip") -> "zip"
            n.endsWith(".apk") -> "apk"
            n.endsWith(".jar") -> "jar"
            else -> n.substringAfterLast('.', "").removePrefix(".")
        }
    }

    private fun resolveFirstPart(file: File, cancelToken: CancelToken? = null): File {
        val n = file.name
        val siblings = file.parentFile?.listFiles().orEmpty()
        fun siblingIgnoreCase(name: String): File? = siblings.firstOrNull { it.name.equals(name, ignoreCase = true) }

        val partRar = Regex("^(.*)\\.part(\\d+)\\.rar$", RegexOption.IGNORE_CASE).matchEntire(n)
        if (partRar != null) {
            val firstName = "${partRar.groupValues[1]}.part1.rar"
            val first = siblingIgnoreCase(firstName) ?: File(file.parentFile, firstName)
            if (!first.isFile) throw IOException("Multipart RAR is missing its first part: $firstName")
            return first
        }
        val zPart = Regex("^(.*)\\.z\\d{2}$", RegexOption.IGNORE_CASE).matchEntire(n)
        if (zPart != null) {
            val zipName = "${zPart.groupValues[1]}.zip"
            val first = siblingIgnoreCase(zipName) ?: File(file.parentFile, zipName)
            if (!first.isFile) throw IOException("Split ZIP is missing its main .zip file: $zipName")
            return first
        }
        val sevenPart = Regex("^(.*)\\.7z\\.(\\d{3})$", RegexOption.IGNORE_CASE).matchEntire(n)
        if (sevenPart != null) return mergeSplitSevenZip(file, sevenPart.groupValues[1], cancelToken)
        return file
    }

    /** Joins numbered 7z volumes only after validating the complete sequence and cache signature. */
    private fun mergeSplitSevenZip(selectedPart: File, baseName: String, cancelToken: CancelToken? = null): File {
        val parent = selectedPart.parentFile ?: throw IOException("Split 7z archive has no parent directory")
        val siblings = parent.listFiles() ?: throw IOException("Could not inspect split 7z volumes")
        fun partNumber(file: File): Int? {
            val m = Regex("^${Regex.escape(baseName)}\\.7z\\.(\\d{3})$", RegexOption.IGNORE_CASE).matchEntire(file.name) ?: return null
            return m.groupValues[1].toIntOrNull()
        }
        fun findPart(number: Int): File? {
            val expected = "$baseName.7z.${number.toString().padStart(3, '0')}"
            return siblings.firstOrNull { it.isFile && it.name.equals(expected, ignoreCase = true) }
        }

        val parts = ArrayList<File>()
        var index = 1
        while (index <= 999) {
            cancelToken?.throwIfCancelled()
            val part = findPart(index)
            if (part == null) {
                val later = siblings.firstOrNull { candidate -> (partNumber(candidate) ?: 0) > index }
                if (later != null) throw IOException("Split 7z volume gap: missing $baseName.7z.${index.toString().padStart(3, '0')} before ${later.name}")
                break
            }
            parts += part
            index++
        }
        if (parts.isEmpty()) throw IOException("Split 7z archive is missing .001: $baseName.7z.001")
        if (index > 999 && siblings.any { (partNumber(it) ?: 0) > 999 }) throw IOException("Split 7z set exceeds 999 volumes")

        val cacheBase = parent.canonicalPath + File.separator + baseName.lowercase(Locale.ROOT) + ".7z.001"
        val signature = parts.joinToString("|") { "${it.name.lowercase(Locale.ROOT)}:${it.length()}:${it.lastModified()}" }
        val key = "$cacheBase#$signature"
        splitSevenZipCache[key]?.takeIf { it.isFile && it.length() == parts.sumOf { part -> part.length() } }?.let { return it }

        // Avoid keeping stale joined copies after any source volume changes.
        splitSevenZipCache.keys.filter { it.startsWith("$cacheBase#") && it != key }.forEach { staleKey ->
            splitSevenZipCache.remove(staleKey)?.delete()
        }
        val temp = File.createTempFile(".omnihub-joined-", ".7z", parent)
        try {
            BufferedOutputStream(FileOutputStream(temp)).use { out ->
                var total = 0L
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 8)
                for (part in parts) {
                    cancelToken?.throwIfCancelled()
                    BufferedInputStream(FileInputStream(part)).use { input ->
                        while (true) {
                            cancelToken?.throwIfCancelled()
                            val count = input.read(buffer)
                            if (count < 0) break
                            if (count == 0) continue
                            total += count
                            if (total > 8L * 1024L * 1024L * 1024L) throw IOException("Split 7z set exceeds the 8 GiB join safety limit")
                            out.write(buffer, 0, count)
                        }
                    }
                }
                out.flush()
            }
            cancelToken?.throwIfCancelled()
            splitSevenZipCache[key] = temp
            temp.deleteOnExit()
            return temp
        } catch (t: Throwable) {
            temp.delete()
            throw t
        }
    }

    private fun isUnsafeName(name: String): Boolean {
        val n = name.replace('\\', '/')
        return n.startsWith('/') || Regex("^[A-Za-z]:").containsMatchIn(n) || n.split('/').any { it == ".." || it == "." }
    }

    private fun safeTarget(root: File, entryName: String): File {
        if (isUnsafeName(entryName)) throw IOException("Unsafe archive path rejected")
        val target = File(root, entryName.replace('\\', '/')).canonicalFile
        assertInside(root, target)
        return target
    }

    private fun assertInside(root: File, child: File) {
        val r = root.canonicalPath.trimEnd(File.separatorChar) + File.separator
        val c = child.canonicalPath
        if (c != root.canonicalPath && !c.startsWith(r)) throw IOException("Archive path escapes destination")
    }

    private fun isSymlinkNameOrNative(name: String, native: Any?): Boolean {
        if (native != null) {
            val redirection = invokeValue(native, "getRedirection")
            val redirectionType = redirection?.let { invokeValue(it, "getType")?.toString() }
            if (!redirectionType.isNullOrBlank() && !redirectionType.equals("NONE", ignoreCase = true)) return true
            for (methodName in listOf("isSymbolicLink", "isUnixSymlink")) {
                val value = invokeValue(native, methodName)
                if (value == true) return true
            }
            // ZIP external mode (Unix st_mode symlink bit) lives in the high 16 bits of external attributes.
            val attrs = invokeValue(native, "getExternalFileAttributes")
            if (attrs is Number && (((attrs.toLong() ushr 16).toInt()) and 0xF000) == 0xA000) return true
            if (attrs is ByteArray && attrs.size >= 4) {
                val mode = ((attrs[3].toInt() and 0xff) shl 8) or (attrs[2].toInt() and 0xff)
                if ((mode and 0xF000) == 0xA000) return true
            }
        }
        return name.startsWith(".symlink/") // harmless fallback; symlink metadata is never recreated
    }

    private fun invokeValue(target: Any, method: String): Any? = try { target.javaClass.methods.firstOrNull { it.name == method && it.parameterCount == 0 }?.invoke(target) } catch (_: Exception) { null }
    private fun invokeValue(target: Any, method: String, ignored: String): Any? = invokeValue(target, method)

    private fun validateDeclaredSize(uncompressed: Long, compressed: Long, dest: File) {
        if (uncompressed > MAX_EXTRACTED_BYTES) throw IOException("Archive exceeds the extraction size safety limit")
        if (uncompressed > 0 && compressed > 0 && uncompressed / compressed.coerceAtLeast(1) > ZIP_BOMB_RATIO_WARNING && uncompressed > 64L * 1024L * 1024L) {
            // High-ratio archives are allowed only while the hard expanded-size limit remains satisfied.
        }
        val free = dest.usableSpace
        if (uncompressed > 0 && free > 0 && uncompressed > free) throw IOException("Not enough free disk space for extraction")
    }

    private fun enforceEntryLimit(count: Int) { if (count > MAX_ENTRIES) throw IOException("Archive contains too many entries") }

    private fun keepBothPath(target: File): File {
        val ext = target.extension
        val stem = if (ext.isBlank()) target.name else target.name.removeSuffix(".$ext")
        var n = 1
        var candidate: File
        do { candidate = File(target.parentFile, if (ext.isBlank()) "$stem ($n)" else "$stem ($n).$ext"); n++ } while (candidate.exists() && n < 100_000)
        if (candidate.exists()) throw IOException("Could not resolve filename conflict")
        return candidate
    }

    private fun stripSingleCompressionSuffix(name: String): String = when {
        name.endsWith(".gz", true) -> name.dropLast(3)
        name.endsWith(".bz2", true) -> name.dropLast(4)
        name.endsWith(".xz", true) -> name.dropLast(3)
        name.endsWith(".zst", true) -> name.dropLast(4)
        name.endsWith(".lzma", true) -> name.dropLast(5)
        else -> name
    }

    private fun recursiveSize(file: File, token: CancelToken): Long {
        token.throwIfCancelled()
        if (file.isFile) return file.length().coerceAtLeast(0L)
        if (!file.isDirectory) return 0L
        var sum = 0L
        file.listFiles()?.forEach { child -> if (!child.isSymbolicLinkCompat()) sum += recursiveSize(child, token) }
        return sum
    }

    private fun File.isSymbolicLinkCompat(): Boolean = try {
        val stat = android.system.Os.lstat(absolutePath)
        (stat.st_mode and android.system.OsConstants.S_IFMT) == android.system.OsConstants.S_IFLNK
    } catch (_: Throwable) { false }

    private fun addToSevenZip(out: SevenZOutputFile, file: File, name: String, total: Long, token: CancelToken, tick: (Long, String) -> Unit) {
        token.throwIfCancelled()
        if (file.isDirectory) {
            val entry = out.createArchiveEntry(file, name)
            out.putArchiveEntry(entry); out.closeArchiveEntry(); tick(0, name)
            file.listFiles()?.filterNot { it.isSymbolicLinkCompat() }?.forEach { child -> addToSevenZip(out, child, "$name/${child.name}", total, token, tick) }
        } else {
            out.putArchiveEntry(out.createArchiveEntry(file, name))
            FileInputStream(file).use { input -> val buf = ByteArray(DEFAULT_BUFFER_SIZE * 2); while (true) { token.throwIfCancelled(); val n = input.read(buf); if (n < 0) break; out.write(buf, 0, n); tick(n.toLong(), name) } }
            out.closeArchiveEntry()
        }
    }

    private fun addToTar(out: TarArchiveOutputStream, file: File, name: String, total: Long, token: CancelToken, tick: (Long, String) -> Unit) {
        token.throwIfCancelled()
        val entry = TarArchiveEntry(file, name)
        out.putArchiveEntry(entry)
        if (file.isFile && !file.isSymbolicLinkCompat()) {
            FileInputStream(file).use { input -> val buf = ByteArray(DEFAULT_BUFFER_SIZE * 2); while (true) { token.throwIfCancelled(); val n = input.read(buf); if (n < 0) break; out.write(buf, 0, n); tick(n.toLong(), name) } }
        }
        out.closeArchiveEntry()
        if (file.isDirectory && !file.isSymbolicLinkCompat()) file.listFiles()?.filterNot { it.isSymbolicLinkCompat() }?.forEach { child -> addToTar(out, child, "$name/${child.name}", total, token, tick) }
    }
}
