package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import java.io.File
import java.util.Locale

/** "Set as wallpaper" for any picture and "Set as ringtone / notification / alarm" for any audio file. */
object SetAs {
    private val WALLPAPER_EXTS = setOf("jpg", "jpeg", "jpe", "jfif", "png", "webp", "gif", "bmp", "heic", "heif", "avif")

    fun canSetWallpaper(name: String) = name.substringAfterLast('.', "").lowercase(Locale.ROOT) in WALLPAPER_EXTS
    fun canSetRingtone(name: String) = name.substringAfterLast('.', "").lowercase(Locale.ROOT) in MediaKinds.audio

    private fun displayName(activity: Activity, uri: Uri, fallback: String?): String {
        if (!fallback.isNullOrBlank()) return fallback
        if (uri.scheme == "file") return File(uri.path ?: "").name
        try {
            activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { return it }
            }
        } catch (_: Throwable) { }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "audio"
    }

    // ------------------------------------------------------------------ wallpaper

    fun wallpaper(activity: Activity, uri: Uri) {
        val labels = if (Build.VERSION.SDK_INT >= 24) arrayOf("Home screen", "Lock screen", "Home and lock screen") else arrayOf("Set as wallpaper")
        AlertDialog.Builder(activity).setTitle("Set as wallpaper").setItems(labels) { _, which ->
            val flag = when (which) {
                0 -> if (Build.VERSION.SDK_INT >= 24) WallpaperManager.FLAG_SYSTEM else 0
                1 -> if (Build.VERSION.SDK_INT >= 24) WallpaperManager.FLAG_LOCK else 0
                else -> if (Build.VERSION.SDK_INT >= 24) WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK else 0
            }
            applyWallpaper(activity, uri, flag)
        }.setNegativeButton(R.string.action_cancel, null).show()
    }

    private fun applyWallpaper(activity: Activity, uri: Uri, flag: Int) {
        Toast.makeText(activity, "Setting wallpaper…", Toast.LENGTH_SHORT).show()
        Thread({
            var error: String? = null
            try {
                val dm = activity.resources.displayMetrics
                // Decode at most ~2x the screen's long side so huge photos cannot run out of memory.
                val target = maxOf(dm.widthPixels, dm.heightPixels) * 2
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                activity.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("This picture format cannot be decoded")
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2
                val bitmap: Bitmap = activity.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                } ?: throw IllegalStateException("Could not read the picture")
                val wm = WallpaperManager.getInstance(activity)
                if (Build.VERSION.SDK_INT >= 24 && flag != 0) wm.setBitmap(bitmap, null, true, flag) else wm.setBitmap(bitmap)
            } catch (t: Throwable) { error = t.localizedMessage ?: t.javaClass.simpleName }
            activity.runOnUiThread {
                if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
                Toast.makeText(activity, if (error == null) "Wallpaper set ✓" else "Could not set wallpaper: $error", Toast.LENGTH_LONG).show()
            }
        }, "OmniHub-Wallpaper").apply { isDaemon = true; start() }
    }

    // ------------------------------------------------------------------ ringtone

    fun ringtone(activity: Activity, uri: Uri, name: String? = null) {
        if (!Settings.System.canWrite(activity)) {
            AlertDialog.Builder(activity)
                .setTitle("Permission needed")
                .setMessage("Android needs the \"Modify system settings\" permission before OmniHub can change your ringtone. Allow it on the next screen, then try again.")
                .setNegativeButton(R.string.action_cancel, null)
                .setPositiveButton("Open settings") { _, _ ->
                    try {
                        activity.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + activity.packageName)))
                    } catch (_: Throwable) { Toast.makeText(activity, "Cannot open settings", Toast.LENGTH_LONG).show() }
                }.show()
            return
        }
        val types = arrayOf("Phone ringtone", "Notification sound", "Alarm sound")
        AlertDialog.Builder(activity).setTitle("Set as…").setItems(types) { _, which ->
            val type = when (which) { 0 -> RingtoneManager.TYPE_RINGTONE; 1 -> RingtoneManager.TYPE_NOTIFICATION; else -> RingtoneManager.TYPE_ALARM }
            applyRingtone(activity, uri, displayName(activity, uri, name), type)
        }.setNegativeButton(R.string.action_cancel, null).show()
    }

    private fun applyRingtone(activity: Activity, source: Uri, name: String, type: Int) {
        Thread({
            var error: String? = null
            try {
                val target = prepareMediaStoreUri(activity, source, name, type)
                RingtoneManager.setActualDefaultRingtoneUri(activity, type, target)
            } catch (t: Throwable) { error = t.localizedMessage ?: t.javaClass.simpleName }
            activity.runOnUiThread {
                if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
                val what = when (type) { RingtoneManager.TYPE_RINGTONE -> "Ringtone"; RingtoneManager.TYPE_NOTIFICATION -> "Notification sound"; else -> "Alarm sound" }
                Toast.makeText(activity, if (error == null) "$what set ✓" else "Could not set: $error", Toast.LENGTH_LONG).show()
            }
        }, "OmniHub-Ringtone").apply { isDaemon = true; start() }
    }

    /** Copies the audio into the system Ringtones / Notifications / Alarms folder (once) and returns its MediaStore Uri. */
    private fun prepareMediaStoreUri(activity: Activity, source: Uri, name: String, type: Int): Uri {
        val resolver = activity.contentResolver
        val dirName = when (type) {
            RingtoneManager.TYPE_NOTIFICATION -> Environment.DIRECTORY_NOTIFICATIONS
            RingtoneManager.TYPE_ALARM -> Environment.DIRECTORY_ALARMS
            else -> Environment.DIRECTORY_RINGTONES
        }
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.takeIf { it.startsWith("audio/") } ?: "audio/mpeg"
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        fun flags(v: ContentValues) {
            v.put(MediaStore.Audio.Media.IS_RINGTONE, type == RingtoneManager.TYPE_RINGTONE)
            v.put(MediaStore.Audio.Media.IS_NOTIFICATION, type == RingtoneManager.TYPE_NOTIFICATION)
            v.put(MediaStore.Audio.Media.IS_ALARM, type == RingtoneManager.TYPE_ALARM)
            v.put(MediaStore.Audio.Media.IS_MUSIC, false)
        }

        if (Build.VERSION.SDK_INT >= 29) {
            val rel = "$dirName/"
            // Reuse an earlier copy of the same file instead of creating duplicates.
            resolver.query(collection, arrayOf(MediaStore.MediaColumns._ID), "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?", arrayOf(name, rel), null)?.use { c ->
                if (c.moveToFirst()) {
                    val existing = ContentUris.withAppendedId(collection, c.getLong(0))
                    try { resolver.update(existing, ContentValues().also { flags(it) }, null, null) } catch (_: Throwable) { }
                    return existing
                }
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                put(MediaStore.MediaColumns.TITLE, name.substringBeforeLast('.'))
                put(MediaStore.MediaColumns.IS_PENDING, 1)
                flags(this)
            }
            val created = resolver.insert(collection, values) ?: throw IllegalStateException("Could not create the audio entry")
            try {
                resolver.openInputStream(source)!!.use { input -> resolver.openOutputStream(created, "w")!!.use { out -> input.copyTo(out) } }
                resolver.update(created, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (t: Throwable) { try { resolver.delete(created, null, null) } catch (_: Throwable) { }; throw t }
            return created
        }

        // Android 7-9: plain file in the public folder + MediaStore row pointing at it.
        @Suppress("DEPRECATION")
        val dir = Environment.getExternalStoragePublicDirectory(dirName).apply { mkdirs() }
        val dest = File(dir, name)
        if (!dest.exists()) resolver.openInputStream(source)!!.use { input -> dest.outputStream().use { input.copyTo(it) } }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DATA, dest.absolutePath)
            put(MediaStore.MediaColumns.TITLE, name.substringBeforeLast('.'))
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            flags(this)
        }
        val existing = MediaStore.Audio.Media.getContentUriForPath(dest.absolutePath)
        resolver.delete(existing!!, MediaStore.MediaColumns.DATA + "=?", arrayOf(dest.absolutePath))
        return resolver.insert(existing, values) ?: throw IllegalStateException("Could not register the audio file")
    }
}
