package com.example.omnihub

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class AppLockAccessibilityService : AccessibilityService() {
    // Opaque cover that hides a protected app the instant it appears, until the lock screen is on top.
    private var cover: View? = null
    private var lockVisible = false
    private var pendingPkg: String? = null
    private val main = Handler(Looper.getMainLooper())
    private val dropCover = Runnable { hideCover(false) }

    // If the lock screen is slow to appear we try again; the protected app is NEVER revealed without the lock.
    private val retryLock = Runnable {
        val p = pendingPkg
        if (cover != null && !lockVisible && p != null) launchLock(p)
    }
    private val giveUp = Runnable {
        if (cover != null && !lockVisible) {
            // Last resort: send the user home instead of exposing the protected app.
            try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Throwable) { }
            hideCover(true)
        }
    }

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            lockVisible = false
            recentsOpen = false
            AppLockState.relockAll()
            hideCover(true)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Fresh start: nothing is unlocked.
        AppLockState.relockAll()
        try { ContextCompat.registerReceiver(this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED) } catch (_: Exception) { }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        AppLockState.relockAll()
        hideCover(true)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        AppLockState.relockAll()
        hideCover(true)
        try { unregisterReceiver(screenOff) } catch (_: Exception) { }
        super.onDestroy()
    }

    // Set when the Recents screen was opened while a protected app was unlocked.
    private var recentsOpen = false

    private fun homePackage(): String? = try {
        packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
    } catch (_: Throwable) { null }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString().orEmpty()

        if (pkg == packageName) {
            // The cover and dialogs are not activities; only real OmniHub screens matter here.
            if (!cls.startsWith(packageName)) return
            if (cls.endsWith("AppLockScreenActivity")) {
                lockVisible = true
                main.removeCallbacks(retryLock)
                main.removeCallbacks(giveUp)
                main.removeCallbacks(dropCover)
                main.postDelayed(dropCover, 90)
                return
            }
            // OmniHub itself is never locked and visiting it does NOT end an unlocked session.
            lockVisible = false
            hideCover(true)
            return
        }

        if (pkg == "com.android.systemui") {
            // Remember that Recents was opened; the session only ends if the user then goes home (app dismissed).
            if (cls.contains("recent", true) && AppLockState.anyUnlocked()) recentsOpen = true
            return
        }
        if (isKeyboard(pkg)) return

        val prefs = getSharedPreferences("omnihub_app_locker", MODE_PRIVATE)
        val locked = (prefs.getStringSet("locked_packages", emptySet()) ?: emptySet()) - packageName

        // Recents -> home screen (instead of back into an app) means the app was swiped away: lock it again.
        if (recentsOpen) {
            recentsOpen = false
            if (pkg == homePackage()) AppLockState.relockAll()
        }

        if (pkg !in locked) { lockVisible = false; hideCover(true); return }

        // Opened through OmniHub's own lock gate a moment ago: allow once without asking twice.
        if (AppLockState.consumeGrant(pkg)) {
            AppLockState.markUnlocked(pkg)
            lockVisible = false
            hideCover(true)
            return
        }

        // Already unlocked in this session: let it open, never ask again.
        if (AppLockState.isUnlocked(pkg)) { lockVisible = false; hideCover(true); return }

        // The lock screen for this very app is already showing: do not restart the fingerprint / PIN prompt.
        if (lockVisible && pendingPkg == pkg) return

        // Protected app is opening and has NOT been unlocked: cover it at once, then bring up the lock screen.
        lockVisible = false
        showCover(pkg)
        launchLock(pkg)
    }

    private fun launchLock(pkg: String) {
        try {
            startActivity(
                Intent(this, AppLockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    .putExtra("locked_package", pkg)
            )
        } catch (_: Exception) { /* the retry / give-up timers below keep the app hidden */ }
    }

    private fun showCover(pkg: String) {
        pendingPkg = pkg
        main.removeCallbacks(dropCover)
        main.removeCallbacks(retryLock)
        main.removeCallbacks(giveUp)
        main.postDelayed(retryLock, 1800)
        main.postDelayed(giveUp, 6000)
        if (cover != null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val view = FrameLayout(this).apply {
                setBackgroundColor(Color.rgb(11, 16, 32))
                isClickable = true
                addView(TextView(this@AppLockAccessibilityService).apply {
                    text = "🔒"
                    textSize = 44f
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.OPAQUE
            )
            if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            wm.addView(view, lp)
            cover = view
        } catch (_: Throwable) { cover = null }
    }

    private fun hideCover(now: Boolean) {
        main.removeCallbacks(dropCover)
        main.removeCallbacks(retryLock)
        main.removeCallbacks(giveUp)
        val view = cover ?: return
        cover = null
        val wm = try { getSystemService(Context.WINDOW_SERVICE) as WindowManager } catch (_: Throwable) { return }
        fun remove() { try { wm.removeViewImmediate(view) } catch (_: Throwable) { try { wm.removeView(view) } catch (_: Throwable) { } } }
        if (now) { remove(); return }
        // Quick fade so the lock screen appears smoothly instead of popping.
        view.animate().alpha(0f).setDuration(110).withEndAction { remove() }.start()
    }

    private fun isKeyboard(pkg: String): Boolean = try {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.enabledInputMethodList.any { it.packageName == pkg }
    } catch (_: Exception) { false }

    override fun onInterrupt() { hideCover(true) }
}
