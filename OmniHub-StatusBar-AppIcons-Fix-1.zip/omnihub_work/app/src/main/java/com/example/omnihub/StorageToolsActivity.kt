package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/** Storage analysis and carefully-confirmed cleanup actions. File scanning never runs on the UI thread. */
class StorageToolsActivity : Activity() {
    private val bg = Color.rgb(242, 240, 247)
    private val surface = Color.rgb(252, 251, 254)
    private val line = Color.rgb(218, 213, 230)
    private val ink = Color.rgb(37, 34, 47)
    private val muted = Color.rgb(94, 88, 112)
    private val accent = Color.rgb(102, 80, 196)
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private var mode = "analyze"
    private var cacheRequestPending = false
    private var analysis: Analysis? = null

    private data class Analysis(
        val files: Int,
        val visited: Int,
        val categoryBytes: Map<String, Long>,
        val categoryCounts: Map<String, Int>,
        val largest: List<File>,
        val duplicateDownloadGroups: Int,
        val duplicateDownloadFiles: List<File>
    )

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == ShizukuHelper.PERMISSION_REQUEST) ui.post {
            if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                ShizukuHelper.bind(this)
                if (cacheRequestPending) {
                    cacheRequestPending = false
                    ui.postDelayed({ clearCachesAfterBinding(0) }, 450L)
                }
            } else {
                cacheRequestPending = false
                toast("Shizuku permission was not granted")
                updateStatus("Shizuku permission is required for app-cache cleanup.")
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode")?.lowercase(Locale.ROOT) ?: "analyze"
        window.statusBarColor = bg
        window.navigationBarColor = surface
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        try { Shizuku.addRequestPermissionResultListener(permissionListener) } catch (_: Throwable) { }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)); setBackgroundColor(surface) }
        top.addView(button("‹", surface) { finish() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titleBox.addView(label(if (mode == "clean") "Clean storage" else "Analyze storage", 20f, ink, true))
        titleBox.addView(label("OmniHub · local storage", 11f, muted, false))
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("↻", surface) { if (mode == "clean") renderClean() else scan() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(top)
        val divider = View(this).apply { setBackgroundColor(line) }
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        status = label("", 11f, muted, false).apply { setPadding(dp(16), dp(5), dp(16), dp(5)); visibility = View.GONE }
        root.addView(status)
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; setPadding(dp(14), dp(12), dp(14), dp(24)) }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (mode == "clean") renderClean() else renderAnalyzeIntro()
        ShizukuHelper.bind(this)
    }

    private fun renderAnalyzeIntro() {
        body.removeAllViews()
        card {
            addView(label("Storage overview", 16f, ink, true))
            addView(label("Analyze file types, locate large files and review likely duplicate downloads. Scanning is read-only.", 12f, muted, false).apply { setPadding(0, dp(6), 0, dp(12)) })
            addView(button("Start analysis", accent) { scan() }, LinearLayout.LayoutParams(-1, dp(46)))
        }
        analysis?.let { showAnalysis(it) } ?: run {
            card { addView(label("Ready to scan", 14f, ink, true)); addView(label("The scan skips hidden folders, Android/data and Android/obb to avoid unnecessary slowdowns.", 12f, muted, false).apply { setPadding(0, dp(5), 0, 0) }) }
        }
    }

    private fun scan() {
        status.text = "Scanning shared storage in the background…"
        status.visibility = View.VISIBLE
        body.removeAllViews()
        card { addView(label("Scanning storage…", 15f, ink, true)); addView(label("Large phones can take a little time. You can leave this screen open.", 12f, muted, false).apply { setPadding(0, dp(5), 0, 0) }) }
        io.execute {
            val base = Environment.getExternalStorageDirectory()
            val bytes = linkedMapOf("Images" to 0L, "Audio" to 0L, "Videos" to 0L, "Documents" to 0L, "Archives / APK" to 0L, "Other files" to 0L)
            val counts = bytes.keys.associateWith { 0 }.toMutableMap()
            val largest = ArrayList<File>()
            var fileCount = 0
            var visited = 0
            val dupGroups = HashMap<String, MutableList<File>>()
            val downloads = File(base, "Download")
            try {
                val sequence = base.walkTopDown().onEnter { dir ->
                    val rel = try { dir.relativeTo(base).path.replace('\\', '/') } catch (_: Exception) { "" }
                    dir == base || (dir.name != ".omnihub_trash" && !dir.name.startsWith(".") && !rel.startsWith("Android/data") && !rel.startsWith("Android/obb") && dir.canRead())
                }
                for (f in sequence) {
                    if (Thread.currentThread().isInterrupted || isFinishing) break
                    visited++
                    if (!f.isFile || f.name.startsWith(".")) continue
                    fileCount++
                    val ext = f.extension.lowercase(Locale.ROOT)
                    val group = when (ext) {
                        "jpg","jpeg","png","gif","webp","bmp","heic","heif","avif","tif","tiff","svg" -> "Images"
                        "mp3","m4a","aac","wav","flac","ogg","opus","wma","mid","midi","amr" -> "Audio"
                        "mp4","mkv","mov","avi","webm","3gp","mpeg","mpg","ts","wmv","flv","m4v" -> "Videos"
                        "pdf","doc","docx","txt","rtf","odt","xls","xlsx","ppt","pptx","csv","md","epub" -> "Documents"
                        "zip","rar","7z","tar","gz","bz2","xz","zst","apk" -> "Archives / APK"
                        else -> "Other files"
                    }
                    bytes[group] = (bytes[group] ?: 0L) + f.length()
                    counts[group] = (counts[group] ?: 0) + 1
                    if (largest.size < 12 || f.length() > (largest.minOfOrNull { it.length() } ?: -1L)) {
                        largest.add(f)
                        largest.sortByDescending { it.length() }
                        while (largest.size > 12) largest.removeAt(largest.lastIndex)
                    }
                    if (f.parentFile?.absolutePath == downloads.absolutePath) {
                        val name = normalizeDownloadName(f.name)
                        if (name.isNotBlank()) dupGroups.getOrPut(name + "|" + f.length()) { mutableListOf() }.add(f)
                    }
                    if (visited >= 150_000) break
                }
            } catch (_: Throwable) { }
            val duplicates = dupGroups.values.filter { it.size > 1 }.flatMap { group -> group.sortedByDescending { it.lastModified() }.drop(1) }
            val result = Analysis(fileCount, visited, bytes, counts, largest.toList(), dupGroups.values.count { it.size > 1 }, duplicates)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                analysis = result
                status.text = "Analysis complete · ${result.files} files checked${if (result.visited >= 150_000) " · scan limit reached" else ""}"
                showAnalysis(result)
            }
        }
    }

    private fun showAnalysis(a: Analysis) {
        body.removeAllViews()
        card {
            addView(label("Storage summary", 16f, ink, true))
            val root = Environment.getExternalStorageDirectory()
            val total = root.totalSpace.coerceAtLeast(0L)
            val free = root.usableSpace.coerceAtLeast(0L)
            val used = (total - free).coerceAtLeast(0L)
            addView(label("${human(used)} used · ${human(free)} free", 13f, muted, false).apply { setPadding(0, dp(5), 0, dp(8)) })
            addView(label("${a.files} files checked", 12f, ink, true))
        }
        card {
            addView(label("Files by type", 15f, ink, true))
            val categoryTotal = a.categoryBytes.values.sum().coerceAtLeast(1L)
            a.categoryBytes.forEach { (name, size) ->
                val percent = ((size.toDouble() / categoryTotal.toDouble()) * 100.0).toInt().coerceIn(0, 100)
                val row = LinearLayout(this@StorageToolsActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(4)) }
                row.addView(label(name, 12f, ink, false), LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(label("${a.categoryCounts[name] ?: 0} · ${human(size)} · $percent%", 11f, muted, false))
                addView(row)
                val bar = android.widget.ProgressBar(this@StorageToolsActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100; progress = percent; progressTintList = ColorStateList.valueOf(when (name) {
                        "Images" -> Color.rgb(120, 169, 255); "Audio" -> Color.rgb(99, 230, 190)
                        "Videos" -> Color.rgb(167, 139, 250); "Documents" -> Color.rgb(251, 191, 36)
                        "Archives / APK" -> Color.rgb(251, 146, 60); else -> Color.rgb(148, 163, 184)
                    }); progressBackgroundTintList = ColorStateList.valueOf(line)
                }
                addView(bar, LinearLayout.LayoutParams(-1, dp(5)).apply { bottomMargin = dp(6) })
            }
            addView(button("Browse all files", surface) { openBrowser() }, LinearLayout.LayoutParams(-1, dp(44)))
        }
        card {
            addView(label("Large files", 15f, ink, true))
            if (a.largest.isEmpty()) addView(label("No accessible files found.", 12f, muted, false).apply { setPadding(0, dp(8), 0, 0) })
            a.largest.forEach { f ->
                addView(fileRow(f, showOpen = true))
            }
        }
        card {
            addView(label("Potential duplicate downloads", 15f, ink, true))
            addView(label("${a.duplicateDownloadGroups} candidate group(s) share a normalized filename and size. These are only candidates, not confirmed duplicates. Use SHA-256 verification before removing copies.", 12f, muted, false).apply { setPadding(0, dp(5), 0, dp(10)) })
            addView(button("Verify duplicates & scan junk", accent) { startActivity(Intent(this@StorageToolsActivity, DuplicateCleanerActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(44)))
            addView(button("Review Downloads folder", surface) { openFolder("Download", true) }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(7) })
        }
        card {
            addView(label("Next steps", 15f, ink, true))
            addView(button("Open Clean tools", surface) { startActivity(Intent(this@StorageToolsActivity, StorageToolsActivity::class.java).putExtra("mode", "clean")) }, LinearLayout.LayoutParams(-1, dp(44)))
        }
    }

    private fun renderClean() {
        body.removeAllViews()
        card {
            addView(label("Clean safely", 16f, ink, true))
            addView(label("Review the target first. OmniHub does not silently erase your personal photos, videos, documents or app data.", 12f, muted, false).apply { setPadding(0, dp(5), 0, dp(12)) })
        }
        card {
            addView(label("App cache", 15f, ink, true))
            addView(label("Ask Android to trim app caches and clear accessible Android/data/*/cache folders using Shizuku. App data and media are not intentionally touched.", 12f, muted, false).apply { setPadding(0, dp(5), 0, dp(10)) })
            addView(button("Clear app caches", accent) { confirmCacheClear() }, LinearLayout.LayoutParams(-1, dp(46)))
            addView(button("Open Shizuku setup", surface) { openShizuku() }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(7) })
        }
        card {
            addView(label("Recycle Bin", 15f, ink, true))
            addView(label("Restore deleted files or permanently remove them after review.", 12f, muted, false).apply { setPadding(0, dp(5), 0, dp(10)) })
            addView(button("Open Recycle Bin", surface) { startActivity(Intent(this@StorageToolsActivity, RecycleBinActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(44)))
        }
        card {
            addView(label("Duplicate & junk scan", 15f, ink, true))
            addView(label("Verify duplicates by file content and review old APK installers or empty directories. Nothing is removed automatically.", 12f, muted, false).apply { setPadding(0, dp(5), 0, dp(10)) })
            addView(button("Scan duplicates & junk", accent) { startActivity(Intent(this@StorageToolsActivity, DuplicateCleanerActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(44)))
        }
        card {
            addView(label("Unused apps", 15f, ink, true))
            addView(label("Android requires Usage Access permission before apps can be classified by usage. Open the system permission screen, or manage installed apps with Shizuku.", 12f, muted, false).apply { setPadding(0, dp(5), 0, dp(10)) })
            addView(button("Permit usage access", surface) {
                try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) { toast("Usage Access settings are unavailable") }
            }, LinearLayout.LayoutParams(-1, dp(44)))
            addView(button("Manage installed apps", surface) { startActivity(Intent(this@StorageToolsActivity, ShizukuAppsActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(7) })
        }
        analysis?.let { a ->
            card {
                addView(label("Large files", 15f, ink, true))
                addView(label("Analysis found ${a.largest.size} of the largest accessible files. Review before deleting.", 12f, muted, false).apply { setPadding(0, dp(5), 0, dp(10)) })
                addView(button("Open Analyze results", surface) { startActivity(Intent(this@StorageToolsActivity, StorageToolsActivity::class.java).putExtra("mode", "analyze")) }, LinearLayout.LayoutParams(-1, dp(44)))
            }
        }
    }

    private fun confirmCacheClear() {
        AlertDialog.Builder(this)
            .setTitle("Clear app caches?")
            .setMessage("Android will be asked to trim caches. Where Shizuku allows access, OmniHub will also remove contents of folders named cache under Android/data. App data, downloads, photos, and documents are not included. Some apps may rebuild their cache.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear caches") { _, _ -> beginCacheClear() }
            .show()
    }

    private fun beginCacheClear() {
        if (!ShizukuHelper.installed(this)) {
            AlertDialog.Builder(this).setTitle("Shizuku is not installed")
                .setMessage("Install and start Shizuku first, then grant OmniHub permission to use it.")
                .setNegativeButton("Cancel", null).setPositiveButton("Download Shizuku") { _, _ -> try { ShizukuHelper.openDownloadPage(this) } catch (_: Exception) { } }.show()
            return
        }
        if (!ShizukuHelper.running()) {
            AlertDialog.Builder(this).setTitle("Start Shizuku")
                .setMessage("Shizuku is installed but its service is not running. Start it, then return here.")
                .setNegativeButton("Cancel", null).setPositiveButton("Open Shizuku") { _, _ -> ShizukuHelper.openShizukuApp(this) }.show()
            return
        }
        if (!ShizukuHelper.permitted()) {
            cacheRequestPending = true
            ShizukuHelper.requestPermission()
            updateStatus("Waiting for Shizuku permission…")
            return
        }
        ShizukuHelper.bind(this)
        clearCachesAfterBinding(0)
    }

    private fun clearCachesAfterBinding(attempt: Int) {
        if (isFinishing || isDestroyed) return
        if (ShizukuHelper.service == null) {
            if (attempt < 8) { ShizukuHelper.bind(this); ui.postDelayed({ clearCachesAfterBinding(attempt + 1) }, 350L); return }
            toast("Shizuku service could not connect. Open Shizuku Files once, then retry.")
            updateStatus("Shizuku service is not connected.")
            return
        }
        status.text = "Clearing accessible caches…"
        status.visibility = View.VISIBLE
        io.execute {
            var osTrim = false
            var externalCleaned = 0
            var message = ""
            try {
                val result = ShizukuHelper.exec("pm trim-caches 999G")
                osTrim = result.first == 0
                if (result.second.isNotBlank()) message = result.second.take(160)
            } catch (e: Throwable) { message = e.message ?: "Android cache trim was denied" }
            try {
                val base = "/storage/emulated/0/Android/data"
                val packages = ShizukuHelper.list(base).filter { it.isDir && !it.link }.take(4000)
                for (pkg in packages) {
                    if (Thread.currentThread().isInterrupted) break
                    val cachePath = "$base/${pkg.name}/cache"
                    try {
                        if (ShizukuHelper.exists(cachePath) && ShizukuHelper.delete(cachePath)) externalCleaned++
                    } catch (_: Throwable) { }
                }
            } catch (_: Throwable) { }
            val finalTrim = osTrim
            val externalCount = externalCleaned
            val detail = message
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val result = if (finalTrim || externalCount > 0) "Cache cleanup finished. Android trim: ${if (finalTrim) "requested successfully" else "not available"}; accessible Android/data cache folders removed: $externalCount." else "No cache data was removed. Shizuku may lack the required shell access or the cache folders may be protected."
                updateStatus(result + if (detail.isNotBlank() && !finalTrim) " ($detail)" else "")
                AlertDialog.Builder(this).setTitle(if (finalTrim || externalCount > 0) "Cleanup finished" else "Cleanup limited")
                    .setMessage(result + if (detail.isNotBlank() && !finalTrim) "\n\n$detail" else "")
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    private fun fileRow(file: File, showOpen: Boolean): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(label(file.name, 12f, ink, true))
        info.addView(label("${human(file.length())} · ${file.parentFile?.name.orEmpty()}", 10f, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        if (showOpen) row.addView(button("Open", surface) { openFile(file) }, LinearLayout.LayoutParams(dp(72), dp(36)))
        return row
    }

    private fun openFile(file: File) {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra(MainActivity.EXTRA_OPEN_PATH, file.absolutePath))
    }
    private fun openBrowser() { startActivity(Intent(this, FileManagerActivity::class.java).putExtra("mode", "browse")) }
    private fun openFolder(name: String, recent: Boolean = false) {
        val path = File(Environment.getExternalStorageDirectory(), name)
        startActivity(Intent(this, FileManagerActivity::class.java).putExtra("mode", "browse").putExtra("browse_path", path.absolutePath).putExtra("sort_recent", recent))
    }
    private fun openShizuku() { startActivity(Intent(this, ShizukuFileActivity::class.java).putExtra("path", Environment.getExternalStorageDirectory().absolutePath).putExtra("action", "files")) }

    private fun normalizeDownloadName(name: String): String = name.lowercase(Locale.ROOT).replace(Regex("\\s*\\(\\d+\\)(?=\\.[^.]+$)"), "").trim()
    private fun human(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024L * 1024 -> String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024 * 1024 -> String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024))
        else -> String.format(Locale.ROOT, "%.2f GB", bytes / (1024.0 * 1024 * 1024))
    }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun updateStatus(text: String) { status.text = text; status.visibility = if (text.isBlank()) View.GONE else View.VISIBLE }

    private fun card(block: LinearLayout.() -> Unit) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14)); background = android.graphics.drawable.GradientDrawable().apply { setColor(surface); cornerRadius = dp(16).toFloat(); setStroke(dp(1), line) } }
        wrap.block()
        body.addView(wrap, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }
    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER_VERTICAL; setLineSpacing(dp(2).toFloat(), 1f) }
    private fun button(text: String, color: Int, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 12f; isAllCaps = false; setTextColor(if (color == accent) Color.WHITE else ink)
        backgroundTintList = ColorStateList.valueOf(color); minHeight = dp(38); minimumHeight = dp(38); setPadding(dp(8), 0, dp(8), 0); setOnClickListener { action() }
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permissionListener) } catch (_: Throwable) { }
        io.shutdownNow()
        super.onDestroy()
    }
}
