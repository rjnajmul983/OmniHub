package com.example.omnihub

import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import java.io.File
import java.nio.file.Files
import java.nio.file.DirectoryStream
import java.util.WeakHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Cancellable folder-media preview lookup. Every visible owner subscribes to a shared folder job;
 * detaching/recycling an owner unsubscribes it and cancels the underlying IO when no owners remain.
 */
class FolderPreviewLoader(private val executor: ExecutorService) {
    data class Preview(val children: List<File>, val hasMore: Boolean)

    private val cache = object : LruCache<String, Preview>(320) {}
    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val inFlight = HashMap<String, Task>()
    private val ownerKeys = WeakHashMap<View, String>()

    private class Task(val key: String, val folder: File) {
        val cancelled = AtomicBoolean(false)
        val subscribers = LinkedHashMap<View, (Preview) -> Unit>()
        var future: Future<*>? = null
    }

    fun load(folder: File, owner: View, callback: (Preview) -> Unit) {
        cancel(owner)
        val key = "${folder.absolutePath}|${folder.lastModified()}"
        cache.get(key)?.let { callback(it); return }
        synchronized(lock) {
            // Recheck after entering the lock, so simultaneous UI bind calls don't queue duplicate scans.
            cache.get(key)?.let { cached ->
                main.post { if (owner.isAttachedToWindow && ownerKeys[owner] == null) callback(cached) }
                return
            }
            val task = inFlight[key] ?: Task(key, folder).also { inFlight[key] = it }
            task.subscribers[owner] = callback
            ownerKeys[owner] = key
            if (task.future == null) {
                try {
                    task.future = executor.submit {
                        val result = try { readAtMostFour(folder, task.cancelled) } catch (_: Throwable) { Preview(emptyList(), false) }
                        if (task.cancelled.get() || Thread.currentThread().isInterrupted) return@submit
                        cache.put(key, result)
                        main.post {
                            val callbacks: List<Pair<View, (Preview) -> Unit>>
                            synchronized(lock) {
                                if (inFlight[key] !== task || task.cancelled.get()) return@post
                                inFlight.remove(key)
                                callbacks = task.subscribers.entries.map { it.key to it.value }
                                task.subscribers.clear()
                                // Owner-to-key associations remain weak and are removed on detach/recycle.
                            }
                            callbacks.forEach { (view, deliver) ->
                                val stillSubscribed = synchronized(lock) { ownerKeys[view] == key }
                                if (stillSubscribed && view.isAttachedToWindow) deliver(result)
                            }
                        }
                    }
                } catch (_: Exception) {
                    inFlight.remove(key, task)
                    task.subscribers.keys.toList().forEach { ownerKeys.remove(it) }
                    task.subscribers.clear()
                }
            }
        }
    }

    /** Removes a view from its current preview job; the job is interrupted when no view needs it. */
    fun cancel(owner: View) {
        synchronized(lock) {
            val key = ownerKeys.remove(owner) ?: return
            val task = inFlight[key] ?: return
            task.subscribers.remove(owner)
            if (task.subscribers.isEmpty()) {
                task.cancelled.set(true)
                inFlight.remove(key, task)
                task.future?.cancel(true)
            }
        }
    }

    /** Cancels all pending preview IO and releases cached previews when the Activity is destroyed. */
    fun clear() {
        synchronized(lock) {
            inFlight.values.toList().forEach { task ->
                task.cancelled.set(true)
                task.future?.cancel(true)
                task.subscribers.keys.toList().forEach { ownerKeys.remove(it) }
                task.subscribers.clear()
            }
            inFlight.clear()
            ownerKeys.clear()
        }
        cache.evictAll()
    }

    private fun readAtMostFour(folder: File, cancelled: AtomicBoolean): Preview {
        if (!folder.isDirectory || !folder.canRead() || cancelled.get() || Thread.currentThread().isInterrupted) return Preview(emptyList(), false)
        val picked = ArrayList<File>(4)
        var more = false
        fun consider(file: File) {
            if (cancelled.get() || Thread.currentThread().isInterrupted) return
            if (!file.isFile || file.name.startsWith(".")) return
            val ext = file.extension.lowercase()
            if (ext !in MEDIA_EXTENSIONS) return
            // Folder mosaics skip icons / UI assets / tiny clips so they show real photos and videos.
            val lowerName = file.name.lowercase()
            val isImage = ext in IMAGE_EXTENSIONS
            if (isImage && (lowerName.startsWith("ic_") || lowerName.startsWith("icon") || lowerName.contains("thumb") || file.length() < 30L * 1024)) return
            if (!isImage && ext in VIDEO_EXTENSIONS && file.length() < 150L * 1024) return
            if (picked.size < 4) picked.add(file) else more = true
        }

        // DirectoryStream is lazy on API 26+; close as soon as we find a fifth media file.
        if (Build.VERSION.SDK_INT >= 26) {
            var stream: DirectoryStream<java.nio.file.Path>? = null
            try {
                stream = Files.newDirectoryStream(folder.toPath())
                for (path in stream) {
                    if (cancelled.get() || Thread.currentThread().isInterrupted) return Preview(emptyList(), false)
                    consider(path.toFile())
                    if (more) break
                }
            } catch (_: Exception) {
                // Fall through to a compatibility scan below only while still requested.
            } finally { try { stream?.close() } catch (_: Exception) {} }
            if (cancelled.get() || Thread.currentThread().isInterrupted) return Preview(emptyList(), false)
            if (picked.isNotEmpty() || more) return Preview(picked, more)
        }

        // Android 23–25 fallback. Still runs on the existing thumbnail executor, never the UI thread.
        val files = try { folder.listFiles() } catch (_: Exception) { null } ?: return Preview(picked, false)
        for (file in files) {
            if (cancelled.get() || Thread.currentThread().isInterrupted) return Preview(emptyList(), false)
            consider(file)
            if (more) break
        }
        return Preview(picked, more)
    }

    companion object {
        private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif")
        private val VIDEO_EXTENSIONS = setOf("mp4", "mkv", "mov", "webm", "avi", "m4v", "3gp", "mpeg", "mpg")
        private val MEDIA_EXTENSIONS = setOf(
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif",
            "mp4", "mkv", "mov", "webm", "avi", "m4v", "3gp", "mpeg", "mpg",
            "mp3", "m4a", "aac", "ogg", "opus", "wav", "flac", "amr", "wma"
        )
    }
}
