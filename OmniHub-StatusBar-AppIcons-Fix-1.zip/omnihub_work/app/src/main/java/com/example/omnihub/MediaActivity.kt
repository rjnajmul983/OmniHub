package com.example.omnihub

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.TextUtils
import android.util.Rational
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * OmniHub media player: MX-Player style video UI + a music-player style audio UI.
 * Playback is done by Media3 ExoPlayer (far wider codec/container support than android.media.MediaPlayer).
 */
class MediaActivity : Activity() {

    private val accent = Color.rgb(98, 228, 211)
    private val prefs by lazy { getSharedPreferences("omnihub_media", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())

    // ---------- player state ----------
    private var player: ExoPlayer? = null
    private var playlist: List<Uri> = emptyList()
    private var playlistNames: List<String> = emptyList()
    private var index = 0
    private var isVideoItem = true
    private var hasVideoTrack = false
    private var currentName = ""
    private var currentMime = ""
    private var speed = 1f
    private var repeatMode = 0              // 0 off, 1 all, 2 one
    private var shuffle = false
    private var equalizer: Equalizer? = null
    private var adopted: AudioKeeper.Session? = null
    private var sleepRunnable: Runnable? = null
    private var subtitleTextSize = 20f

    // ---------- video view state ----------
    private var textureView: TextureView? = null
    private var aspectMode = 0
    private val aspectNames = listOf("Fit", "Fill", "Stretch", "100%", "16:9", "4:3")
    private var userScale = 1f
    private var userTx = 0f
    private var userTy = 0f
    private var orientMode = 0              // 0 auto(by video), 1 landscape, 2 portrait, 3 sensor
    // 0 = off, 1 = 2x HD, 2 = 3.5x HD (GPU sharpen / contrast render levels)
    private var upscaleLevel = 0
    private val upscale: Boolean get() = upscaleLevel > 0
    private var locked = false
    private var inPip = false

    // ---------- ui ----------
    private lateinit var root: FrameLayout
    private lateinit var videoHolder: FrameLayout
    private lateinit var touchLayer: View
    private lateinit var controlsLayer: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var centerRow: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private lateinit var feedbackView: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var seekBar: SeekBar
    private lateinit var posLabel: TextView
    private lateinit var durLabel: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var unlockBtn: ImageButton
    private lateinit var speedChip: TextView
    private lateinit var aspectChip: TextView
    private lateinit var hdChip: TextView
    private lateinit var lockBtn: ImageButton
    private lateinit var videoOnlyTools: List<View>
    private lateinit var repeatBtn: ImageButton
    private lateinit var shuffleBtn: ImageButton
    private lateinit var audioPanel: LinearLayout
    private lateinit var discView: FrameLayout
    private lateinit var artImage: ImageView
    private lateinit var audioTitle: TextView
    private lateinit var audioSub: TextView
    private lateinit var bars: BarsView
    private var discAnimator: ObjectAnimator? = null
    private var controlsVisible = true
    private var userSeeking = false
    private var lastSeekAt = 0L

    // ---------- gesture state ----------
    private enum class Drag { NONE, SEEK, BRIGHTNESS, VOLUME, PAN }
    private var drag = Drag.NONE
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var seekStartPos = 0L
    private var seekTarget = 0L
    private var startBrightness = 0.5f
    private var startVolume = 0
    private var scaling = false

    private val updater = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && !userSeeking) {
                val dur = p.duration
                val pos = p.currentPosition
                if (dur != C.TIME_UNSET && dur > 0) {
                    seekBar.max = dur.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    seekBar.progress = pos.coerceIn(0, dur).toInt()
                    seekBar.secondaryProgress = p.bufferedPosition.coerceIn(0, dur).toInt()
                    durLabel.text = MediaFmt.time(dur)
                } else {
                    durLabel.text = "LIVE"
                }
                posLabel.text = MediaFmt.time(pos)
            }
            if (!isFinishing && !isDestroyed) handler.postDelayed(this, 250)
        }
    }
    private val hideRunnable = Runnable { if (showVideoUi() && player?.isPlaying == true) setControlsVisible(false) }

    // =====================================================================================
    // lifecycle
    // =====================================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data ?: run { finish(); return }
        currentName = intent.getStringExtra("name") ?: resolveName(uri)
        currentMime = intent.getStringExtra("mime") ?: intent.type ?: ""
        isVideoItem = when {
            currentMime.startsWith("video/") -> true
            currentMime.startsWith("audio/") -> false
            else -> !MediaKinds.isAudio(currentName)
        }
        // A closed (Back) audio screen keeps playing in AudioKeeper; reopening it from the mini player adopts that player.
        val kept = AudioKeeper.takeForActivity(intent.getBooleanExtra("adopt", false))
        if (kept != null) {
            adopted = kept
            playlist = kept.playlist; playlistNames = kept.names; index = kept.index
            repeatMode = kept.repeatMode; shuffle = kept.shuffle; speed = kept.speed
            equalizer = kept.equalizer
            currentName = kept.names.getOrNull(kept.index) ?: currentName
            isVideoItem = false
        } else buildPlaylist(uri)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        volumeControlStream = AudioManager.STREAM_MUSIC

        val keptSession = adopted
        if (keptSession != null) { player = keptSession.player; keptSession.player.addListener(playerListener) } else createPlayer()
        buildUi()
        applyOrientation()
        if (keptSession != null) {
            titleView.text = currentName
            audioTitle.text = currentName.substringBeforeLast('.')
            playBtn.setImageResource(if (keptSession.player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            updateRepeatShuffleIcons()
            updateNavButtons()
            loadAudioMeta(playlist[index])
            refreshUiMode()
            attachBackgroundPlayback()
        } else loadItem(index, true)
        handler.post(updater)
    }

    private fun createPlayer() {
        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, renderers)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setHandleAudioBecomingNoisy(true)
            .build()
        try { p.setWakeMode(C.WAKE_MODE_LOCAL) } catch (_: Throwable) { }
        p.setAudioAttributes(
            androidx.media3.common.AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(if (isVideoItem) C.AUDIO_CONTENT_TYPE_MOVIE else C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true
        )
        p.addListener(playerListener)
        player = p
    }

    private fun attachBackgroundPlayback() {
        val p = player ?: return
        val open = Intent(this, MediaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        PlaybackHub.attach(this, p, open) { currentName.substringBeforeLast('.').ifBlank { "OmniHub" } }
    }

    override fun onResume() {
        super.onResume()
        if (showVideoUi()) goImmersive()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && showVideoUi()) goImmersive()
    }

    override fun onPause() {
        super.onPause()
        savePosition()
        // Keep playing in the background (home / screen off / another app). Audio also keeps playing when this screen is
        // closed with Back (AudioKeeper + mini player); only video, or a finished/failed track, is paused on close.
        if (isFinishing && !keepAudioOnExit()) player?.pause()
    }

    override fun onStop() {
        super.onStop()
        savePosition()
    }

    /** True when closing this screen should leave the audio playing in the mini player. */
    private fun keepAudioOnExit(): Boolean {
        val p = player ?: return false
        if (!isFinishing || isChangingConfigurations || showVideoUi() || playlist.isEmpty()) return false
        return p.playbackState == Player.STATE_READY || p.playbackState == Player.STATE_BUFFERING
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        discAnimator?.cancel()
        savePosition()
        val keepPlayer = player
        if (keepPlayer != null && keepAudioOnExit()) {
            keepPlayer.removeListener(playerListener)
            try { textureView?.let { tv -> keepPlayer.clearVideoTextureView(tv) } } catch (_: Exception) { }
            AudioKeeper.keep(applicationContext, AudioKeeper.Session(keepPlayer, playlist, playlistNames, index, repeatMode, shuffle, speed, equalizer))
            player = null
            equalizer = null
            super.onDestroy()
            return
        }
        try { equalizer?.release() } catch (_: Exception) { }
        equalizer = null
        player?.let {
            it.removeListener(playerListener)
            PlaybackHub.detach(it)
            try { textureView?.let { tv -> it.clearVideoTextureView(tv) } } catch (_: Exception) { }
            it.release()
        }
        player = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        videoHolder.post { applyVideoLayout() }
    }

    @Deprecated("Compatibility fallback")
    override fun onBackPressed() {
        if (locked) { showLockedHint(); return }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (showVideoUi() && player?.isPlaying == true && !locked) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        controlsLayer.visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        if (!isInPictureInPictureMode) setControlsVisible(true)
    }

    // =====================================================================================
    // playlist / loading
    // =====================================================================================
    private fun buildPlaylist(uri: Uri) {
        if (uri.scheme == "file") {
            val file = File(uri.path ?: "")
            val kind: (String) -> Boolean = if (isVideoItem) { n -> MediaKinds.isVideo(n) } else { n -> MediaKinds.isAudio(n) }
            val siblings = MediaKinds.siblings(file, kind)
            playlist = siblings.map { Uri.fromFile(it) }
            playlistNames = siblings.map { it.name }
            index = siblings.indexOfFirst { it.absolutePath == file.absolutePath }.coerceAtLeast(0)
        } else {
            playlist = listOf(uri)
            playlistNames = listOf(currentName)
            index = 0
        }
    }

    private fun resolveName(uri: Uri): String {
        if (uri.scheme == "file") return File(uri.path ?: "").name.ifBlank { "Media" }
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: uri.lastPathSegment ?: "Media"
        } catch (_: Exception) { uri.lastPathSegment ?: "Media" }
    }

    private fun loadItem(i: Int, resume: Boolean) {
        val p = player ?: return
        if (playlist.isEmpty()) return
        savePosition()
        index = ((i % playlist.size) + playlist.size) % playlist.size
        val uri = playlist[index]
        currentName = playlistNames.getOrNull(index) ?: resolveName(uri)
        titleView.text = currentName
        audioTitle.text = currentName.substringBeforeLast('.')
        audioSub.text = ""
        hasVideoTrack = false
        subtitleView.text = ""
        subtitleView.visibility = View.GONE
        val builder = MediaItem.Builder().setUri(uri)
        val subs = sidecarSubtitles(uri)
        if (subs.isNotEmpty()) builder.setSubtitleConfigurations(subs)
        p.setMediaItem(builder.build())
        if (resume) {
            val saved = prefs.getLong("pos:$uri", 0L)
            if (saved > 3000) p.seekTo(saved)
        }
        p.setPlaybackSpeed(speed)
        p.repeatMode = if (repeatMode == 2) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        p.prepare()
        p.playWhenReady = true
        textureView?.let { p.setVideoTextureView(it) }
        loadAudioMeta(uri)
        updateNavButtons()
    }

    private fun savePosition() {
        val p = player ?: return
        if (playlist.isEmpty()) return
        try {
            val uri = playlist[index]
            val dur = p.duration
            val pos = p.currentPosition
            val edit = prefs.edit()
            if (dur != C.TIME_UNSET && dur > 0 && (pos > dur - 5000 || pos < 3000)) edit.remove("pos:$uri")
            else edit.putLong("pos:$uri", pos)
            edit.apply()
        } catch (_: Exception) { }
    }

    private fun sidecarSubtitles(uri: Uri): List<MediaItem.SubtitleConfiguration> {
        if (uri.scheme != "file") return emptyList()
        val source = File(uri.path ?: return emptyList())
        val stem = source.nameWithoutExtension
        val dir = source.parentFile ?: return emptyList()
        val files = try { dir.listFiles() } catch (_: Exception) { null } ?: return emptyList()
        val out = ArrayList<MediaItem.SubtitleConfiguration>()
        for (f in files) {
            if (!f.isFile || !f.name.startsWith(stem)) continue
            val mime = when (f.extension.lowercase(Locale.ROOT)) {
                "srt" -> MimeTypes.APPLICATION_SUBRIP
                "vtt" -> MimeTypes.TEXT_VTT
                "ass", "ssa" -> MimeTypes.TEXT_SSA
                "ttml", "dfxp" -> MimeTypes.APPLICATION_TTML
                else -> continue
            }
            val label = f.nameWithoutExtension.removePrefix(stem).trim('.', ' ', '_', '-').ifBlank { f.extension.uppercase(Locale.ROOT) }
            out.add(
                MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                    .setMimeType(mime)
                    .setLabel(label)
                    .build()
            )
        }
        return out
    }

    // =====================================================================================
    // player listener
    // =====================================================================================
    private val playerListener = object : Player.Listener {
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            applyOrientation()
            applyVideoLayout()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) attachBackgroundPlayback()
            playBtn.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            updateDisc(isPlaying)
            if (isPlaying) scheduleHide() else handler.removeCallbacks(hideRunnable)
            if (!isPlaying && showVideoUi()) setControlsVisible(true)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            spinner.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (playbackState == Player.STATE_ENDED) onEnded()
        }

        override fun onTracksChanged(tracks: Tracks) {
            hasVideoTrack = tracks.groups.any { it.type == C.TRACK_TYPE_VIDEO && it.length > 0 }
            if (isVideoItem && hasVideoTrack && !tracks.isTypeSupported(C.TRACK_TYPE_VIDEO, true)) {
                val codec = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_VIDEO }
                    ?.getTrackFormat(0)?.sampleMimeType ?: "unknown"
                Toast.makeText(
                    this@MediaActivity,
                    "এই ফোনের ডিকোডার ভিডিও কোডেক ($codec) চালাতে পারছে না — শুধু অডিও চলবে।",
                    Toast.LENGTH_LONG
                ).show()
            }
            refreshUiMode()
        }

        override fun onCues(cueGroup: CueGroup) {
            val text = cueGroup.cues.mapNotNull { it.text?.toString() }.joinToString("\n").trim()
            subtitleView.text = text
            subtitleView.visibility = if (text.isEmpty() || !showVideoUi()) View.GONE else View.VISIBLE
        }

        override fun onPlayerError(error: PlaybackException) {
            showPlayerError(error)
        }
    }

    private fun onEnded() {
        when {
            repeatMode == 2 -> { player?.seekTo(0); player?.play() }
            shuffle && playlist.size > 1 -> loadItem(randomOther(), false)
            playlist.size > 1 && (repeatMode == 1 || index < playlist.size - 1) -> loadItem(index + 1, false)
            else -> setControlsVisible(true)
        }
    }

    private fun randomOther(): Int {
        var r = index
        while (r == index) r = (Math.random() * playlist.size).toInt().coerceAtMost(playlist.size - 1)
        return r
    }

    private fun showPlayerError(error: PlaybackException) {
        if (isFinishing || isDestroyed) return
        val msg = "ফাইলটি চালানো যায়নি।\n\nকারণ: ${error.errorCodeName}\n${error.localizedMessage ?: ""}\n\n" +
            "ফাইল নষ্ট, DRM-সুরক্ষিত, বা এই ফোনে কোডেক নেই — এমন হতে পারে।"
        AlertDialog.Builder(this)
            .setTitle("Playback error")
            .setMessage(msg)
            .setPositiveButton("Other app") { _, _ -> MediaShare.openWithOtherApp(this, playlist[index], currentMime) }
            .setNegativeButton("Close", null)
            .show()
    }

    // =====================================================================================
    // UI construction
    // =====================================================================================
    /** Video UI is shown for video files until the tracks say there really is no picture. */
    private fun showVideoUi(): Boolean {
        if (!isVideoItem) return false
        if (hasVideoTrack) return true
        return player?.currentTracks?.groups?.isEmpty() != false
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        videoHolder = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); clipChildren = true }
        val tv = TextureView(this)
        textureView = tv
        videoHolder.addView(tv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { player?.setVideoTextureView(tv) }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
        videoHolder.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - t != ob - ot) applyVideoLayout()
        }
        root.addView(videoHolder, FrameLayout.LayoutParams(-1, -1))

        audioPanel = buildAudioPanel()
        root.addView(audioPanel, FrameLayout.LayoutParams(-1, -1))

        subtitleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, subtitleTextSize)
            gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 2f, Color.BLACK)
            setPadding(dp(24), dp(4), dp(24), dp(56))
            visibility = View.GONE
        }
        root.addView(subtitleView, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        touchLayer = View(this)
        installGestures(touchLayer)
        root.addView(touchLayer, FrameLayout.LayoutParams(-1, -1))

        controlsLayer = FrameLayout(this)
        buildControls()
        root.addView(controlsLayer, FrameLayout.LayoutParams(-1, -1))

        feedbackView = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(12), dp(22), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0xAA000000.toInt()) }
            visibility = View.GONE
        }
        root.addView(feedbackView, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        spinner = ProgressBar(this).apply {
            indeterminateTintList = ColorStateList.valueOf(accent)
            visibility = View.GONE
        }
        root.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        setContentView(root)
        InsetsUtil.applyOverlay(this, root) { i ->
            controlsLayer.setPadding(i.left, i.top, i.right, i.bottom)
            subtitleView.translationY = -i.bottom.toFloat()
        }
        refreshUiMode()
    }

    /** [left, top, right, bottom] of system bars + display cutout. */
    @Suppress("DEPRECATION")
    private fun safeInsets(insets: WindowInsets): IntArray =
        if (Build.VERSION.SDK_INT >= 30) {
            val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            intArrayOf(i.left, i.top, i.right, i.bottom)
        } else {
            intArrayOf(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
        }

    private fun buildControls() {
        // ---- top bar ----
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
        }
        topBar.addView(iconButton(R.drawable.ic_back, "Back") { if (locked) showLockedHint() else finish() })
        topBar.addView(HomeNavigation.makeHomeButton(this), LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(2); rightMargin = dp(2) })
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            isSingleLine = true; ellipsize = TextUtils.TruncateAt.MARQUEE; isSelected = true
            setPadding(dp(6), 0, dp(6), 0)
        }
        topBar.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(iconButton(R.drawable.ic_more, "More") { showMoreMenu() })
        controlsLayer.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- center transport ----
        centerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        centerRow.addView(iconButton(R.drawable.ic_prev, "Previous", 56) { previous() })
        playBtn = iconButton(R.drawable.ic_pause, "Play/Pause", 72) { togglePlay() }
        playBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC62E4D3.toInt()) }
        playBtn.imageTintList = ColorStateList.valueOf(Color.rgb(8, 16, 24))
        playBtn.setPadding(dp(18), dp(18), dp(18), dp(18))
        centerRow.addView(playBtn, LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(dp(24), 0, dp(24), 0) })
        centerRow.addView(iconButton(R.drawable.ic_next, "Next", 56) { next() })
        controlsLayer.addView(centerRow, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // ---- unlock button (only shown while locked) ----
        unlockBtn = iconButton(R.drawable.ic_unlock, "Unlock", 56) { setLocked(false) }
        unlockBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xAA000000.toInt()) }
        unlockBtn.visibility = View.GONE
        controlsLayer.addView(unlockBtn, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(24) })

        // ---- bottom bar ----
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(24), dp(14), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xDD000000.toInt(), 0x00000000))
        }
        val seekRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        posLabel = timeLabel("00:00")
        durLabel = timeLabel("00:00")
        seekBar = SeekBar(this).apply {
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
            secondaryProgressTintList = ColorStateList.valueOf(0x88FFFFFF.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    posLabel.text = MediaFmt.time(progress.toLong())
                    val now = System.currentTimeMillis()
                    if (now - lastSeekAt > 150) { lastSeekAt = now; player?.seekTo(progress.toLong()) }
                }
                override fun onStartTrackingTouch(sb: SeekBar) { userSeeking = true; handler.removeCallbacks(hideRunnable) }
                override fun onStopTrackingTouch(sb: SeekBar) {
                    userSeeking = false
                    player?.seekTo(sb.progress.toLong())
                    scheduleHide()
                }
            })
        }
        seekRow.addView(posLabel, LinearLayout.LayoutParams(dp(58), -2))
        seekRow.addView(seekBar, LinearLayout.LayoutParams(0, dp(40), 1f))
        seekRow.addView(durLabel, LinearLayout.LayoutParams(dp(58), -2))
        bottomBar.addView(seekRow)

        val toolsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tools = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        lockBtn = iconButton(R.drawable.ic_lock, "Lock") { setLocked(true) }
        aspectChip = chip(aspectNames[0], R.drawable.ic_aspect) { cycleAspect() }
        speedChip = chip("1.0x", R.drawable.ic_speed) { showSpeedDialog() }
        val subBtn = iconButton(R.drawable.ic_subtitle, "Subtitles") { showTrackDialog(C.TRACK_TYPE_TEXT, "Subtitles") }
        val audBtn = iconButton(R.drawable.ic_audiotrack, "Audio track") { showTrackDialog(C.TRACK_TYPE_AUDIO, "Audio track") }
        hdChip = chip("HD", R.drawable.ic_hd) { showUpscaleDialog() }
        val rotBtn = iconButton(R.drawable.ic_rotate, "Rotate") { cycleOrientation() }
        val pipBtn = iconButton(R.drawable.ic_pip, "Picture in picture") { enterPip() }
        val backTen = iconButton(R.drawable.ic_replay10, "Back 10s") { seekBy(-10_000) }
        val fwdTen = iconButton(R.drawable.ic_forward10, "Forward 10s") { seekBy(10_000) }
        repeatBtn = iconButton(R.drawable.ic_repeat, "Repeat") { cycleRepeat() }
        shuffleBtn = iconButton(R.drawable.ic_shuffle, "Shuffle") { toggleShuffle() }
        val eqBtn = iconButton(R.drawable.ic_equalizer, "Equalizer") { showEqualizer() }

        val all = listOf<View>(lockBtn, backTen, fwdTen, aspectChip, speedChip, subBtn, audBtn, hdChip, rotBtn, pipBtn, repeatBtn, shuffleBtn, eqBtn)
        for (v in all) {
            if (v is TextView) tools.addView(v, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(4), 0, dp(4), 0) })
            else tools.addView(v)
        }
        videoOnlyTools = listOf(lockBtn, aspectChip, hdChip, rotBtn, pipBtn)
        toolsScroll.addView(tools)
        bottomBar.addView(toolsScroll, LinearLayout.LayoutParams(-1, -2))
        controlsLayer.addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        updateRepeatShuffleIcons()
    }

    private fun buildAudioPanel(): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(dp(24), dp(72), dp(24), dp(150))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(30, 41, 75), Color.rgb(8, 10, 16)))
        }
        val size = dp(230)
        discView = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = size / 2f
                colors = intArrayOf(Color.rgb(70, 90, 160), Color.rgb(20, 24, 40))
                setStroke(dp(6), Color.rgb(12, 14, 22))
            }
            elevation = dp(12).toFloat()
        }
        artImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(R.drawable.ic_music)
            imageTintList = ColorStateList.valueOf(Color.argb(200, 147, 197, 253))
            setPadding(dp(70), dp(70), dp(70), dp(70))
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) { outline.setOval(0, 0, view.width, view.height) }
            }
            clipToOutline = true
        }
        discView.addView(artImage, FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
        panel.addView(discView, LinearLayout.LayoutParams(size, size))
        audioTitle = TextView(this).apply {
            setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(22), 0, dp(4))
        }
        audioSub = TextView(this).apply {
            setTextColor(Color.rgb(160, 174, 200)); setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); gravity = Gravity.CENTER; maxLines = 2
        }
        panel.addView(audioTitle, LinearLayout.LayoutParams(-1, -2))
        panel.addView(audioSub, LinearLayout.LayoutParams(-1, -2))
        bars = BarsView(this)
        panel.addView(bars, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(18) })
        return panel
    }

    // ---- small view helpers ----
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun ripple(): Drawable {
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        return RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), null, mask)
    }

    private fun iconButton(res: Int, desc: String, sizeDp: Int = 44, onClick: () -> Unit): ImageButton =
        ImageButton(this).apply {
            setImageResource(res)
            contentDescription = desc
            background = ripple()
            scaleType = ImageView.ScaleType.FIT_CENTER
            val pad = dp(if (sizeDp >= 56) 14 else 10)
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
            setOnClickListener { onClick(); scheduleHide() }
        }

    private fun chip(label: String, iconRes: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), 0, dp(14), 0)
        compoundDrawablePadding = dp(6)
        setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0)
        compoundDrawableTintList = ColorStateList.valueOf(Color.WHITE)
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0x33FFFFFF) }
        setOnClickListener { onClick(); scheduleHide() }
    }

    private fun timeLabel(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f); gravity = Gravity.CENTER
    }

    private fun refreshUiMode() {
        val video = showVideoUi()
        videoHolder.visibility = if (video) View.VISIBLE else View.GONE
        audioPanel.visibility = if (video) View.GONE else View.VISIBLE
        videoOnlyTools.forEach { it.visibility = if (video) View.VISIBLE else View.GONE }
        subtitleView.visibility = if (video && subtitleView.text.isNotEmpty()) View.VISIBLE else View.GONE
        if (video) goImmersive() else {
            setControlsVisible(true)
            handler.removeCallbacks(hideRunnable)
        }
        updateDisc(player?.isPlaying == true)
        applyOrientation()
    }

    // =====================================================================================
    // controls behaviour
    // =====================================================================================
    private fun togglePlay() {
        val p = player ?: return
        if (p.playbackState == Player.STATE_ENDED) { p.seekTo(0); p.play() }
        else if (p.isPlaying) p.pause() else p.play()
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val dur = p.duration
        var target = p.currentPosition + deltaMs
        target = if (dur != C.TIME_UNSET && dur > 0) target.coerceIn(0, dur) else max(0, target)
        p.seekTo(target)
    }

    private fun next() { if (playlist.size > 1) loadItem(if (shuffle) randomOther() else index + 1, false) else seekBy(10_000) }

    private fun previous() {
        val p = player
        if (p != null && p.currentPosition > 4000) p.seekTo(0)
        else if (playlist.size > 1) loadItem(index - 1, false)
        else seekBy(-10_000)
    }

    private fun updateNavButtons() {
        val a = if (playlist.size > 1) 1f else 0.5f
        centerRow.getChildAt(0).alpha = a
        centerRow.getChildAt(2).alpha = a
    }

    private fun setControlsVisible(visible: Boolean) {
        if (inPip) return
        controlsVisible = visible
        if (locked) {
            unlockBtn.visibility = if (visible) View.VISIBLE else View.GONE
            topBar.visibility = View.GONE; bottomBar.visibility = View.GONE; centerRow.visibility = View.GONE
            return
        }
        unlockBtn.visibility = View.GONE
        val show = visible || !showVideoUi()
        for (view in listOf<View>(topBar, bottomBar, centerRow)) {
            view.animate().cancel()
            if (show) {
                view.visibility = View.VISIBLE
                view.animate().alpha(1f).setDuration(160).start()
            } else {
                view.animate().alpha(0f).setDuration(160).withEndAction { view.visibility = View.GONE }.start()
            }
        }
        if (show) scheduleHide()
    }

    private fun toggleControls() = setControlsVisible(!controlsVisible)

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        if (showVideoUi() && player?.isPlaying == true && !userSeeking) handler.postDelayed(hideRunnable, 3500)
    }

    private fun setLocked(value: Boolean) {
        locked = value
        if (value) {
            showFeedback("Screen locked", 800)
            showLockedHint()
        } else {
            setControlsVisible(true)
            showFeedback("Unlocked", 700)
        }
    }

    private fun showLockedHint() {
        setControlsVisible(true)
        handler.postDelayed({ if (locked) setControlsVisible(false) }, 2000)
    }

    private var feedbackHide: Runnable? = null
    private fun showFeedback(text: String, durationMs: Long = 700) {
        feedbackView.text = text
        feedbackView.visibility = View.VISIBLE
        feedbackHide?.let { handler.removeCallbacks(it) }
        val r = Runnable { feedbackView.visibility = View.GONE }
        feedbackHide = r
        handler.postDelayed(r, durationMs)
    }

    // =====================================================================================
    // gestures
    // =====================================================================================
    private fun installGestures(view: View) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { toggleControls(); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked || !showVideoUi()) return true
                val w = view.width.toFloat()
                when {
                    e.x < w / 3f -> { seekBy(-10_000); showFeedback("« 10s", 500) }
                    e.x > w * 2f / 3f -> { seekBy(10_000); showFeedback("10s »", 500) }
                    else -> togglePlay()
                }
                return true
            }
        })
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean { scaling = true; return true }
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                userScale = (userScale * detector.scaleFactor).coerceIn(0.5f, 6f)
                applyUserTransform()
                showFeedback("Zoom ${(userScale * 100).toInt()}%", 500)
                return true
            }
            override fun onScaleEnd(detector: ScaleGestureDetector) { scaling = false }
        })
        view.setOnTouchListener { v, ev ->
            tapDetector.onTouchEvent(ev)
            if (locked || !showVideoUi()) return@setOnTouchListener true
            scaleDetector.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; lastX = ev.x; lastY = ev.y
                    drag = Drag.NONE
                    seekStartPos = player?.currentPosition ?: 0L
                    startBrightness = currentBrightness()
                    startVolume = (getSystemService(AUDIO_SERVICE) as AudioManager).getStreamVolume(AudioManager.STREAM_MUSIC)
                }
                MotionEvent.ACTION_MOVE -> if (ev.pointerCount == 1 && !scaling) {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (drag == Drag.NONE && (abs(dx) > slop * 2 || abs(dy) > slop * 2)) {
                        drag = if (abs(dx) > abs(dy)) {
                            if (userScale > 1.05f) Drag.PAN else Drag.SEEK
                        } else if (downX < v.width / 2f) Drag.BRIGHTNESS else Drag.VOLUME
                    }
                    when (drag) {
                        Drag.SEEK -> {
                            val dur = player?.duration ?: 0L
                            val known = dur > 0 && dur != C.TIME_UNSET
                            val span = if (known) min(dur, 600_000L) else 600_000L
                            var t = (seekStartPos + (dx / v.width) * span).toLong()
                            t = if (known) t.coerceIn(0, dur) else max(0, t)
                            seekTarget = t
                            val delta = (t - seekStartPos) / 1000
                            showFeedback("${MediaFmt.time(t)}\n[${if (delta >= 0) "+" else ""}${delta}s]", 600)
                        }
                        Drag.BRIGHTNESS -> {
                            val value = (startBrightness - dy / v.height * 1.3f).coerceIn(0.02f, 1f)
                            setBrightness(value)
                            showFeedback("Brightness ${(value * 100).toInt()}%", 500)
                        }
                        Drag.VOLUME -> {
                            val am = getSystemService(AUDIO_SERVICE) as AudioManager
                            val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            val target = (startVolume - dy / v.height * maxV * 1.3f).toInt().coerceIn(0, maxV)
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                            showFeedback("Volume ${if (maxV > 0) target * 100 / maxV else 0}%", 500)
                        }
                        Drag.PAN -> {
                            userTx += ev.x - lastX
                            userTy += ev.y - lastY
                            applyUserTransform()
                        }
                        Drag.NONE -> {}
                    }
                    lastX = ev.x; lastY = ev.y
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (drag == Drag.SEEK) player?.seekTo(seekTarget)
                    drag = Drag.NONE
                }
            }
            true
        }
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) { 0.5f }
    }

    private fun setBrightness(v: Float) {
        window.attributes = window.attributes.also { it.screenBrightness = v }
    }

    // =====================================================================================
    // video layout, zoom, aspect, orientation, upscale
    // =====================================================================================
    private fun applyVideoLayout() {
        val tv = textureView ?: return
        val w = videoHolder.width
        val h = videoHolder.height
        if (w <= 0 || h <= 0) return
        val vs = player?.videoSize ?: VideoSize.UNKNOWN
        val vw = if (vs.width > 0) vs.width * (if (vs.pixelWidthHeightRatio > 0) vs.pixelWidthHeightRatio else 1f) else w.toFloat()
        val vh = if (vs.height > 0) vs.height.toFloat() else h.toFloat()
        val fit = min(w / vw, h / vh)
        val fill = max(w / vw, h / vh)
        val size: Pair<Float, Float> = when (aspectMode) {
            0 -> Pair(vw * fit, vh * fit)
            1 -> Pair(vw * fill, vh * fill)
            2 -> Pair(w.toFloat(), h.toFloat())
            3 -> Pair(vw, vh)
            4 -> ratioFit(w, h, 16f / 9f)
            else -> ratioFit(w, h, 4f / 3f)
        }
        tv.layoutParams = FrameLayout.LayoutParams(size.first.toInt().coerceAtLeast(1), size.second.toInt().coerceAtLeast(1), Gravity.CENTER)
        applyUserTransform()
    }

    private fun ratioFit(w: Int, h: Int, ratio: Float): Pair<Float, Float> {
        val byWidth = Pair(w.toFloat(), w / ratio)
        return if (byWidth.second <= h) byWidth else Pair(h * ratio, h.toFloat())
    }

    private fun applyUserTransform() {
        val tv = textureView ?: return
        if (userScale <= 1.01f) { userTx = 0f; userTy = 0f }
        val maxX = tv.width * userScale / 2f
        val maxY = tv.height * userScale / 2f
        userTx = userTx.coerceIn(-maxX, maxX)
        userTy = userTy.coerceIn(-maxY, maxY)
        tv.scaleX = userScale
        tv.scaleY = userScale
        tv.translationX = userTx
        tv.translationY = userTy
    }

    private fun cycleAspect() {
        aspectMode = (aspectMode + 1) % aspectNames.size
        userScale = 1f; userTx = 0f; userTy = 0f
        aspectChip.text = aspectNames[aspectMode]
        applyVideoLayout()
        showFeedback(aspectNames[aspectMode])
    }

    private fun applyOrientation() {
        val vs = player?.videoSize ?: VideoSize.UNKNOWN
        val portraitVideo = vs.width > 0 && vs.height > vs.width
        requestedOrientation = when {
            !showVideoUi() -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            orientMode == 1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            orientMode == 2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            orientMode == 3 -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            portraitVideo -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    private fun cycleOrientation() {
        orientMode = (orientMode + 1) % 4
        applyOrientation()
        showFeedback(listOf("Auto (by video)", "Landscape", "Portrait", "Sensor")[orientMode])
    }

    private fun showUpscaleDialog() {
        val labels = arrayOf("Off", "2x HD", "3.5x HD (strongest)")
        AlertDialog.Builder(this).setTitle("HD render")
            .setSingleChoiceItems(labels, upscaleLevel) { d, which ->
                setUpscaleLevel(which)
                d.dismiss()
            }.show()
    }

    private fun setUpscaleLevel(level: Int) {
        upscaleLevel = level.coerceIn(0, 2)
        applyUpscale()
        hdChip.text = when (upscaleLevel) { 1 -> "2x HD"; 2 -> "3.5x HD"; else -> "HD" }
        hdChip.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (upscale) 0xFF62E4D3.toInt() else 0x33FFFFFF)
        }
        val fg = if (upscale) Color.rgb(8, 16, 24) else Color.WHITE
        hdChip.setTextColor(fg)
        hdChip.compoundDrawableTintList = ColorStateList.valueOf(fg)
        showFeedback(when (upscaleLevel) { 1 -> "2x HD: ON"; 2 -> "3.5x HD: ON"; else -> "HD render: OFF" }, 900)
    }

    /**
     * "2x HD" / "3.5x HD": GPU sharpen + contrast/saturation boost on the video scaled up to the screen.
     * API 33+: AGSL unsharp-mask shader. Older: colour-matrix boost. (Enhancement, not AI super-resolution.)
     * 3.5x uses a stronger sharpen amount, a wider sampling radius and more contrast than 2x.
     */
    private fun applyUpscale() {
        val tv = textureView ?: return
        val strong = upscaleLevel == 2
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                if (upscale) {
                    val shader = RuntimeShader(SHARPEN_AGSL)
                    shader.setFloatUniform("amount", if (strong) 2.0f else 1.1f)
                    shader.setFloatUniform("radius", if (strong) 1.5f else 1.0f)
                    shader.setFloatUniform("punch", if (strong) 1.14f else 1.06f)
                    tv.setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "content"))
                } else tv.setRenderEffect(null)
                return
            } catch (_: Throwable) { /* fall back to the colour matrix below */ }
        }
        if (upscale) {
            val cm = ColorMatrix().apply { setSaturation(if (strong) 1.32f else 1.18f) }
            val c = if (strong) 1.24f else 1.12f
            val t = (-0.5f * c + 0.5f) * 255f
            cm.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
            tv.setLayerPaint(Paint().apply { colorFilter = ColorMatrixColorFilter(cm); isFilterBitmap = true })
        } else tv.setLayerPaint(null)
    }

    @Suppress("DEPRECATION")
    private fun goImmersive() {
        if (inPip) return
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !showVideoUi()) {
            Toast.makeText(this, "PiP not available", Toast.LENGTH_SHORT).show(); return
        }
        try {
            val vs = player?.videoSize ?: VideoSize.UNKNOWN
            val w = if (vs.width > 0) vs.width else 16
            val h = if (vs.height > 0) vs.height else 9
            val f = w.toFloat() / h
            val ratio = if (f > 2.39f) Rational(239, 100) else if (f < 0.4184f) Rational(100, 239) else Rational(w, h)
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        } catch (_: Exception) {
            Toast.makeText(this, "PiP not supported on this device", Toast.LENGTH_SHORT).show()
        }
    }

    // =====================================================================================
    // dialogs & menus
    // =====================================================================================
    private fun showSpeedDialog() {
        val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f, 3.5f, 4f)
        val labels = speeds.map { String.format(Locale.US, "%.2fx", it) }.toTypedArray()
        val checked = speeds.indexOfFirst { abs(it - speed) < 0.01f }
        AlertDialog.Builder(this).setTitle("Playback speed")
            .setSingleChoiceItems(labels, checked) { d, which ->
                speed = speeds[which]
                player?.setPlaybackSpeed(speed)
                speedChip.text = String.format(Locale.US, "%.1fx", speed)
                d.dismiss()
            }.show()
    }

    private fun trackLabel(f: Format, n: Int): String {
        val parts = ArrayList<String>()
        val lang = f.language
        val langName = if (!lang.isNullOrBlank() && lang != "und") Locale(lang).displayLanguage.ifBlank { lang } else null
        parts.add(f.label ?: langName ?: "Track $n")
        if (f.label != null && langName != null) parts.add(langName)
        if (MimeTypes.isAudio(f.sampleMimeType)) {
            f.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT)?.let { parts.add(it) }
            if (f.channelCount > 0) parts.add("${f.channelCount}ch")
        }
        return parts.joinToString(" · ")
    }

    private fun showTrackDialog(type: Int, title: String) {
        val p = player ?: return
        val textOff = p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        val groups = p.currentTracks.groups.filter { it.type == type }
        val labels = ArrayList<String>()
        val picks = ArrayList<Pair<Tracks.Group, Int>?>()
        var checked = -1
        if (type == C.TRACK_TYPE_TEXT) {
            labels.add("Off"); picks.add(null)
            if (textOff || groups.none { it.isSelected }) checked = 0
        }
        var n = 1
        for (g in groups) for (i in 0 until g.length) {
            if (!g.isTrackSupported(i)) continue
            labels.add(trackLabel(g.getTrackFormat(i), n++))
            picks.add(Pair(g, i))
            if (g.isTrackSelected(i) && !(type == C.TRACK_TYPE_TEXT && textOff)) checked = labels.size - 1
        }
        if (labels.isEmpty() || (type == C.TRACK_TYPE_TEXT && labels.size == 1)) {
            Toast.makeText(
                this,
                if (type == C.TRACK_TYPE_TEXT) "No subtitles found (embedded or same-name .srt/.vtt/.ass)" else "No alternative audio tracks",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        AlertDialog.Builder(this).setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                val pick = picks[which]
                val b = p.trackSelectionParameters.buildUpon()
                if (pick == null) b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                else {
                    b.setTrackTypeDisabled(type, false)
                    b.setOverrideForType(TrackSelectionOverride(pick.first.mediaTrackGroup, listOf(pick.second)))
                }
                p.trackSelectionParameters = b.build()
                d.dismiss()
            }.show()
    }

    private fun showMoreMenu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("Sleep timer" to { showSleepTimer() })
        items.add("Subtitle size" to { showSubtitleSize() })
        items.add("Media info" to { showInfo() })
        items.add("Share" to { MediaShare.share(this, playlist[index], currentMime) })
        items.add("Open with other app" to { MediaShare.openWithOtherApp(this, playlist[index], currentMime) })
        if (currentMime.startsWith("audio/")) items.add("Set as ringtone…" to { SetAs.ringtone(this, playlist[index], playlistNames.getOrNull(index)) })
        AlertDialog.Builder(this).setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }.show()
    }

    private fun showSleepTimer() {
        val labels = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes")
        val mins = intArrayOf(0, 15, 30, 45, 60, 90)
        AlertDialog.Builder(this).setTitle("Sleep timer").setItems(labels) { _, i ->
            sleepRunnable?.let { handler.removeCallbacks(it) }
            sleepRunnable = null
            if (mins[i] > 0) {
                val r = Runnable { player?.pause(); Toast.makeText(this, "Sleep timer: paused", Toast.LENGTH_LONG).show() }
                sleepRunnable = r
                handler.postDelayed(r, mins[i] * 60_000L)
                Toast.makeText(this, "Will pause in ${mins[i]} min", Toast.LENGTH_SHORT).show()
            }
        }.show()
    }

    private fun showSubtitleSize() {
        val sizes = floatArrayOf(14f, 18f, 20f, 24f, 28f, 34f)
        val labels = arrayOf("Small", "Medium", "Default", "Large", "Extra large", "Huge")
        AlertDialog.Builder(this).setTitle("Subtitle size").setItems(labels) { _, i ->
            subtitleTextSize = sizes[i]
            subtitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, subtitleTextSize)
        }.show()
    }

    private fun showInfo() {
        val p = player ?: return
        val sb = StringBuilder()
        sb.append("Name: ").append(currentName).append('\n')
        val uri = playlist[index]
        if (uri.scheme == "file") {
            val f = File(uri.path ?: "")
            sb.append("Folder: ").append(f.parentFile?.name ?: "").append('\n')
            sb.append("Size: ").append(MediaFmt.size(f.length())).append('\n')
        }
        if (p.duration != C.TIME_UNSET) sb.append("Duration: ").append(MediaFmt.time(p.duration)).append('\n')
        for (g in p.currentTracks.groups) for (i in 0 until g.length) {
            if (!g.isTrackSelected(i)) continue
            val f = g.getTrackFormat(i)
            when (g.type) {
                C.TRACK_TYPE_VIDEO -> sb.append("Video: ").append(f.sampleMimeType).append(' ').append(f.width).append('x').append(f.height)
                    .append(if (f.frameRate > 0) " @ ${f.frameRate.toInt()}fps" else "")
                    .append(if (f.bitrate > 0) " · ${f.bitrate / 1000} kbps" else "").append('\n')
                C.TRACK_TYPE_AUDIO -> sb.append("Audio: ").append(f.sampleMimeType).append(' ').append(f.channelCount).append("ch ")
                    .append(f.sampleRate).append("Hz")
                    .append(if (f.bitrate > 0) " · ${f.bitrate / 1000} kbps" else "").append('\n')
            }
        }
        AlertDialog.Builder(this).setTitle("Media info").setMessage(sb.toString()).setPositiveButton("OK", null).show()
    }

    private fun showEqualizer() {
        val p = player ?: return
        val sid = p.audioSessionId
        if (sid == C.AUDIO_SESSION_ID_UNSET) { Toast.makeText(this, "Equalizer not ready yet", Toast.LENGTH_SHORT).show(); return }
        try {
            val eq = equalizer ?: Equalizer(0, sid).also { it.enabled = true; equalizer = it }
            val range = eq.bandLevelRange
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
            for (b in 0 until eq.numberOfBands) {
                val band = b.toShort()
                val hz = eq.getCenterFreq(band) / 1000
                box.addView(TextView(this).apply { text = if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz" })
                box.addView(SeekBar(this).apply {
                    max = range[1] - range[0]
                    progress = eq.getBandLevel(band) - range[0]
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                            if (fromUser) try { eq.setBandLevel(band, (progress + range[0]).toShort()) } catch (_: Exception) { }
                        }
                        override fun onStartTrackingTouch(sb: SeekBar) {}
                        override fun onStopTrackingTouch(sb: SeekBar) {}
                    })
                })
            }
            AlertDialog.Builder(this).setTitle("Equalizer")
                .setView(ScrollView(this).apply { addView(box) })
                .setPositiveButton("Done", null).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Equalizer not supported on this device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cycleRepeat() {
        repeatMode = (repeatMode + 1) % 3
        player?.repeatMode = if (repeatMode == 2) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        updateRepeatShuffleIcons()
        showFeedback(listOf("Repeat: off", "Repeat: all", "Repeat: one")[repeatMode])
    }

    private fun toggleShuffle() {
        shuffle = !shuffle
        updateRepeatShuffleIcons()
        showFeedback(if (shuffle) "Shuffle: on" else "Shuffle: off")
    }

    private fun updateRepeatShuffleIcons() {
        repeatBtn.imageTintList = ColorStateList.valueOf(if (repeatMode != 0) accent else Color.WHITE)
        shuffleBtn.imageTintList = ColorStateList.valueOf(if (shuffle) accent else Color.WHITE)
    }

    // =====================================================================================
    // audio extras: metadata, album art, rotating disc
    // =====================================================================================
    private fun loadAudioMeta(uri: Uri) {
        Thread {
            var title: String? = null
            var artist: String? = null
            var album: String? = null
            var art: Bitmap? = null
            val r = MediaMetadataRetriever()
            try {
                if (uri.scheme == "file") r.setDataSource(uri.path) else r.setDataSource(this, uri)
                title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                album = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                r.embeddedPicture?.let { bytes ->
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var s = 1
                    while (o.outWidth / s > 800 || o.outHeight / s > 800) s *= 2
                    art = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                }
            } catch (_: Throwable) {
            } finally { try { r.release() } catch (_: Exception) { } }
            runOnUiThread {
                if (isFinishing || isDestroyed || playlist.getOrNull(index) != uri) return@runOnUiThread
                if (!title.isNullOrBlank()) audioTitle.text = title
                audioSub.text = listOfNotNull(artist, album).filter { it.isNotBlank() }.joinToString(" — ")
                val bmp = art
                if (bmp != null) {
                    artImage.imageTintList = null
                    artImage.setPadding(0, 0, 0, 0)
                    artImage.setImageBitmap(bmp)
                    val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
                    val dark = Color.rgb((Color.red(px) * 0.45f).toInt(), (Color.green(px) * 0.45f).toInt(), (Color.blue(px) * 0.45f).toInt())
                    audioPanel.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(dark, Color.rgb(8, 10, 16)))
                } else {
                    artImage.setImageResource(R.drawable.ic_music)
                    artImage.imageTintList = ColorStateList.valueOf(Color.argb(200, 147, 197, 253))
                    artImage.setPadding(dp(70), dp(70), dp(70), dp(70))
                    audioPanel.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(30, 41, 75), Color.rgb(8, 10, 16)))
                }
            }
        }.start()
    }

    private fun updateDisc(playing: Boolean) {
        bars.active = playing
        val a = discAnimator ?: ObjectAnimator.ofFloat(discView, View.ROTATION, 0f, 360f).apply {
            duration = 14_000; interpolator = LinearInterpolator(); repeatCount = ValueAnimator.INFINITE
        }.also { discAnimator = it }
        if (playing && !showVideoUi()) { if (!a.isStarted) a.start() else a.resume() }
        else if (a.isStarted) a.pause()
    }

    /** Decorative animated equaliser bars for the audio screen (not a real spectrum analyser). */
    private class BarsView(context: Context) : View(context) {
        var active = false
        private val levels = FloatArray(32) { 0.05f }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(98, 228, 211) }
        private val tick = object : Runnable {
            override fun run() {
                for (i in levels.indices) {
                    val target = if (active) 0.15f + Math.random().toFloat() * 0.85f else 0.04f
                    levels[i] += (target - levels[i]) * 0.35f
                }
                invalidate()
                if (isAttachedToWindow) postDelayed(this, 70)
            }
        }
        override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
        override fun onDraw(canvas: Canvas) {
            val n = levels.size
            val gap = width / n.toFloat()
            val bw = gap * 0.55f
            for (i in 0 until n) {
                val h = levels[i] * height
                val x = i * gap + (gap - bw) / 2
                paint.alpha = 120 + (levels[i] * 135).toInt()
                canvas.drawRoundRect(x, height - h, x + bw, height.toFloat(), bw / 2, bw / 2, paint)
            }
        }
    }

    companion object {
        private const val SHARPEN_AGSL = """
            uniform shader content;
            uniform float amount;
            uniform float radius;
            uniform float punch;
            half4 main(float2 p) {
                half4 c = content.eval(p);
                half4 n = content.eval(p + float2(0.0, -radius));
                half4 s = content.eval(p + float2(0.0, radius));
                half4 e = content.eval(p + float2(radius, 0.0));
                half4 w = content.eval(p + float2(-radius, 0.0));
                half4 avg = (n + s + e + w) * 0.25;
                half3 rgb = c.rgb + (c.rgb - avg.rgb) * half(amount);
                rgb = (rgb - 0.5) * half(punch) + 0.5;
                return half4(clamp(rgb, 0.0, 1.0), c.a);
            }
        """
    }
}
