package com.example.omnihub

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

/** Streaming content fingerprint. Returns null when a file cannot be read completely. */
internal object FileContentHash {
    fun sha256(file: File): String? = try {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count > 0) digest.update(buffer, 0, count)
            }
        }
        digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    } catch (_: Throwable) {
        null
    }
}
