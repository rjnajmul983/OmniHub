package com.example.omnihub

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.webkit.MimeTypeMap
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.widget.ScrollView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.view.ScaleGestureDetector
import android.view.MotionEvent
import android.content.Context
import android.graphics.Outline
import android.view.ViewOutlineProvider
import android.widget.Space
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.Collections
import java.util.concurrent.Semaphore
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import android.util.LruCache
import android.os.Handler
import android.os.FileObserver
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import android.os.Looper
import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import java.util.concurrent.Future
import java.util.concurrent.FutureTask
import java.util.concurrent.Callable

/** In-app shared-storage browser. It deliberately does not launch ACTION_OPEN_DOCUMENT. */
class FileManagerActivity : Activity() {
    private val bg = Color.rgb(242, 240, 247)
    private val panel = Color.rgb(252, 251, 254)
    private val panelAlt = Color.rgb(232, 229, 241)
    private val textColor = Color.rgb(37, 34, 47)
    private val mutedColor = Color.rgb(94, 88, 112)
    private val accent = Color.rgb(102, 80, 196)

    private var mode = "any"
    private var initialCategory = ""
    private var mimeConstraint = "*/*"
    private var selectedExtension = ""
    private var browseFilterMode = ""
    private var initialBrowseQuery = ""
    private var browseFocusApplied = false
    private var globalIndexMode = false
    private val indexedFiles = mutableListOf<File>()
    private val indexDirectory by lazy { File(filesDir, "omnihub_media_index_v3") }
    private val thumbnailKeysInFlight = Collections.synchronizedSet(mutableSetOf<String>())
    private val thumbnailSlots = Semaphore(24)
    private var cacheLoadStarted = false
    private val scanExecutor = Executors.newSingleThreadExecutor()
    // Background-priority workers: decoding thumbnails must never steal CPU from the UI thread while scrolling.
    private val thumbnailExecutor = Executors.newFixedThreadPool(
        (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 4)
    ) { r ->
        Thread({
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Throwable) { }
            r.run()
        }, "OmniHub-Thumb").apply { isDaemon = true }
    }
    // Cache sized from the device's heap (about 1/6, 24–96MB) instead of a fixed 12MB that only held ~45 thumbnails.
    private val thumbnailCache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6L).coerceIn(24L * 1024 * 1024, 96L * 1024 * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private var scanInProgress = false
    // ---- whole-storage search + sort/date/type filters ----
    private val searchExecutor = Executors.newSingleThreadExecutor()
    private val searchGen = AtomicInteger(0)
    private val searchHandler = Handler(Looper.getMainLooper())
    private val searchTrigger = Runnable { refreshEntries() }
    private var showingSearch = false
    private var sortIndex = 0              // see SORT_LABELS
    private var dateIndex = 0              // see DATE_LABELS
    @Volatile private var sinceMs = 0L
    private var extFilter = ""
    @Volatile private var extSetCache: Set<String> = emptySet()
    private var sortButton: Button? = null
    private var dateButton: Button? = null
    private var typeButton: Button? = null
    private var scanProgress: ProgressBar? = null
    private var scanStatus: TextView? = null
    private var lastSwipeY = 0f
    private var saveName = "untitled.txt"
    private var currentDir = Environment.getExternalStorageDirectory()
    // Media/Code libraries show a flat list of "last" folders (folders that directly hold files).
    // openFolder is the folder whose files are currently shown; null means the folder list itself.
    private var openFolder: File? = null
    private val folderMeta = HashMap<String, String>()
    private var activeCategory = "All"
    private var managerUiBuilt = false
    private val maxIndexedFiles = 100_000

    private lateinit var root: LinearLayout
    private lateinit var pathLabel: TextView
    private lateinit var searchInput: EditText
    private lateinit var listView: RecyclerView
    private lateinit var contentContainer: FrameLayout
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private var gridMode = false
    private var showHiddenFiles = false
    private var showHiddenButton: Button? = null
    private var gridColumns = 3
    private var gridScaleDetector: ScaleGestureDetector? = null
    private var pinchChangedColumns = false
    private var viewToggleButton: Button? = null
    private var navDirection = 0   // +1 entering a folder, -1 going back: drives the list transition
    private var pasteBar: LinearLayout? = null
    private var pasteLabel: TextView? = null
    private var pasteButton: Button? = null
    private var searchPanels: List<View> = emptyList()
    private var librarySearchToggle: Button? = null
    private var lastRecordedDir: String? = null
    private val folderCountCache = LruCache<String, String>(512)
    private val selectedPaths = linkedSetOf<String>()
    private lateinit var selectionToolbar: LinearLayout
    private lateinit var selectionCountLabel: TextView
    private lateinit var selectionActionBar: LinearLayout
    private val videoDurationCache = object : LruCache<String, String>(256) {}
    private val durationInFlight = Collections.synchronizedSet(mutableSetOf<String>())
    private val durationWaiters = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.CopyOnWriteArrayList<java.lang.ref.WeakReference<TextView>>>()
    private val durationFutures = java.util.concurrent.ConcurrentHashMap<String, Future<*>>()
    private val durationPendingFiles = java.util.concurrent.ConcurrentHashMap<String, File>()
    private val durationAttachListeners = java.util.WeakHashMap<TextView, View.OnAttachStateChangeListener>()
    private val durationWaiterKeys = java.util.WeakHashMap<TextView, String>()
    private val thumbnailWaiters = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.CopyOnWriteArrayList<java.lang.ref.WeakReference<ImageView>>>()
    private val thumbnailFutures = java.util.concurrent.ConcurrentHashMap<String, Future<*>>()
    private val thumbnailPendingFiles = java.util.concurrent.ConcurrentHashMap<String, File>()
    private val thumbnailAttachListeners = java.util.WeakHashMap<ImageView, View.OnAttachStateChangeListener>()
    private val folderPreviewAttachListeners = java.util.WeakHashMap<View, View.OnAttachStateChangeListener>()
    private val thumbnailWaiterLock = Any()
    private val folderPreviewLoader by lazy { FolderPreviewLoader(thumbnailExecutor) }
    private lateinit var emptyLabel: TextView
    private lateinit var listAdapter: FileRowsAdapter
    private val shownFiles = mutableListOf<File>()
    private sealed class DisplayRow {
        data class DateHeader(val dayStart: Long, val label: String) : DisplayRow()
        data class FileItem(val file: File) : DisplayRow()
    }
    private var displayRows: List<DisplayRow> = emptyList()
    private var hasDateGroups = false
    private var stickyHeaderLabel: TextView? = null
    private var categoryButtons = mutableListOf<Pair<String, Button>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode")?.ifBlank { "any" } ?: "any"
        mimeConstraint = intent.getStringExtra("mime")?.ifBlank { "*/*" } ?: "*/*"
        selectedExtension = intent.getStringExtra("extension")?.trim()?.lowercase(Locale.ROOT).orEmpty()
        browseFilterMode = intent.getStringExtra("browse_filter_mode")?.lowercase(Locale.ROOT).orEmpty()
        initialBrowseQuery = intent.getStringExtra("query").orEmpty()
        initialCategory = intent.getStringExtra("initial_category").orEmpty()
        activeCategory = initialCategory.ifBlank { "All files" }
        sortIndex = intent.getIntExtra("sort_index", if (intent.getBooleanExtra("sort_recent", false) || mode == "recent") 2 else 0)
        val preferences = getSharedPreferences("omnihub_filemanager_view", MODE_PRIVATE)
        val mediaDefaultGrid = mode == "media" || (mode == "browse" && browseFilterMode == "media") || mimeConstraint.startsWith("image/") || mimeConstraint.startsWith("video/")
        gridMode = preferences.getBoolean("grid_mode", mediaDefaultGrid)
        showHiddenFiles = preferences.getBoolean("show_hidden_files", false)
        val wideScreen = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE || resources.configuration.screenWidthDp >= 600
        gridColumns = preferences.getInt("grid_columns", if (wideScreen) 4 else 3).coerceIn(2, 5)
        intent.getStringExtra("browse_path")?.let { path -> File(path).takeIf { it.isDirectory && it.canRead() }?.let { currentDir = it } }
        globalIndexMode = mode == "media" || mode == "text" || mode == "recent"
        removeLegacyOversizedIndexCache()
        saveName = intent.getStringExtra("save_name")?.ifBlank { "untitled.txt" } ?: "untitled.txt"
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        setContentView(root)
        InsetsUtil.apply(this, root)
        if (Build.VERSION.SDK_INT >= 23) {
            androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply {
                isAppearanceLightStatusBars = true
                isAppearanceLightNavigationBars = true
            }
        }
        showPermissionOrManager()
    }

    override fun onResume() {
        super.onResume()
        fileSigCache.evictAll()
        if (!::root.isInitialized) return
        if (hasStorageAccess()) {
            if (!managerUiBuilt) buildManagerUi() else refreshEntries()
        } else if (managerUiBuilt) {
            managerUiBuilt = false
            showPermissionUi()
        }
    }

    private fun hasStorageAccess(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val canRead = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                val canWrite = Build.VERSION.SDK_INT > Build.VERSION_CODES.Q || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                canRead && canWrite
            } else true
        } catch (_: Exception) { false }
    }

    private fun showPermissionOrManager() {
        if (hasStorageAccess()) buildManagerUi() else showPermissionUi()
    }

    private fun showPermissionUi() {
        managerUiBuilt = false
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "OmniHub File Manager"
            setTextColor(textColor)
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(18))
        })
        root.addView(TextView(this).apply {
            text = "To browse files inside OmniHub, allow access to shared storage once. Then folders, audio, video, images and documents will be listed here instead of opening the phone's file picker."
            setTextColor(mutedColor)
            textSize = 15f
            setLineSpacing(dp(3).toFloat(), 1.08f)
            setPadding(0, 0, 0, dp(18))
        })
        root.addView(makeButton("Grant storage access", accent) { requestStorageAccess() }, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(makeButton("Cancel", panelAlt) { setResult(RESULT_CANCELED); finish() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        root.addView(TextView(this).apply {
            text = "Android may still protect app-private folders such as parts of Android/data. OmniHub only browses shared storage that Android makes accessible."
            setTextColor(mutedColor)
            textSize = 12f
            setPadding(0, dp(20), 0, 0)
        })
    }

    private fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                catch (_: Exception) { Toast.makeText(this, "Storage access settings could not be opened", Toast.LENGTH_LONG).show() }
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val permissions = if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            } else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            requestPermissions(permissions, REQUEST_READ_STORAGE)
        }
    }

    @Deprecated("Compatibility with Android versions that use runtime storage permission callbacks")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_READ_STORAGE) {
            if (hasStorageAccess()) buildManagerUi() else Toast.makeText(this, "Storage permission was not granted", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildManagerUi() {
        managerUiBuilt = true
        root.removeAllViews()

        val compact = mode == "browse"
        viewToggleButton = makeFlatButton(if (gridMode) getString(R.string.list_view) else getString(R.string.grid_view)) { toggleGridList() }.apply {
            contentDescription = getString(if (gridMode) R.string.toggle_list_view else R.string.toggle_grid_view)
        }
        if (!compact) {
            // Clean flat toolbar: ‹  Title / subtitle  ·····  🔍  Grid  ↻  ✕   (no cards, no borders)
            val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            toolbar.addView(makeFlatButton("‹") { goParent() }.apply { textSize = 26f }, LinearLayout.LayoutParams(dp(40), dp(52)))
            val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            titles.addView(TextView(this).apply {
                text = when { mode == "save" -> "Save file"; mode == "recent" -> "New files"; mode == "media" -> when { mimeConstraint.startsWith("audio/") -> "Audio Library"; mimeConstraint.startsWith("video/") -> "Video Library"; mimeConstraint.startsWith("image/") -> "Image Library"; else -> "Media Library" }; mode == "text" -> "Code / Text Library · ${selectedExtension.uppercase().ifBlank { "All formats" }}"; else -> "File Manager" }
                textSize = 19f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(textColor)
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            titles.addView(TextView(this).apply {
                pathLabel = this
                textSize = 11f; setTextColor(mutedColor); maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            toolbar.addView(titles, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(4) })
            librarySearchToggle = makeFlatButton("🔍") { }
            toolbar.addView(librarySearchToggle, LinearLayout.LayoutParams(dp(42), dp(48)))
            toolbar.addView(viewToggleButton, LinearLayout.LayoutParams(-2, dp(48)))
            if (globalIndexMode) toolbar.addView(makeFlatButton("↻") { startIndexScan(true) }.apply { textSize = 18f; contentDescription = "Refresh" }, LinearLayout.LayoutParams(dp(42), dp(48)))
            toolbar.addView(makeFlatButton("✕") { setResult(RESULT_CANCELED); finish() }, LinearLayout.LayoutParams(dp(42), dp(48)))
            root.addView(toolbar)
        }
        selectionToolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(5), dp(2), dp(5), dp(2))
            background = roundedDrawable(panel, dp(12), dp(1), Color.rgb(218, 213, 230))
        }
        selectionCountLabel = TextView(this).apply { setTextColor(accent); textSize = 13f; typeface = Typeface.DEFAULT_BOLD }
        selectionToolbar.addView(selectionCountLabel, LinearLayout.LayoutParams(0, dp(42), 1f))
        selectionToolbar.addView(makeButton(getString(R.string.action_select_all), panelAlt) {
            selectedPaths.clear(); selectedPaths.addAll(shownFiles.map { it.absolutePath }); notifyRowsChanged(); updateSelectionControls()
        }, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(5) })
        selectionToolbar.addView(makeButton("✕", panelAlt) { clearSelection() }, LinearLayout.LayoutParams(dp(46), dp(40)))
        root.addView(selectionToolbar, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(4) })
        run {
            scanProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                isIndeterminate = true
                visibility = View.GONE
                progressTintList = ColorStateList.valueOf(accent)
                indeterminateTintList = ColorStateList.valueOf(accent)
            }
            root.addView(scanProgress, LinearLayout.LayoutParams(-1, dp(3)))
            scanStatus = TextView(this).apply {
                text = ""
                textSize = 10f
                setTextColor(mutedColor)
                visibility = View.GONE
                setPadding(dp(2), dp(2), dp(2), dp(2))
            }
            root.addView(scanStatus)
        }

        val navigation = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (compact) navigation.addView(makeButton("‹ Back", panelAlt) { goParent() }, LinearLayout.LayoutParams(dp(76), dp(42)))
        if (compact) navigation.addView(HomeNavigation.makeHomeButton(this), LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(5) })
        if (compact) navigation.addView(TextView(this).apply {
            pathLabel = this
            if (compact) {
                textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(textColor); maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            } else {
                textSize = 11f; setTextColor(mutedColor); maxLines = 2
            }
            setPadding(dp(10), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (compact) pathLabel.setOnClickListener { showRecentFolders() }
        if (compact) navigation.addView(makeButton("⋮", panelAlt) { showBrowseMenu() }, LinearLayout.LayoutParams(dp(44), dp(42)))
        if (compact) root.addView(navigation, LinearLayout.LayoutParams(-1, dp(48)))

        searchInput = EditText(this).apply {
            hint = if (globalIndexMode) "Search folders or files…" else "Search whole phone storage…"
            setHintTextColor(mutedColor)
            setTextColor(textColor)
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(14), 0, dp(14), 0)
            background = roundedDrawable(panelAlt, dp(24))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { scheduleRefresh() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(searchInput, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })

        val quickScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(7), 0, dp(3)) }
        listOf("Android/data" to "Android/data", "Android/obb" to "Android/obb", "Shizuku" to "").forEach { (label, relative) ->
            quickRow.addView(makeButton("⚡ $label", panelAlt) {
                val path = Environment.getExternalStorageDirectory().absolutePath + if (relative.isEmpty()) "" else "/$relative"
                startActivity(Intent(this, ShizukuFileActivity::class.java).putExtra("path", path))
            }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        }
        listOf(
            "Internal" to "",
            "Downloads" to "Download",
            "Documents" to "Documents",
            "Music" to "Music",
            "Movies" to "Movies",
            "Pictures" to "Pictures",
            "DCIM" to "DCIM"
        ).forEach { (label, relative) ->
            quickRow.addView(makeButton(label, panelAlt) {
                val dest = if (relative.isEmpty()) Environment.getExternalStorageDirectory() else File(Environment.getExternalStorageDirectory(), relative)
                if (dest.exists() && dest.isDirectory && dest.canRead()) { currentDir = dest; openFolder = null; if (::searchInput.isInitialized) searchInput.setText(""); refreshEntries() }
                else Toast.makeText(this, "$label folder is not available", Toast.LENGTH_SHORT).show()
            }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        }
        quickScroll.addView(quickRow)
        root.addView(quickScroll)
        quickScroll.visibility = View.GONE // Android/data, obb, Shizuku and folder shortcut chips are removed from every top bar.

        val categoryScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(3), 0, dp(8)) }
        categoryButtons.clear()
        categoriesForMode().forEach { category ->
            val button = makeButton(category, panelAlt) {
                activeCategory = category
                val prefs = getSharedPreferences("omnihub_filemanager_view", MODE_PRIVATE)
                if (!prefs.contains("grid_mode") && category in setOf("Images", "Video", "Audio")) {
                    gridMode = true
                    viewToggleButton?.text = getString(R.string.list_view)
                    viewToggleButton?.contentDescription = getString(R.string.toggle_list_view)
                    if (::contentContainer.isInitialized && ::emptyLabel.isInitialized && ::listAdapter.isInitialized) {
                        attachItemsView(resetScroll = false)
                    }
                }
                updateCategoryStyles(); refreshEntries()
            }
            categoryButtons.add(category to button)
            categoryRow.addView(button, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        }
        categoryScroll.addView(categoryRow)
        root.addView(categoryScroll)

        // Sort / date / type filters (work for folders, search results and the media libraries alike).
        val filterScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(8)) }
        sortButton = makeButton("", panelAlt) { showSortDialog() }
        dateButton = makeButton("", panelAlt) { showDateDialog() }
        typeButton = makeButton("", panelAlt) { showTypeDialog() }
        listOf<Button?>(sortButton, dateButton, typeButton).forEach { b ->
            if (b != null) filterRow.addView(b, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        }
        filterRow.addView(makeButton("↺ Reset", panelAlt) { resetFilters() }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        showHiddenButton = makeButton("", panelAlt) {
            showHiddenFiles = !showHiddenFiles
            getSharedPreferences("omnihub_filemanager_view", MODE_PRIVATE).edit().putBoolean("show_hidden_files", showHiddenFiles).apply()
            updateFilterButtons()
            refreshEntries()
        }.apply { contentDescription = getString(R.string.show_hidden_files) }
        filterRow.addView(showHiddenButton, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        filterScroll.addView(filterRow)
        root.addView(filterScroll)
        updateFilterButtons()
        if (compact) {
            // File Manager keeps the top clean: Back, Home and the folder name. Search / filters live in the ⋮ menu.
            searchPanels = listOf(searchInput, categoryScroll, filterScroll)
            searchPanels.forEach { it.visibility = View.GONE }
        } else {
            // Libraries get the same clean top: search / filters / category chips stay hidden until 🔍 is tapped.
            searchPanels = listOf(searchInput, categoryScroll, filterScroll)
            searchPanels.forEach { it.visibility = View.GONE }
            librarySearchToggle?.setOnClickListener {
                val showIt = searchInput.visibility != View.VISIBLE
                searchPanels.forEach { it.visibility = if (showIt) View.VISIBLE else View.GONE }
                if (showIt) searchInput.requestFocus()
            }
        }

        if (mode == "save") {
            root.addView(makeButton("Save in this folder…", accent) { promptSaveInCurrentFolder() }, LinearLayout.LayoutParams(-1, dp(47)).apply { bottomMargin = dp(7) })
        }

        contentContainer = FrameLayout(this)
        emptyLabel = TextView(this).apply {
            text = getString(R.string.quick_search_no_results)
            setTextColor(mutedColor)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        listAdapter = FileRowsAdapter()
        attachItemsView(resetScroll = true)
        swipeRefresh = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(accent)
            setProgressBackgroundColorSchemeColor(Color.rgb(252, 251, 254))
            setOnChildScrollUpCallback { _, _ -> ::listView.isInitialized && listView.canScrollVertically(-1) }
            setOnRefreshListener {
                if (globalIndexMode) startIndexScan(true) else refreshEntries()
                postDelayed({ isRefreshing = false }, 600)
            }
            addView(contentContainer, ViewGroup.LayoutParams(-1, -1))
        }
        root.addView(swipeRefresh, LinearLayout.LayoutParams(-1, 0, 1f))
        selectionActionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(2), dp(5), dp(2), dp(5))
            background = roundedDrawable(panel, dp(15), dp(1), Color.rgb(218, 213, 230))
        }
        if (compact) {
            fun addAction(label: String, color: Int, action: () -> Unit, last: Boolean = false) =
                selectionActionBar.addView(makeButton(label, color) { action() }.apply { textSize = 12f; setPadding(dp(2), 0, dp(2), 0) },
                    LinearLayout.LayoutParams(0, dp(48), 1f).apply { if (!last) rightMargin = dp(4) })
            addAction(getString(R.string.action_copy), panelAlt, { performFileAction("copy", selectedFilesSnapshot()) })
            addAction(getString(R.string.action_move), panelAlt, { performFileAction("move", selectedFilesSnapshot()) })
            addAction(getString(R.string.action_rename), panelAlt, { performFileAction("rename", selectedFilesSnapshot()) })
            addAction(getString(R.string.action_delete), panelAlt, { performFileAction("delete", selectedFilesSnapshot()) })
            addAction(getString(R.string.action_more), accent, { showFileActionSheet() }, last = true)
        } else {
            selectionActionBar.addView(makeButton(getString(R.string.action_open), panelAlt) { performFileAction("open", selectedFilesSnapshot()) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(4) })
            selectionActionBar.addView(makeButton(getString(R.string.action_share), panelAlt) { performFileAction("share", selectedFilesSnapshot()) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(4) })
            selectionActionBar.addView(makeButton(getString(R.string.archive_compress), panelAlt) { performFileAction("compress", selectedFilesSnapshot()) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(4) })
            selectionActionBar.addView(makeButton(getString(R.string.action_more), accent) { showFileActionSheet() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(selectionActionBar, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(5) })

        if (compact) {
            // Paste bar: shown whenever something is waiting in the clipboard, in EVERY folder.
            val bar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                visibility = View.GONE
                setPadding(dp(8), dp(6), dp(8), dp(6))
                background = roundedDrawable(Color.rgb(74, 64, 140), dp(16))
            }
            bar.addView(makeButton("✕ Cancel", Color.rgb(102, 92, 168)) { FileClipboard.clear(); updatePasteBar() }.apply { setTextColor(Color.WHITE) },
                LinearLayout.LayoutParams(-2, dp(46)).apply { rightMargin = dp(8) })
            pasteLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
            bar.addView(pasteLabel, LinearLayout.LayoutParams(0, -2, 1f))
            pasteButton = makeButton("Paste here", accent) { performPaste() }.apply { setTextColor(Color.WHITE) }
            bar.addView(pasteButton, LinearLayout.LayoutParams(-2, dp(46)).apply { leftMargin = dp(8) })
            pasteBar = bar
            root.addView(bar, 0, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        }

        updateCategoryStyles()
        if (globalIndexMode) {
            refreshEntries()
            loadCachedIndexInBackground()
        } else refreshEntries()
        if (mode == "browse" && !browseFocusApplied) {
            browseFocusApplied = true
            if (initialBrowseQuery.isNotBlank()) {
                searchPanels.forEach { it.visibility = View.VISIBLE }
                searchInput.setText(initialBrowseQuery)
                searchInput.requestFocus()
                searchInput.post {
                    try { (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)?.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) } catch (_: Exception) { }
                }
            }
            updatePasteBar()
        }
    }


    private fun createItemsView(): RecyclerView {
        val view = RecyclerView(this).apply {
            setBackgroundColor(bg)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            setHasFixedSize(true)
            itemAnimator = null
            setItemViewCacheSize(24)
            recycledViewPool.setMaxRecycledViews(TYPE_FILE_ITEM, 48)
            isNestedScrollingEnabled = false
            layoutManager = if (gridMode) {
                GridLayoutManager(this@FileManagerActivity, gridColumns).apply {
                    spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                        override fun getSpanSize(position: Int): Int =
                            if (listAdapter.getItemViewType(position) == TYPE_DATE_HEADER) spanCount else 1
                    }
                }
            } else LinearLayoutManager(this@FileManagerActivity)
            adapter = listAdapter
        }
        if (gridMode) {
            view.addItemDecoration(object : RecyclerView.ItemDecoration() {
                override fun getItemOffsets(outRect: android.graphics.Rect, child: View, parent: RecyclerView, state: RecyclerView.State) {
                    val position = parent.getChildAdapterPosition(child)
                    if (position == RecyclerView.NO_POSITION || listAdapter.getItemViewType(position) == TYPE_DATE_HEADER) return
                    val gap = dp(3)
                    outRect.set(gap, gap, gap, gap)
                }
            })
        }
        view.setOnTouchListener { v, event ->
            if (gridMode) gridScaleDetector?.onTouchEvent(event)
            when (event.action) {
                MotionEvent.ACTION_DOWN -> lastSwipeY = event.y
                MotionEvent.ACTION_UP -> {
                    val delta = event.y - lastSwipeY
                    if (globalIndexMode && delta > dp(90) && firstVisiblePosition() == 0 && !scanInProgress) {
                        startIndexScan(true)
                        v.performClick()
                    }
                }
            }
            false
        }
        view.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (hasDateGroups && dy != 0) updateStickyHeader()
            }
        })
        gridScaleDetector = if (gridMode) ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean { pinchChangedColumns = false; return true }
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (!pinchChangedColumns && detector.scaleFactor > 1.12f) {
                    pinchChangedColumns = true; setGridColumns((gridColumns - 1).coerceAtLeast(2))
                } else if (!pinchChangedColumns && detector.scaleFactor < 0.88f) {
                    pinchChangedColumns = true; setGridColumns((gridColumns + 1).coerceAtMost(5))
                }
                return true
            }
            override fun onScaleEnd(detector: ScaleGestureDetector) { pinchChangedColumns = false }
        }) else null
        return view
    }

    private fun attachItemsView(resetScroll: Boolean) {
        if (!::contentContainer.isInitialized || !::emptyLabel.isInitialized || !::listAdapter.isInitialized) return
        val oldPosition = if (!resetScroll && ::listView.isInitialized) firstVisiblePosition() else 0
        contentContainer.removeAllViews()
        listView = createItemsView()
        contentContainer.addView(listView, FrameLayout.LayoutParams(-1, -1))
        if (stickyHeaderLabel == null) {
            stickyHeaderLabel = TextView(this).apply {
                setTextColor(accent)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), 0)
                setBackgroundColor(Color.rgb(232, 229, 241))
                visibility = View.GONE
                elevation = dp(2).toFloat()
                contentDescription = "Sticky media date group"
            }
        }
        contentContainer.addView(stickyHeaderLabel, FrameLayout.LayoutParams(-1, dp(34), Gravity.TOP))
        contentContainer.addView(emptyLabel, FrameLayout.LayoutParams(-1, -1))
        if (!resetScroll && oldPosition > 0) listView.scrollToPosition(oldPosition)
        updateStickyHeader()
        updateEmptyState()
    }

    private fun firstVisiblePosition(): Int {
        val manager = if (::listView.isInitialized) listView.layoutManager else null
        return when (manager) {
            is GridLayoutManager -> manager.findFirstVisibleItemPosition().coerceAtLeast(0)
            is LinearLayoutManager -> manager.findFirstVisibleItemPosition().coerceAtLeast(0)
            else -> 0
        }
    }

    private fun updateEmptyState() {
        if (!::emptyLabel.isInitialized || !::listView.isInitialized) return
        val empty = shownFiles.isEmpty()
        emptyLabel.visibility = if (empty) View.VISIBLE else View.GONE
        listView.visibility = if (empty) View.GONE else View.VISIBLE
    }

    private fun dayStartMillis(timestamp: Long): Long {
        val calendar = Calendar.getInstance().apply { timeInMillis = timestamp; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        return calendar.timeInMillis
    }

    private fun dateGroupLabel(dayStart: Long): String {
        val today = dayStartMillis(System.currentTimeMillis())
        val yesterday = Calendar.getInstance().apply { timeInMillis = today; add(Calendar.DAY_OF_YEAR, -1) }.timeInMillis
        return when (dayStart) {
            today -> getString(R.string.media_group_today)
            yesterday -> getString(R.string.media_group_yesterday)
            else -> DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(dayStart))
        }
    }

    private fun rebuildDisplayRows() {
        val groupMedia = (mode == "media" || (mode == "browse" && browseFilterMode == "media")) &&
            shownFiles.any { !it.isDirectory && isMediaFile(it) }
        if (!groupMedia) {
            hasDateGroups = false
            displayRows = shownFiles.map { DisplayRow.FileItem(it) }
            return
        }
        val rows = ArrayList<DisplayRow>(shownFiles.size + 32)
        val directories = shownFiles.filter { it.isDirectory }
        directories.forEach { rows += DisplayRow.FileItem(it) }
        val buckets = HashMap<Long, MutableList<File>>()
        shownFiles.filter { !it.isDirectory }.forEach { file ->
            buckets.getOrPut(dayStartMillis(file.lastModified())) { mutableListOf() }.add(file)
        }
        val days = buckets.keys.sortedDescending()
        hasDateGroups = days.isNotEmpty()
        for (day in days) {
            rows += DisplayRow.DateHeader(day, dateGroupLabel(day))
            buckets[day].orEmpty().forEach { rows += DisplayRow.FileItem(it) }
        }
        displayRows = rows
    }

    private fun updateStickyHeader() {
        val label = stickyHeaderLabel ?: return
        if (!::listView.isInitialized) {
            label.visibility = View.GONE
            return
        }
        if (!hasDateGroups) {
            label.visibility = View.GONE
            (listView.layoutParams as? FrameLayout.LayoutParams)?.let { if (it.topMargin != 0) { it.topMargin = 0; listView.layoutParams = it } }
            return
        }
        val params = listView.layoutParams as? FrameLayout.LayoutParams
        if (params != null && params.topMargin != dp(34)) { params.topMargin = dp(34); listView.layoutParams = params }
        if (label.visibility != View.VISIBLE) label.visibility = View.VISIBLE
        val first = firstVisiblePosition().coerceIn(0, (displayRows.size - 1).coerceAtLeast(0))
        var found: DisplayRow.DateHeader? = null
        for (i in first downTo 0) {
            val row = displayRows.getOrNull(i)
            if (row is DisplayRow.DateHeader) { found = row; break }
        }
        if (found == null) { if (label.visibility != View.GONE) label.visibility = View.GONE }
        else if (label.text.toString() != found.label) label.text = found.label
    }

    private fun toggleGridList() {
        gridMode = !gridMode
        getSharedPreferences("omnihub_filemanager_view", MODE_PRIVATE).edit().putBoolean("grid_mode", gridMode).apply()
        viewToggleButton?.apply {
            text = if (gridMode) getString(R.string.list_view) else getString(R.string.grid_view)
            contentDescription = getString(if (gridMode) R.string.toggle_list_view else R.string.toggle_grid_view)
        }
        val oldPosition = if (::listView.isInitialized) firstVisiblePosition() else 0
        if (::contentContainer.isInitialized && ::emptyLabel.isInitialized && ::listAdapter.isInitialized) {
            attachItemsView(resetScroll = true)
            if (oldPosition > 0) listView.scrollToPosition(oldPosition)
        }
    }

    private fun setGridColumns(value: Int) {
        gridColumns = value.coerceIn(2, 5)
        getSharedPreferences("omnihub_filemanager_view", MODE_PRIVATE).edit().putInt("grid_columns", gridColumns).apply()
        (listView.layoutManager as? GridLayoutManager)?.spanCount = gridColumns
        listView.requestLayout()
        notifyRowsChanged()
    }

    private fun createGridTile(file: File): View {
        val path = file.absolutePath
        val selected = selectedPaths.contains(path)
        val tile = SquareFrameLayout(this).apply {
            tag = path
            setBackground(roundedDrawable(Color.rgb(252, 251, 254), dp(12), if (selected) dp(2) else 0, if (selected) accent else Color.TRANSPARENT))
            clipToOutline = true
            foreground = android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(38, 102, 80, 196)), null, roundedDrawable(Color.rgb(252, 251, 254), dp(12)))
            contentDescription = if (file.isDirectory) displayName(file) else file.name
        }
        val mime = if (file.isDirectory) "" else mimeForFile(file)
        if (file.isDirectory) {
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(252, 251, 254)) }
            val mosaic = FrameLayout(this).apply { tag = path; setBackgroundColor(Color.rgb(232, 229, 241)) }
            body.addView(mosaic, LinearLayout.LayoutParams(-1, 0, 1f))
            val footer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(7), dp(3), dp(5), dp(4))
                background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(242, 240, 247), Color.WHITE))
            }
            footer.addView(TextView(this).apply { text = displayName(file); setTextColor(textColor); textSize = 11f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            footer.addView(TextView(this).apply { text = folderMeta[path] ?: getString(R.string.folder_media_preview); setTextColor(mutedColor); textSize = 9f; maxLines = 1 })
            body.addView(footer, LinearLayout.LayoutParams(-1, dp(36)))
            tile.addView(body, FrameLayout.LayoutParams(-1, -1))
            addFolderMosaic(file, mosaic)
        } else {
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.rgb(232, 229, 241))
                contentDescription = file.name
            }
            tile.addView(image, FrameLayout.LayoutParams(-1, -1))
            if (mime.startsWith("image/") || mime.startsWith("video/")) requestThumbnail(file, image)
            else {
                val audio = mime.startsWith("audio/")
                image.setImageDrawable(android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(214, 209, 226), Color.rgb(232, 229, 241))))
                val icon = TextView(this).apply { text = if (audio) "♫" else if (ArchiveManager.isArchive(file)) "▤" else if (isTextFile(file)) "⌘" else "▧"; textSize = 29f; gravity = Gravity.CENTER; setTextColor(accent); contentDescription = file.name }
                tile.addView(icon, FrameLayout.LayoutParams(-1, -1))
            }
            val footer = TextView(this).apply {
                text = file.name
                textSize = 10f
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), 0, dp(6), 0)
                background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(220, 4, 8, 16)))
            }
            tile.addView(footer, FrameLayout.LayoutParams(-1, dp(25), Gravity.BOTTOM))
            if (mime.startsWith("video/")) {
                tile.addView(TextView(this).apply { text = "▶"; textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = roundedDrawable(Color.argb(150, 0, 0, 0), dp(10)); contentDescription = getString(R.string.grid_video_file) }, FrameLayout.LayoutParams(dp(26), dp(22), Gravity.TOP or Gravity.START).apply { leftMargin = dp(5); topMargin = dp(5) })
                val duration = TextView(this).apply { textSize = 9f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(4), 0, dp(4), 0); background = roundedDrawable(Color.argb(165, 0, 0, 0), dp(5)); tag = path }
                videoDurationCache.get(thumbnailKey(file))?.let { duration.text = it }
                tile.addView(duration, FrameLayout.LayoutParams(-2, dp(20), Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(5); bottomMargin = dp(28) })
                loadVideoDuration(file, duration)
            }
        }
        // Border overlays thumbnails without blocking touches; selected items are unmistakable.
        val border = View(this).apply { background = roundedDrawable(Color.TRANSPARENT, dp(12), if (selected) dp(2) else 0, if (selected) accent else Color.TRANSPARENT); isClickable = false }
        tile.addView(border, FrameLayout.LayoutParams(-1, -1))
        tile.addView(TextView(this).apply {
            tag = GRID_SELECTED_BADGE_TAG
            text = "✓"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = roundedDrawable(accent, dp(20))
            contentDescription = getString(R.string.action_selection_clear)
            visibility = if (selected) View.VISIBLE else View.GONE
        }, FrameLayout.LayoutParams(dp(25), dp(25), Gravity.TOP or Gravity.END).apply { topMargin = dp(5); rightMargin = dp(5) })
        return tile
    }

    private fun loadFolderPreviewWhenAttached(folder: File, owner: View, callback: (FolderPreviewLoader.Preview) -> Unit) {
        synchronized(folderPreviewAttachListeners) {
            folderPreviewAttachListeners.remove(owner)?.let { owner.removeOnAttachStateChangeListener(it) }
            val path = folder.absolutePath
            val listener = object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) {
                    if (v.tag == path && !isFinishing && !isDestroyed) folderPreviewLoader.load(folder, owner, callback)
                }
                override fun onViewDetachedFromWindow(v: View) {
                    folderPreviewLoader.cancel(owner)
                }
            }
            folderPreviewAttachListeners[owner] = listener
            owner.addOnAttachStateChangeListener(listener)
        }
        if (owner.isAttachedToWindow && owner.tag == folder.absolutePath && !isFinishing && !isDestroyed) {
            folderPreviewLoader.load(folder, owner, callback)
        }
    }

    private fun addFolderMosaic(folder: File, mosaic: FrameLayout) {
        val fallback = TextView(this).apply { text = "📁"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(accent); contentDescription = getString(R.string.storage_root) }
        mosaic.addView(fallback, FrameLayout.LayoutParams(-1, -1))
        loadFolderPreviewWhenAttached(folder, mosaic) { preview ->
            if (isFinishing || isDestroyed || mosaic.tag != folder.absolutePath) return@loadFolderPreviewWhenAttached
            mosaic.removeAllViews()
            if (preview.children.isEmpty()) {
                mosaic.addView(fallback, FrameLayout.LayoutParams(-1, -1))
                return@loadFolderPreviewWhenAttached
            }
            val columnRows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            for (r in 0..1) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                columnRows.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
                for (c in 0..1) {
                    val idx = r * 2 + c
                    if (idx < preview.children.size) {
                        val child = preview.children[idx]
                        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.rgb(232, 229, 241)); contentDescription = child.name }
                        row.addView(image, LinearLayout.LayoutParams(0, -1, 1f).apply { rightMargin = dp(1); bottomMargin = dp(1) })
                        requestThumbnail(child, image)
                    } else row.addView(Space(this), LinearLayout.LayoutParams(0, -1, 1f))
                }
            }
            mosaic.addView(columnRows, FrameLayout.LayoutParams(-1, -1))
            if (preview.hasMore) mosaic.addView(TextView(this).apply {
                val known = folderMeta[folder.absolutePath]?.substringBefore(' ')?.toIntOrNull()
                text = if (known != null && known > 4) getString(R.string.folder_more_items, known - 4) else "+…"
                textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = roundedDrawable(Color.argb(195, 0, 0, 0), dp(10)); contentDescription = text
            }, FrameLayout.LayoutParams(dp(34), dp(23), Gravity.TOP or Gravity.END).apply { topMargin = dp(5); rightMargin = dp(5) })
        }
    }

    private fun cancelThumbnailsInView(view: View) {
        folderPreviewLoader.cancel(view)
        synchronized(folderPreviewAttachListeners) {
            folderPreviewAttachListeners.remove(view)?.let { try { view.removeOnAttachStateChangeListener(it) } catch (_: Exception) { } }
        }
        if (view is ImageView) {
            val key = view.tag as? String
            if (!key.isNullOrBlank()) removeThumbnailWaiter(key, view)
        }
        if (view is TextView) cancelVideoDurationWaiter(view)
        if (view is ViewGroup) for (i in 0 until view.childCount) cancelThumbnailsInView(view.getChildAt(i))
    }

    private fun suspendThumbnailWaiter(key: String, target: ImageView) {
        synchronized(thumbnailWaiterLock) {
            val waiters = thumbnailWaiters[key]
            waiters?.removeAll { ref -> ref.get() == null || ref.get() === target }
            if (waiters.isNullOrEmpty()) {
                if (waiters != null) thumbnailWaiters.remove(key, waiters)
                thumbnailPendingFiles.remove(key)
                // Future.cancel(true) interrupts work where Android's decoder/media retriever supports it.
                thumbnailFutures[key]?.cancel(true)
            }
        }
    }

    private fun removeThumbnailWaiter(key: String, target: ImageView) {
        suspendThumbnailWaiter(key, target)
        synchronized(thumbnailAttachListeners) {
            val listener = thumbnailAttachListeners.remove(target)
            if (listener != null) {
                try { target.removeOnAttachStateChangeListener(listener) } catch (_: Exception) { }
            }
        }
    }

    // lastModified()/length() are filesystem calls; doing them 3-4 times per bind on the UI thread was a major scroll cost.
    private val fileSigCache = object : LruCache<String, String>(6000) {}
    private fun fileSig(file: File): String {
        val path = file.absolutePath
        fileSigCache.get(path)?.let { return it }
        val sig = path + "|" + file.lastModified() + "|" + file.length()
        fileSigCache.put(path, sig)
        return sig
    }
    private fun thumbnailKey(file: File): String = fileSig(file)

    /** Shares the existing 12MB LruCache, executor pool and semaphore with list/grid thumbnails. */
    private fun requestThumbnail(file: File, target: ImageView) {
        val mime = mimeForFile(file)
        if (!mime.startsWith("image/") && !mime.startsWith("video/")) return
        // A recycled image view must stop receiving the previous file's thumbnail.
        val key = thumbnailKey(file)
        val previousKey = target.tag as? String
        if (!previousKey.isNullOrBlank() && previousKey != key) removeThumbnailWaiter(previousKey, target)
        synchronized(thumbnailAttachListeners) {
            val previous = thumbnailAttachListeners.remove(target)
            if (previous != null) target.removeOnAttachStateChangeListener(previous)
        }
        target.tag = key
        thumbnailCache.get(key)?.let { if (!it.isRecycled) { target.setImageBitmap(it); removeThumbnailWaiter(key, target); return } }
        val waiters = thumbnailWaiters.computeIfAbsent(key) { java.util.concurrent.CopyOnWriteArrayList() }
        synchronized(thumbnailWaiterLock) {
            if (waiters.none { it.get() === target }) waiters.add(java.lang.ref.WeakReference(target))
        }
        val detachListener = object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                if ((v as? ImageView)?.tag == key) {
                    val cached = thumbnailCache.get(key)
                    if (cached != null && !cached.isRecycled) target.setImageBitmap(cached)
                    else requestThumbnail(file, target)
                }
            }
            override fun onViewDetachedFromWindow(v: View) {
                if ((v as? ImageView)?.tag == key) suspendThumbnailWaiter(key, target)
            }
        }
        synchronized(thumbnailAttachListeners) {
            thumbnailAttachListeners[target] = detachListener
            target.addOnAttachStateChangeListener(detachListener)
        }
        if (!thumbnailKeysInFlight.add(key)) return
        if (!thumbnailSlots.tryAcquire()) {
            thumbnailKeysInFlight.remove(key)
            // Keep the waiter and attach listener: the task is deferred, not dropped.
            thumbnailPendingFiles[key] = file
            return
        }
        thumbnailPendingFiles.remove(key)
        val task = object : FutureTask<Unit>(Callable {
            var ready: Bitmap? = null
            try {
                if (Thread.currentThread().isInterrupted) return@Callable Unit
                ready = if (mime.startsWith("video/")) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(file.absolutePath)
                        if (Thread.currentThread().isInterrupted) null
                        else if (Build.VERSION.SDK_INT >= 27) {
                            retriever.getScaledFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 260, 260)
                                ?: if (!Thread.currentThread().isInterrupted) retriever.getScaledFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 260, 260) else null
                        } else {
                            retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                                ?: if (!Thread.currentThread().isInterrupted) retriever.getFrameAtTime(0L) else null
                        }
                    } catch (_: Throwable) { null } finally { try { retriever.release() } catch (_: Throwable) { } }
                } else {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(file.absolutePath, bounds)
                    if (Thread.currentThread().isInterrupted || bounds.outWidth <= 0 || bounds.outHeight <= 0) null
                    else {
                        val sample = sampleSizeFor(bounds.outWidth, bounds.outHeight, 256)
                        val lossy = file.extension.lowercase(Locale.ROOT).let { it == "jpg" || it == "jpeg" }
                        BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
                            inSampleSize = sample
                            // JPEGs have no alpha: RGB_565 halves memory so twice as many thumbnails stay cached.
                            if (lossy) inPreferredConfig = Bitmap.Config.RGB_565
                        })
                    }
                }
                if (Thread.currentThread().isInterrupted) return@Callable Unit
                val decoded = ready
                if (decoded != null && !decoded.isRecycled) {
                    val maxDimension = maxOf(decoded.width, decoded.height)
                    val bitmap = if (maxDimension > 260) {
                        val scale = 260f / maxDimension.toFloat()
                        Bitmap.createScaledBitmap(decoded, maxOf(1, (decoded.width * scale).toInt()), maxOf(1, (decoded.height * scale).toInt()), true).also {
                            if (it !== decoded) try { decoded.recycle() } catch (_: Exception) { }
                        }
                    } else decoded
                    thumbnailCache.put(key, bitmap)
                    val waiting = thumbnailWaiters[key]?.toList().orEmpty()
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        waiting.forEach { ref ->
                            val image = ref.get()
                            if (image != null && image.tag == key && !bitmap.isRecycled) image.setImageBitmap(bitmap)
                        }
                    }
                }
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            } catch (_: Throwable) {
                // A damaged or unreadable media file must not break the browser.
            }
            Unit
        }) {
            override fun done() {
                thumbnailKeysInFlight.remove(key)
                thumbnailFutures.remove(key, this)
                thumbnailSlots.release()
                // Keep weak references only while their ImageViews are genuinely waiting.
                val remains = thumbnailWaiters[key]
                if (remains != null) {
                    remains.removeAll { ref -> ref.get() == null || ref.get()?.tag != key }
                    if (remains.isEmpty()) thumbnailWaiters.remove(key, remains)
                }
                // If a view reattached just as its old future was being cancelled, restart once it is visible.
                mainUi.post {
                    if (thumbnailCache.get(key) == null && !thumbnailWaiters[key].isNullOrEmpty()) {
                        val active = thumbnailWaiters[key]?.firstNotNullOfOrNull { ref -> ref.get()?.takeIf { it.tag == key && it.isAttachedToWindow } }
                        if (active != null && !isFinishing && !isDestroyed) requestThumbnail(file, active)
                    }
                    drainPendingThumbnails()
                }
            }
        }
        thumbnailFutures[key] = task
        try { thumbnailExecutor.execute(task) }
        catch (_: Exception) { task.cancel(false) }
    }

    /** Retries previously deferred visible thumbnails when executor slots become available. */
    private fun drainPendingThumbnails() {
        if (isFinishing || isDestroyed || thumbnailPendingFiles.isEmpty()) return
        thumbnailPendingFiles.entries.toList().forEach { (key, file) ->
            val waiters = thumbnailWaiters[key]
            if (waiters.isNullOrEmpty()) {
                thumbnailPendingFiles.remove(key, file)
                return@forEach
            }
            val active = waiters.firstNotNullOfOrNull { ref -> ref.get()?.takeIf { it.tag == key && it.isAttachedToWindow } }
            if (active != null && thumbnailSlots.availablePermits() > 0 && thumbnailPendingFiles.remove(key, file)) {
                requestThumbnail(file, active)
            }
        }
    }

    private fun sampleSizeFor(width: Int, height: Int, target: Int): Int {
        var sample = 1
        while (width / (sample * 2) >= target && height / (sample * 2) >= target) sample *= 2
        return sample
    }

    private val mainUi by lazy { Handler(Looper.getMainLooper()) }

    private fun loadVideoDuration(file: File, target: TextView) {
        val key = thumbnailKey(file)
        videoDurationCache.get(key)?.let { target.text = it; return }
        val priorKey = synchronized(durationWaiterKeys) { durationWaiterKeys[target] }
        if (priorKey != null && priorKey != key) cancelVideoDurationWaiter(target)
        target.tag = file.absolutePath
        synchronized(durationAttachListeners) {
            if (durationAttachListeners[target] == null) {
                val listener = object : View.OnAttachStateChangeListener {
                    override fun onViewAttachedToWindow(v: View) {
                        if ((v as? TextView)?.tag == file.absolutePath && !isFinishing && !isDestroyed) loadVideoDuration(file, target)
                    }
                    override fun onViewDetachedFromWindow(v: View) {
                        suspendVideoDurationWaiter(key, target)
                    }
                }
                durationAttachListeners[target] = listener
                target.addOnAttachStateChangeListener(listener)
            }
            synchronized(durationWaiterKeys) { durationWaiterKeys[target] = key }
        }
        // Do not start native metadata IO for a tile that has not reached the visible window yet.
        if (!target.isAttachedToWindow) return
        val waiters = durationWaiters.computeIfAbsent(key) { java.util.concurrent.CopyOnWriteArrayList() }
        if (waiters.none { it.get() === target }) waiters.add(java.lang.ref.WeakReference(target))
        if (!durationInFlight.add(key)) return
        if (!thumbnailSlots.tryAcquire()) {
            durationInFlight.remove(key)
            durationPendingFiles[key] = file
            return
        }
        durationPendingFiles.remove(key)
        val task = object : FutureTask<String?>(Callable {
            if (Thread.currentThread().isInterrupted) return@Callable null
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(file.absolutePath)
                if (Thread.currentThread().isInterrupted) null
                else formatVideoDuration(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L)
            } catch (_: Throwable) { null }
            finally { try { retriever.release() } catch (_: Throwable) { } }
        }) {
            override fun done() {
                durationInFlight.remove(key)
                durationFutures.remove(key, this)
                thumbnailSlots.release()
                val value = if (isCancelled) null else try { get() } catch (_: Throwable) { null }
                if (value != null && !isCancelled) {
                    videoDurationCache.put(key, value)
                    val waiting = durationWaiters.remove(key)?.toList().orEmpty()
                    mainUi.post {
                        if (!isFinishing && !isDestroyed) waiting.forEach { ref ->
                            val text = ref.get()
                            if (text != null && text.tag == file.absolutePath && text.isAttachedToWindow) text.text = value
                        }
                    }
                } else {
                    val waiting = durationWaiters[key]
                    if (waiting.isNullOrEmpty() && waiting != null) durationWaiters.remove(key, waiting)
                }
                mainUi.post { drainPendingThumbnails(); drainPendingDurations() }
            }
        }
        durationFutures[key] = task
        try { thumbnailExecutor.execute(task) }
        catch (_: Exception) { task.cancel(false) }
    }

    private fun suspendVideoDurationWaiter(key: String, target: TextView) {
        val waiters = durationWaiters[key]
        waiters?.removeAll { ref -> ref.get() == null || ref.get() === target }
        if (waiters.isNullOrEmpty()) {
            if (waiters != null) durationWaiters.remove(key, waiters)
            durationPendingFiles.remove(key)
            durationFutures[key]?.cancel(true)
        }
    }

    private fun cancelVideoDurationWaiter(target: TextView) {
        val key = synchronized(durationWaiterKeys) { durationWaiterKeys.remove(target) }
        if (key != null) suspendVideoDurationWaiter(key, target)
        synchronized(durationAttachListeners) {
            durationAttachListeners.remove(target)?.let { try { target.removeOnAttachStateChangeListener(it) } catch (_: Exception) { } }
        }
    }

    private fun drainPendingDurations() {
        if (isFinishing || isDestroyed || durationPendingFiles.isEmpty()) return
        durationPendingFiles.entries.toList().forEach { (key, file) ->
            val waiters = durationWaiters[key]
            if (waiters.isNullOrEmpty()) {
                durationPendingFiles.remove(key, file)
                return@forEach
            }
            val active = waiters.firstNotNullOfOrNull { ref -> ref.get()?.takeIf { it.tag == file.absolutePath && it.isAttachedToWindow } }
            if (active != null && thumbnailSlots.availablePermits() > 0 && durationPendingFiles.remove(key, file)) {
                loadVideoDuration(file, active)
            }
        }
    }

    private fun formatVideoDuration(ms: Long): String {
        val seconds = (ms / 1000L).coerceAtLeast(0)
        return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60)
    }

    private fun roundedDrawable(color: Int, radius: Int, stroke: Int = 0, strokeColor: Int = Color.TRANSPARENT): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply {
        shape = android.graphics.drawable.GradientDrawable.RECTANGLE
        cornerRadius = radius.toFloat()
        setColor(color)
        if (stroke > 0) setStroke(stroke, strokeColor)
    }

    private fun toggleSelectedPath(file: File) {
        if (!selectedPaths.add(file.absolutePath)) selectedPaths.remove(file.absolutePath)
        notifyRowsChanged()
        updateSelectionControls()
    }

    private fun updateSelectionControls() {
        if (!::selectionToolbar.isInitialized || !::selectionActionBar.isInitialized) return
        val count = selectedPaths.size
        Motion.toggle(selectionToolbar, count > 0)
        Motion.toggle(selectionActionBar, count > 0)
        updatePasteBar()
        if (::selectionCountLabel.isInitialized) selectionCountLabel.text = getString(R.string.action_selected_count, count)
    }

    private fun selectedFilesSnapshot(): List<File> = selectedPaths.mapNotNull { path -> shownFiles.firstOrNull { it.absolutePath == path } ?: File(path).takeIf { it.exists() } }

    private fun clearSelection() {
        selectedPaths.clear()
        if (::listAdapter.isInitialized) notifyRowsChanged()
        updateSelectionControls()
    }

    private fun showFileActionSheet() {
        val selected = selectedFilesSnapshot()
        if (selected.isEmpty()) return
        FileActionSheet.show(this, selected) { action -> performFileAction(action, selected) }
    }

    private fun performFileAction(action: String, files: List<File>) {
        val selected = files.distinctBy { it.absolutePath }
        if (selected.isEmpty()) { clearSelection(); return }
        when (action) {
            "open" -> {
                val f = selected.first()
                if (f.isDirectory) {
                    if (globalIndexMode) { openFolder = f } else currentDir = f
                    searchInput.setText(""); refreshEntries()
                } else openFileInsideOmniHub(f)
            }
            "open_with" -> selected.singleOrNull()?.let { MediaShare.openWithOtherApp(this, Uri.fromFile(it), mimeForFile(it)) }
                ?: Toast.makeText(this, R.string.action_not_available_multiple, Toast.LENGTH_SHORT).show()
            "set_wallpaper" -> selected.singleOrNull()?.let { SetAs.wallpaper(this, Uri.fromFile(it)); clearSelection() }
            "set_ringtone" -> selected.singleOrNull()?.let { SetAs.ringtone(this, Uri.fromFile(it), it.name); clearSelection() }
            "share" -> shareSelected(selected)
            "copy" -> promptCopyMove(selected, move = false)
            "move" -> promptCopyMove(selected, move = true)
            "rename" -> selected.singleOrNull()?.let(::promptRename)
                ?: Toast.makeText(this, R.string.action_not_available_multiple, Toast.LENGTH_SHORT).show()
            "delete" -> confirmDelete(selected)
            "delete_permanent" -> confirmPermanentDelete(selected)
            "details" -> selected.singleOrNull()?.let(::showFileDetails)
                ?: Toast.makeText(this, R.string.action_not_available_multiple, Toast.LENGTH_SHORT).show()
            "copy_path" -> {
                val text = selected.joinToString("\n") { it.absolutePath }
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("OmniHub path", text))
                Toast.makeText(this, getString(R.string.action_copy_success), Toast.LENGTH_SHORT).show()
                clearSelection()
            }
            "favorite" -> {
                val prefs = getSharedPreferences("omnihub_file_favorites", MODE_PRIVATE)
                val paths = prefs.getStringSet("paths", emptySet()).orEmpty().toMutableSet()
                selected.forEach { paths.add(it.absolutePath) }
                prefs.edit().putStringSet("paths", paths).apply()
                Toast.makeText(this, R.string.action_favorite_saved, Toast.LENGTH_SHORT).show(); clearSelection()
            }
            "hide" -> selected.singleOrNull()?.let(::toggleHidden)
                ?: Toast.makeText(this, R.string.action_not_available_multiple, Toast.LENGTH_SHORT).show()
            "shortcut" -> selected.singleOrNull()?.let(::createPinnedShortcut)
                ?: Toast.makeText(this, R.string.action_not_available_multiple, Toast.LENGTH_SHORT).show()
            "compress" -> { ArchiveDialogs.showCompressDialog(this, selected, currentDir); clearSelection() }
            "extract_to" -> selected.singleOrNull()?.let {
                FileClipboard.set(listOf(it), FileClipboard.Op.EXTRACT); clearSelection(); updatePasteBar()
                Toast.makeText(this, if (mode == "browse") "Open any folder and tap \"Extract here\"" else "Saved. Open File Manager, go to the folder and tap \"Extract here\"", Toast.LENGTH_LONG).show()
            } ?: Toast.makeText(this, R.string.action_not_available_multiple, Toast.LENGTH_SHORT).show()
            "extract_named" -> selected.singleOrNull()?.let { ArchiveDialogs.extractToNamedFolder(this, it, it.parentFile ?: currentDir) }
            "extract" -> selected.singleOrNull()?.let { ArchiveDialogs.showArchivePreview(this, it, currentDir) }
                ?: Toast.makeText(this, R.string.action_not_available_multiple, Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareSelected(files: List<File>) {
        try {
            if (files.size == 1) MediaShare.share(this, Uri.fromFile(files.first()), mimeForFile(files.first()))
            else {
                val uris = ArrayList<Uri>()
                files.forEach { uris.add(MediaShare.shareableUri(this, Uri.fromFile(it))) }
                val intent = Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*")
                    .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(intent, getString(R.string.action_share)))
            }
        } catch (e: Exception) { Toast.makeText(this, getString(R.string.action_operation_failed, e.localizedMessage ?: "unknown"), Toast.LENGTH_LONG).show() }
        clearSelection()
    }

    private fun promptRename(file: File) {
        if (isProtectedDir(file.parentFile ?: file)) { Toast.makeText(this, R.string.action_protected_blocked, Toast.LENGTH_LONG).show(); return }
        val input = EditText(this).apply { setSingleLine(true); setText(file.name); setSelection(text.length); hint = getString(R.string.action_rename_hint) }
        AlertDialog.Builder(this).setTitle(R.string.action_rename).setView(input)
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.action_confirm) { _, _ ->
                val name = input.text?.toString()?.trim().orEmpty().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (name.isBlank() || name == "." || name == "..") return@setPositiveButton
                val target = File(file.parentFile, name)
                if (target.exists()) { Toast.makeText(this, R.string.action_target_exists, Toast.LENGTH_LONG).show(); return@setPositiveButton }
                runFileTask(getString(R.string.action_rename)) { if (!file.renameTo(target)) throw IllegalStateException("Rename failed") }
                clearSelection()
            }.show()
    }

    /** Copy / Move: remember the files, then the user walks to ANY folder and taps "Paste here". */
    private fun promptCopyMove(files: List<File>, move: Boolean) {
        FileClipboard.set(files, if (move) FileClipboard.Op.MOVE else FileClipboard.Op.COPY)
        clearSelection()
        updatePasteBar()
        Toast.makeText(this, if (mode == "browse") "Open any folder and tap \"Paste here\"" else "Saved. Open File Manager, go to the folder and tap \"Paste here\"", Toast.LENGTH_LONG).show()
    }

    fun refreshPasteBar() { updatePasteBar() }

    private fun updatePasteBar() {
        val bar = pasteBar ?: return
        val show = mode == "browse" && FileClipboard.hasItems && selectedPaths.isEmpty()
        Motion.toggle(bar, show)
        if (!show) return
        pasteLabel?.text = FileClipboard.summary() + "\n→ " + displayName(currentDir).ifBlank { "Internal storage" }
        pasteButton?.text = when (FileClipboard.op) { FileClipboard.Op.MOVE -> "Move here"; FileClipboard.Op.EXTRACT -> "Extract here"; else -> "Paste here" }
    }

    private fun performPaste() {
        val destination = currentDir
        val items = FileClipboard.files.filter { it.exists() }
        if (items.isEmpty()) { FileClipboard.clear(); updatePasteBar(); Toast.makeText(this, "Nothing to paste (files no longer exist)", Toast.LENGTH_LONG).show(); return }
        if (!destination.isDirectory || !destination.canWrite()) { Toast.makeText(this, R.string.archive_destination_invalid, Toast.LENGTH_LONG).show(); return }
        if (isProtectedDir(destination)) { Toast.makeText(this, R.string.action_protected_blocked, Toast.LENGTH_LONG).show(); return }
        val op = FileClipboard.op
        if (op == FileClipboard.Op.ARCHIVE_ENTRIES) {
            ArchiveDialogs.extractEntriesTo(this, items.first(), destination, FileClipboard.archivePassword, FileClipboard.archiveEntries)
            FileClipboard.clear(); updatePasteBar()
            return
        }
        if (op == FileClipboard.Op.EXTRACT) {
            ArchiveDialogs.extractTo(this, items.first(), destination)
            FileClipboard.clear(); updatePasteBar()
            return
        }
        val move = op == FileClipboard.Op.MOVE
        RecentFolders.changed(this, destination)
        if (move) items.forEach { RecentFolders.changed(this, it.parentFile) }
        val cancelled = java.util.concurrent.atomic.AtomicBoolean(false)
        val skippedCount = AtomicInteger(0)
        runFileTask(getString(if (move) R.string.action_move else R.string.action_copy), {
            // These live on the worker thread only. "Apply to all" answers are remembered per kind.
            var allFiles: ArchiveDialogs.Choice? = null
            var allFolders: ArchiveDialogs.Choice? = null

            fun ask(existing: File, incoming: File): ArchiveDialogs.Choice {
                val isDir = incoming.isDirectory
                val allowReplace = !isDir && existing.isFile
                val remembered = if (isDir) allFolders else allFiles
                if (remembered != null) return if (remembered == ArchiveDialogs.Choice.REPLACE && !allowReplace) ArchiveDialogs.Choice.KEEP_BOTH else remembered
                val answer = ArchiveDialogs.askConflict(this, existing, isDir, if (isDir) -1L else incoming.length(), allowReplace)
                if (answer.applyToAll) { if (isDir) allFolders = answer.choice else allFiles = answer.choice }
                return answer.choice
            }

            /** Puts [source] at [target], which must not exist. */
            fun placeNew(source: File, target: File) {
                if (move && source.renameTo(target)) return // same volume: instant
                copyItemSafely(source, target)
                if (move && !source.deleteRecursively()) throw IllegalStateException("Could not remove source after copy")
            }

            fun transfer(source: File, target: File) {
                if (source.canonicalPath == target.canonicalPath) {
                    // Pasting an item onto itself: moving does nothing, copying makes a numbered duplicate.
                    if (move) skippedCount.incrementAndGet() else placeNew(source, uniqueTarget(target))
                    return
                }
                if (!target.exists()) { placeNew(source, target); return }
                if (source.isDirectory && target.isDirectory) {
                    when (ask(target, source)) {
                        ArchiveDialogs.Choice.MERGE -> {
                            val children = source.listFiles() ?: throw IllegalStateException("Could not read ${source.name}")
                            children.filterNot { it.name == ".omnihub_trash" }.forEach { child -> transfer(child, File(target, child.name)) }
                            if (move) source.delete() // only succeeds when everything inside was moved
                        }
                        ArchiveDialogs.Choice.SKIP -> skippedCount.incrementAndGet()
                        else -> throw UserCancelled()
                    }
                    return
                }
                when (ask(target, source)) {
                    ArchiveDialogs.Choice.REPLACE -> {
                        if (!target.delete()) throw IllegalStateException("Could not replace ${target.name}")
                        placeNew(source, target)
                    }
                    ArchiveDialogs.Choice.KEEP_BOTH, ArchiveDialogs.Choice.MERGE -> placeNew(source, uniqueTarget(target))
                    ArchiveDialogs.Choice.SKIP -> skippedCount.incrementAndGet()
                    ArchiveDialogs.Choice.CANCEL -> throw UserCancelled()
                }
            }

            try {
                items.forEach { source ->
                    if (isProtectedDir(source.parentFile ?: source)) throw IllegalStateException(getString(R.string.action_protected_blocked))
                    if (move && source.absoluteFile.parentFile?.canonicalPath == destination.canonicalPath) return@forEach // already here
                    if (source.isDirectory && (destination.canonicalPath == source.canonicalPath || destination.canonicalPath.startsWith(source.canonicalPath + File.separator))) throw IllegalArgumentException("Cannot copy a folder into itself")
                    transfer(source, File(destination, source.name))
                }
            } catch (_: UserCancelled) { cancelled.set(true) }
        }) { error ->
            if (error == null) {
                val skipped = skippedCount.get()
                if (cancelled.get()) Toast.makeText(this, R.string.action_cancel, Toast.LENGTH_SHORT).show()
                else {
                    if (move) FileClipboard.clear()
                    Toast.makeText(this, (if (move) "Moved " else "Copied ") + items.size + (if (items.size == 1) " item" else " items") + " ✓" + (if (skipped > 0) " · $skipped skipped" else ""), Toast.LENGTH_SHORT).show()
                }
            }
            updatePasteBar()
        }
    }

    private class UserCancelled : RuntimeException()

    /** Title dropdown: folders marked for copy/move/extract, plus recently opened / changed folders. */
    private fun showRecentFolders() {
        val rootPath = Environment.getExternalStorageDirectory().absolutePath
        val dialog = android.app.Dialog(this)
        val scroll = ScrollView(this)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(252, 251, 254)) }
        scroll.addView(column)

        fun shown(path: String): String = if (path == rootPath) "/" else if (path.startsWith("$rootPath/")) path.removePrefix(rootPath) else path
        fun section(title: String) = column.addView(TextView(this).apply {
            text = title; textSize = 13f; setTextColor(mutedColor); typeface = Typeface.DEFAULT_BOLD
            setBackgroundColor(Color.rgb(232, 229, 241)); setPadding(dp(16), dp(9), dp(16), dp(9))
        }, LinearLayout.LayoutParams(-1, -2))
        fun go(path: String) {
            val dir = File(path)
            dialog.dismiss()
            if (!dir.isDirectory) { RecentFolders.remove(this, path); Toast.makeText(this, "Folder no longer exists", Toast.LENGTH_SHORT).show(); return }
            if (isProtectedDir(dir)) { startActivity(Intent(this, ShizukuFileActivity::class.java).putExtra("path", path)); return }
            if (!dir.canRead()) { Toast.makeText(this, "Android cannot read this folder", Toast.LENGTH_SHORT).show(); return }
            navDirection = 1; currentDir = dir; openFolder = null
            if (::searchInput.isInitialized) searchInput.setText("")
            clearSelection()
            refreshEntries()
        }
        fun row(path: String, sub: String?, removable: Boolean, onRemoved: (() -> Unit)? = null) {
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(6), 0); minimumHeight = dp(54)
                isClickable = true; isFocusable = true
                background = android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(38, 102, 80, 196)), android.graphics.drawable.ColorDrawable(Color.rgb(252, 251, 254)), null)
                setOnClickListener { go(path) }
            }
            line.addView(View(this).apply { background = FolderDrawable() }, LinearLayout.LayoutParams(dp(32), dp(26)))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(TextView(this).apply { text = shown(path); textSize = 15f; setTextColor(textColor); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
            if (sub != null) texts.addView(TextView(this).apply { text = sub; textSize = 11f; setTextColor(mutedColor); maxLines = 1 })
            line.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
            if (removable) line.addView(TextView(this).apply {
                text = "✕"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(mutedColor)
                contentDescription = "Remove"; isClickable = true
                setOnClickListener { RecentFolders.remove(this@FileManagerActivity, path); column.removeView(line); onRemoved?.invoke() }
            }, LinearLayout.LayoutParams(dp(46), dp(46)))
            column.addView(line, LinearLayout.LayoutParams(-1, -2))
            column.addView(View(this).apply { setBackgroundColor(Color.rgb(218, 213, 230)) }, LinearLayout.LayoutParams(-1, dp(1)))
        }

        // 1) Folders that hold the items currently marked for copy / move / extract.
        if (FileClipboard.hasItems) {
            section(FileClipboard.summary())
            FileClipboard.files.mapNotNull { it.absoluteFile.parentFile?.absolutePath }.distinct().forEach { row(it, "Source folder", false) }
        }
        // 2) Quick roots.
        section("Main storage")
        row(rootPath, "Internal storage root", false)
        // 3) Recent: opened or changed.
        val recents = RecentFolders.list(this).filter { it.path != currentDir.absolutePath && it.path != rootPath }
        section("Recent folders")
        if (recents.isEmpty()) column.addView(TextView(this).apply { text = "Folders you open or change will appear here."; textSize = 13f; setTextColor(mutedColor); setPadding(dp(16), dp(14), dp(16), dp(14)) })
        recents.forEach { e ->
            val ago = android.text.format.DateUtils.getRelativeTimeSpanString(e.time, System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS).toString()
            row(e.path, (if (e.changed) "Changed · " else "Opened · ") + ago, true)
        }
        if (recents.isNotEmpty()) column.addView(TextView(this).apply {
            text = "Clear recent folders"; textSize = 14f; setTextColor(accent); gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14)); isClickable = true
            setOnClickListener { RecentFolders.clear(this@FileManagerActivity); dialog.dismiss() }
        }, LinearLayout.LayoutParams(-1, -2))

        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        dialog.setContentView(scroll)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.rgb(252, 251, 254)))
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            w.attributes = w.attributes.apply { gravity = Gravity.TOP; dimAmount = .4f }
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        }
        // Never taller than ~70% of the screen; the list scrolls inside.
        val maxH = (resources.displayMetrics.heightPixels * 0.7f).toInt()
        column.measure(View.MeasureSpec.makeMeasureSpec(resources.displayMetrics.widthPixels, View.MeasureSpec.EXACTLY), View.MeasureSpec.UNSPECIFIED)
        dialog.show()
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, if (column.measuredHeight > maxH) maxH else WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showBrowseMenu() {
        val labels = arrayOf(
            "Search & filters",
            if (gridMode) "List view" else "Grid view",
            if (showHiddenFiles) "Hide hidden files" else "Show hidden files",
            "New folder",
            "Sort…",
            "Quick folders…",
            "⚡ Android/data (Shizuku)",
            "⚡ Android/obb (Shizuku)",
            "Refresh"
        )
        AlertDialog.Builder(this).setItems(labels) { _, which ->
            when (which) {
                0 -> {
                    val showIt = searchPanels.firstOrNull()?.visibility != View.VISIBLE
                    searchPanels.forEach { it.visibility = if (showIt) View.VISIBLE else View.GONE }
                    if (showIt) {
                        searchInput.requestFocus()
                        try { (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)?.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) } catch (_: Exception) { }
                    } else searchInput.setText("")
                }
                1 -> toggleGridList()
                2 -> {
                    showHiddenFiles = !showHiddenFiles
                    getSharedPreferences("omnihub_filemanager_view", MODE_PRIVATE).edit().putBoolean("show_hidden_files", showHiddenFiles).apply()
                    updateFilterButtons(); refreshEntries()
                }
                3 -> promptNewFolder()
                4 -> showSortDialog()
                5 -> showQuickFolders()
                6, 7 -> {
                    val rel = if (which == 6) "Android/data" else "Android/obb"
                    startActivity(Intent(this, ShizukuFileActivity::class.java).putExtra("path", Environment.getExternalStorageDirectory().absolutePath + "/" + rel))
                }
                8 -> refreshEntries()
            }
        }.show()
    }

    private fun showQuickFolders() {
        val entries = listOf("Internal storage" to "", "Downloads" to "Download", "Documents" to "Documents", "Music" to "Music", "Movies" to "Movies", "Pictures" to "Pictures", "DCIM" to "DCIM")
        AlertDialog.Builder(this).setItems(entries.map { it.first }.toTypedArray()) { _, i ->
            val rel = entries[i].second
            val dest = if (rel.isEmpty()) Environment.getExternalStorageDirectory() else File(Environment.getExternalStorageDirectory(), rel)
            if (dest.isDirectory && dest.canRead()) {
                navDirection = 1
                currentDir = dest; openFolder = null
                if (::searchInput.isInitialized) searchInput.setText("")
                refreshEntries()
            } else Toast.makeText(this, "${entries[i].first} folder is not available", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun promptNewFolder() {
        val input = EditText(this).apply { setSingleLine(true); hint = "Folder name"; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        AlertDialog.Builder(this).setTitle("New folder").setView(input)
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.action_confirm) { _, _ ->
                val name = input.text?.toString()?.trim().orEmpty().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (name.isBlank() || name == "." || name == "..") return@setPositiveButton
                val target = File(currentDir, name)
                if (target.exists()) { Toast.makeText(this, R.string.action_target_exists, Toast.LENGTH_LONG).show(); return@setPositiveButton }
                if (target.mkdirs()) { RecentFolders.changed(this, currentDir); refreshEntries() } else Toast.makeText(this, "Could not create folder", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun uniqueTarget(initial: File): File {
        if (!initial.exists()) return initial
        val base = initial.nameWithoutExtension.ifBlank { initial.name }
        val ext = initial.extension.takeIf { it.isNotBlank() }?.let { ".$it" }.orEmpty()
        var index = 1
        while (true) {
            val candidate = File(initial.parentFile, "$base ($index)$ext")
            if (!candidate.exists()) return candidate
            index++
        }
    }

    private fun copyItemSafely(source: File, target: File) {
        if (source.canonicalFile != source.absoluteFile && source.absolutePath != source.canonicalPath) throw IllegalStateException("Symbolic links are skipped")
        if (source.isDirectory) {
            if (!target.mkdirs() && !target.isDirectory) throw IllegalStateException("Could not create ${target.name}")
            val children = source.listFiles() ?: throw IllegalStateException("Could not read ${source.name}")
            children.filterNot { it.name == ".omnihub_trash" }.forEach { child -> copyItemSafely(child, File(target, child.name)) }
        } else {
            target.parentFile?.let { if (!it.exists() && !it.mkdirs()) throw IllegalStateException("Could not create destination folder") }
            source.copyTo(target, overwrite = false)
        }
    }

    private fun confirmDelete(files: List<File>) {
        AlertDialog.Builder(this).setTitle(R.string.action_delete_confirm_title)
            .setMessage(R.string.action_delete_confirm_message)
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.action_delete) { _, _ ->
                val trashTargets = mutableListOf<Pair<File, File>>()
                runFileTask(getString(R.string.action_delete), {
                    files.forEach { source ->
                        val parent = source.parentFile ?: throw IllegalStateException("No parent folder")
                        if (isProtectedDir(parent)) throw IllegalStateException(getString(R.string.action_protected_blocked))
                        val trash = File(parent, ".omnihub_trash")
                        if (!trash.exists() && !trash.mkdirs()) throw IllegalStateException("Could not create trash folder")
                        val target = uniqueTarget(File(trash, source.name))
                        if (!source.renameTo(target)) throw IllegalStateException("Could not move ${source.name} to trash")
                        synchronized(trashTargets) { trashTargets.add(target to source) }
                    }
                }, onFinished = { error ->
                    if (error == null && trashTargets.isNotEmpty() && !isFinishing) {
                        AlertDialog.Builder(this).setMessage(R.string.action_delete_success)
                            .setPositiveButton(R.string.action_undo) { _, _ ->
                                runFileTask(getString(R.string.action_undo)) {
                                    trashTargets.forEach { (trashed, original) ->
                                        if (trashed.exists() && !trashed.renameTo(original)) throw IllegalStateException("Undo failed")
                                        trashed.parentFile?.delete()
                                    }
                                }
                            }.setNegativeButton(android.R.string.ok, null).show()
                    }
                    refreshEntries()
                })
                clearSelection()
            }.show()
    }

    private fun confirmPermanentDelete(files: List<File>) {
        AlertDialog.Builder(this)
            .setTitle(R.string.action_permanent_delete_confirm_title)
            .setMessage(getString(R.string.action_permanent_delete_confirm_message, files.size))
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.action_permanent_delete) { _, _ ->
                runFileTask(getString(R.string.action_permanent_delete), {
                    files.forEach { file ->
                        if (isProtectedDir(file.parentFile ?: file)) throw IllegalStateException(getString(R.string.action_protected_blocked))
                        val removed = if (file.isDirectory) file.deleteRecursively() else file.delete()
                        if (!removed) throw IllegalStateException("Could not permanently delete ${file.name}")
                    }
                })
                clearSelection()
            }.show()
    }

    private fun showFileDetails(file: File) {
        runFileTask(getString(R.string.action_details)) {
            var count = 0
            var size = 0L
            if (file.isDirectory) {
                file.walkTopDown().onEnter { !it.name.startsWith(".") && !isProtectedDir(it) }.forEach { child -> if (child != file) { count++; if (child.isFile) size += child.length() } }
            } else size = file.length()
            val kind = if (file.isDirectory) "Folder" else mimeForFile(file)
            val date = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(file.lastModified()))
            val message = getString(R.string.action_details_format, file.name, kind, humanSize(size), date, file.absolutePath, file.canRead(), file.canWrite(), file.canExecute(), count)
            runOnUiThread { if (!isFinishing) AlertDialog.Builder(this).setTitle(R.string.action_details_title).setMessage(message).setPositiveButton(android.R.string.ok, null).show() }
        }
        clearSelection()
    }

    private fun toggleHidden(file: File) {
        if (isProtectedDir(file.parentFile ?: file)) { Toast.makeText(this, R.string.action_protected_blocked, Toast.LENGTH_LONG).show(); return }
        val newName = if (file.name.startsWith(".")) file.name.removePrefix(".") else ".${file.name}"
        val target = File(file.parentFile, newName)
        if (target.exists()) { Toast.makeText(this, R.string.action_target_exists, Toast.LENGTH_LONG).show(); return }
        runFileTask(getString(R.string.action_hide)) { if (!file.renameTo(target)) throw IllegalStateException("Could not change visibility") }
        clearSelection()
    }

    private fun createPinnedShortcut(file: File) {
        if (Build.VERSION.SDK_INT < 26) { Toast.makeText(this, R.string.action_shortcut_unavailable, Toast.LENGTH_LONG).show(); return }
        try {
            val launch = if (file.isDirectory) {
                Intent(this, FileManagerActivity::class.java).putExtra("mode", "browse").putExtra("browse_path", file.absolutePath)
            } else {
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra(MainActivity.EXTRA_OPEN_PATH, file.absolutePath)
            }
            val shortcut = androidx.core.content.pm.ShortcutInfoCompat.Builder(this, ("omni_" + file.absolutePath.hashCode()).take(80))
                .setShortLabel(file.name.take(40)).setLongLabel(file.absolutePath).setIcon(androidx.core.graphics.drawable.IconCompat.createWithResource(this, R.drawable.ic_omnihub)).setIntent(launch).build()
            androidx.core.content.pm.ShortcutManagerCompat.requestPinShortcut(this, shortcut, null)
            clearSelection()
        } catch (e: Exception) { Toast.makeText(this, getString(R.string.action_operation_failed, e.localizedMessage ?: "unknown"), Toast.LENGTH_LONG).show() }
    }

    private fun runFileTask(title: String, work: () -> Unit) = runFileTask(title, work, null)

    private fun runFileTask(title: String, work: () -> Unit, onFinished: ((Throwable?) -> Unit)?) {
        val progress = ProgressBar(this).apply { isIndeterminate = true }
        val dialog = AlertDialog.Builder(this).setTitle(title).setMessage(R.string.action_operation_running).setView(progress).create()
        dialog.setCancelable(false)
        dialog.show()
        val errorRef = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        Thread({
            try { work() } catch (t: Throwable) { errorRef.set(t) }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    dialog.dismiss()
                    val error = errorRef.get()
                    if (error != null) Toast.makeText(this, getString(R.string.action_operation_failed, error.localizedMessage ?: error.javaClass.simpleName), Toast.LENGTH_LONG).show()
                    else if (onFinished == null) Toast.makeText(this, title + " ✓", Toast.LENGTH_SHORT).show()
                    if (error == null) RecentFolders.changed(this, currentDir)
                    onFinished?.invoke(error)
                    refreshEntries()
                }
            }
        }, "OmniHub-FileOperation").apply { isDaemon = true; start() }
    }

    private fun categoriesForMode(): List<String> = when {
        mode == "recent" -> listOf("Recent files")
        mode == "text" -> listOf("All text", "Text / Code")
        mode == "media" && mimeConstraint.startsWith("audio/") -> listOf("Audio")
        mode == "media" && mimeConstraint.startsWith("video/") -> listOf("Video")
        mode == "media" && mimeConstraint.startsWith("image/") -> listOf("Images")
        mode == "media" -> listOf("All media", "Audio", "Video", "Images")
        mimeConstraint.startsWith("image/") -> listOf("Images")
        mimeConstraint.startsWith("audio/") -> listOf("Audio")
        mimeConstraint.startsWith("video/") -> listOf("Video")
        else -> listOf("All files", "Audio", "Video", "Images", "Documents", "Text / Code", "Archives", "APK")
    }.also { if (activeCategory !in it) activeCategory = it.first() }

    private fun updateCategoryStyles() {
        categoryButtons.forEach { (label, button) ->
            val selected = label == activeCategory
            button.backgroundTintList = ColorStateList.valueOf(if (selected) accent else panelAlt)
            button.setTextColor(if (selected) bg else textColor)
        }
    }

    // Remembers the scroll position of every folder so going back restores it.
    private val scrollMemory = HashMap<String, IntArray>()
    private var lastScrollKey: String? = null
    private var pendingScrollRestore: IntArray? = null

    private fun currentScrollKey(): String =
        (if (globalIndexMode && openFolder != null) openFolder!! else currentDir).absolutePath

    private fun rememberScrollForFolderChange() {
        val newKey = currentScrollKey()
        val oldKey = lastScrollKey
        if (oldKey != null && oldKey != newKey && ::listView.isInitialized) {
            val lm = listView.layoutManager as? LinearLayoutManager
            val pos = lm?.findFirstVisibleItemPosition() ?: -1
            if (pos >= 0) {
                val top = lm?.findViewByPosition(pos)?.top ?: 0
                scrollMemory[oldKey] = intArrayOf(pos, top)
            }
            pendingScrollRestore = scrollMemory[newKey] ?: intArrayOf(0, 0)
        }
        lastScrollKey = newKey
    }

    private fun applyPendingScrollRestore() {
        val target = pendingScrollRestore ?: return
        pendingScrollRestore = null
        if (!::listView.isInitialized) return
        listView.post {
            val lm = listView.layoutManager as? LinearLayoutManager ?: return@post
            val count = listAdapter.itemCount
            if (count > 0) lm.scrollToPositionWithOffset(target[0].coerceAtMost(count - 1), target[1])
        }
    }

    // Watches the open folder so any create / delete / rename / write shows up instantly.
    private var folderObserver: FileObserver? = null
    private var observedPath: String? = null
    private val observerHandler = Handler(Looper.getMainLooper())
    private val observerRefresh = Runnable {
        if (isFinishing || isDestroyed || !managerUiBuilt) return@Runnable
        val searching = ::searchInput.isInitialized && searchInput.text.isNotEmpty()
        if (!searching) refreshEntries()
    }

    private fun ensureFolderObserver() {
        if (globalIndexMode) { stopFolderObserver(); return }
        val path = currentDir.absolutePath
        if (path == observedPath && folderObserver != null) return
        stopFolderObserver()
        val mask = FileObserver.CREATE or FileObserver.DELETE or FileObserver.MOVED_FROM or
            FileObserver.MOVED_TO or FileObserver.CLOSE_WRITE or FileObserver.DELETE_SELF or FileObserver.MOVE_SELF
        @Suppress("DEPRECATION")
        val obs = object : FileObserver(path, mask) {
            override fun onEvent(event: Int, name: String?) {
                observerHandler.removeCallbacks(observerRefresh)
                observerHandler.postDelayed(observerRefresh, 250)
            }
        }
        try { obs.startWatching(); folderObserver = obs; observedPath = path } catch (_: Throwable) { }
    }

    private fun stopFolderObserver() {
        try { folderObserver?.stopWatching() } catch (_: Throwable) { }
        folderObserver = null
        observedPath = null
        observerHandler.removeCallbacks(observerRefresh)
    }

    override fun onPause() {
        stopFolderObserver()
        super.onPause()
    }

    fun onArchiveJobFinished() { if (!isFinishing && !isDestroyed) refreshEntries() }

    private fun refreshEntries() {
        if (!managerUiBuilt || !::listAdapter.isInitialized) return
        rememberScrollForFolderChange()
        ensureFolderObserver()
        if (mode == "browse" && !globalIndexMode && lastRecordedDir != currentDir.absolutePath) {
            lastRecordedDir = currentDir.absolutePath
            // The storage root itself is always one tap away (Home), so only real folders are remembered.
            if (currentDir.absolutePath != Environment.getExternalStorageDirectory().absolutePath) RecentFolders.visit(this, currentDir)
        }
        try {
            pathLabel.text = if (globalIndexMode && openFolder != null) relativePath(openFolder!!) else if (mode == "browse") displayName(currentDir).ifBlank { "Internal storage" } + "  ▾" else folderLabel(currentDir)
            val query = if (::searchInput.isInitialized) searchInput.text.toString().trim().lowercase(Locale.ROOT) else ""
            shownFiles.clear()
            val categories = categoriesForMode()
            val category = activeCategory.takeIf { it in categories } ?: categories.first()
            computeSince()
            // Normal file manager: typing searches the WHOLE phone storage, not just the open folder.
            if (query.isNotEmpty() && !globalIndexMode) { runGlobalSearch(query, category); return }
            cancelSearch()
            val all: List<File> = if (globalIndexMode) {
                val rootPath = Environment.getExternalStorageDirectory().absolutePath
                val scopePath = currentDir.absolutePath
                val opened = openFolder
                folderMeta.clear()
                if (opened != null) {
                    // Folder view: just the files that sit directly in this folder.
                    val openedPath = opened.absolutePath
                    indexedFiles.filter { f ->
                        f.absoluteFile.parent == openedPath && passesFilters(f, category) &&
                            (query.isEmpty() || f.name.lowercase(Locale.ROOT).contains(query))
                    }
                } else if (mode == "recent") {
                    // Recent mode is a true flat list, sorted newest-first, rather than a list of parent folders.
                    indexedFiles.filter { f -> passesFilters(f, category) &&
                        (query.isEmpty() || f.name.lowercase(Locale.ROOT).contains(query)) }
                } else {
                    // Flat folder list: every folder that directly holds matching files, one pass over the index.
                    val counts = HashMap<String, Int>()
                    val looseFiles = ArrayList<File>()
                    for (file in indexedFiles) {
                        if (!passesFilters(file, category)) continue
                        val parent = file.absoluteFile.parent ?: continue
                        if (!(parent == scopePath || parent.startsWith("$scopePath/"))) continue
                        if (query.isEmpty()) {
                            counts[parent] = (counts[parent] ?: 0) + 1
                        } else if (File(parent).name.lowercase(Locale.ROOT).contains(query)) {
                            counts[parent] = (counts[parent] ?: 0) + 1
                        } else if (file.name.lowercase(Locale.ROOT).contains(query)) {
                            looseFiles.add(file)
                        }
                    }
                    val dirs = ArrayList<File>(counts.size)
                    for ((path, n) in counts) {
                        dirs.add(File(path))
                        val rel = if (path.length > rootPath.length) path.substring(rootPath.length).trimStart('/') else ""
                        val where = rel.substringBeforeLast('/', "")
                        folderMeta[path] = (if (n == 1) "1 file" else "$n files") + (if (where.isNotEmpty()) "  ·  $where" else "")
                    }
                    dirs + looseFiles
                }
            } else {
                try { currentDir.listFiles()?.toList() ?: emptyList() } catch (_: Exception) { emptyList() }
            }
            // Stat each entry once (isDirectory is a filesystem call) instead of on every sort comparison.
            val dirFlags = HashMap<File, Boolean>()
            val visible = ArrayList<File>()
            for (file in all) {
                if (file.name == ".omnihub_trash") continue
                if (file.name.startsWith(".") && !showHiddenFiles) continue
                val isDir = file.isDirectory
                if (!isDir) {
                    val okQuery = query.isEmpty() || file.name.lowercase(Locale.ROOT).contains(query) ||
                        (!globalIndexMode && file.absolutePath.lowercase(Locale.ROOT).contains(query))
                    if (!okQuery || !passesFilters(file, category)) continue
                }
                dirFlags[file] = isDir
                visible.add(file)
            }
            sortFiles(visible, dirFlags)
            shownFiles.addAll(visible)
            if (globalIndexMode && openFolder == null) {
                if (mode == "recent") pathLabel.text = "Recent files  ·  ${visible.size} items"
                else {
                    val folderCount = visible.count { dirFlags[it] == true }
                    val scopeName = if (currentDir.absolutePath == Environment.getExternalStorageDirectory().absolutePath) "All folders" else folderLabel(currentDir)
                    pathLabel.text = "$scopeName  ·  $folderCount " + (if (folderCount == 1) "folder" else "folders")
                }
            }
            notifyRowsChanged()
            updateCategoryStyles()
            updatePasteBar()
            emptyLabel.text = if (query.isNotEmpty()) "Nothing matches your search." else if (mode == "recent") "No recent files found yet. Tap Refresh to scan again." else if (globalIndexMode) "No folders with files found yet. Tap Refresh if you just added files." else "No accessible files here. Try another folder or grant storage access."
        } catch (e: Exception) {
            // File listings can fail on protected or removable folders; never crash the activity.
            shownFiles.clear()
            try { notifyRowsChanged() } catch (_: Exception) { }
            emptyLabel.text = "This folder could not be read. Try another folder."
        }
    }


    private fun notifyRowsChanged() {
        rebuildDisplayRows()
        if (::listAdapter.isInitialized) listAdapter.notifyDataSetChanged()
        if (navDirection != 0 && ::listView.isInitialized) { Motion.cascade(listView, navDirection); navDirection = 0 }
        applyPendingScrollRestore()
        updateStickyHeader()
        updateEmptyState()
        if (::listView.isInitialized) listView.post { updateStickyHeader(); updateEmptyState() }
    }

    /**
     * Remove the legacy SharedPreferences XML without opening/parsing it. Earlier builds put
     * the complete path index into one preference string; on large phones that XML could be
     * enormous and loading it could exhaust the app's heap before the browser even appeared.
     * This file contains only the old cache, not user documents.
     */
    private fun removeLegacyOversizedIndexCache() {
        try {
            val oldDir = File(applicationInfo.dataDir, "shared_prefs")
            File(oldDir, "omnihub_media_index_v2.xml").delete()
            File(oldDir, "omnihub_media_index_v2.xml.bak").delete()
        } catch (_: Exception) { }
    }

    private fun cacheFileForMode(): File = File(indexDirectory, "${mode}_paths_v3.txt")

    private val indexListener = object : LibraryIndex.Listener {
        override fun onIndexUpdated() { applySharedIndex() }
    }

    /** Copies the process-wide index (built at app start) into this screen and redraws. */
    private fun applySharedIndex() {
        if (isFinishing || isDestroyed || !globalIndexMode || !managerUiBuilt) return
        val files = LibraryIndex.list(mode)
        scanInProgress = LibraryIndex.scanning
        indexedFiles.clear()
        indexedFiles.addAll(files)
        if (LibraryIndex.scanning) {
            scanProgress?.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
            scanStatus?.apply { text = if (files.isEmpty()) "Loading library…" else "Updating · ${files.size} files"; visibility = View.VISIBLE }
        } else {
            scanProgress?.visibility = View.GONE
            scanStatus?.apply {
                text = "Library ready · ${files.size} files"
                visibility = View.VISIBLE
                postDelayed({ if (!LibraryIndex.scanning && !isFinishing) visibility = View.GONE }, 1500)
            }
        }
        refreshEntries()
    }

    /** The index is already (being) built in the background; just attach to it. */
    private fun loadCachedIndexInBackground() {
        if (!globalIndexMode || cacheLoadStarted) return
        cacheLoadStarted = true
        LibraryIndex.addListener(indexListener)
        if (LibraryIndex.ready) applySharedIndex()
        else {
            scanProgress?.visibility = View.VISIBLE
            scanStatus?.apply { text = "Loading library…"; visibility = View.VISIBLE }
        }
        LibraryIndex.warmUp(this, false)
    }

    /** Manual Refresh: force a new background scan; the old list stays visible meanwhile. */
    private fun startIndexScan(showProgress: Boolean) {
        if (!globalIndexMode || isFinishing || isDestroyed) return
        LibraryIndex.addListener(indexListener)
        if (showProgress) {
            scanProgress?.visibility = View.VISIBLE
            scanStatus?.apply { text = "Scanning storage in background…"; visibility = View.VISIBLE }
        }
        LibraryIndex.warmUp(this, true)
    }

    // ===================== search, sort and filters =====================

    private fun scheduleRefresh() {
        searchHandler.removeCallbacks(searchTrigger)
        val q = if (::searchInput.isInitialized) searchInput.text.toString().trim() else ""
        if (q.isEmpty()) refreshEntries()
        else searchHandler.postDelayed(searchTrigger, if (globalIndexMode) 150L else 400L)
    }

    private fun cancelSearch() {
        searchGen.incrementAndGet()
        searchHandler.removeCallbacks(searchTrigger)
        if (showingSearch) {
            showingSearch = false
            if (!scanInProgress) scanProgress?.visibility = View.GONE
        }
    }

    /** Internal storage plus any SD card / USB volume Android exposes to the app. */
    private fun searchRoots(): List<File> {
        val roots = LinkedHashSet<File>()
        roots.add(Environment.getExternalStorageDirectory())
        try {
            val dirs = getExternalFilesDirs(null)
            if (dirs != null) for (d in dirs) {
                val path = d?.absolutePath ?: continue
                val idx = path.indexOf("/Android/")
                if (idx > 0) {
                    val r = File(path.substring(0, idx))
                    if (r.isDirectory && r.canRead()) roots.add(r)
                }
            }
        } catch (_: Exception) { }
        return roots.toList()
    }

    /** Search / libraries never wander into /Android (data, obb, media). Browsing there by hand still works. */
    private fun isInsideAndroidDir(dir: File): Boolean {
        val p = dir.absolutePath
        return p.endsWith("/Android") || p.contains("/Android/")
    }

    private fun isProtectedDir(dir: File): Boolean {
        val p = dir.absolutePath
        return p.endsWith("/Android/data") || p.endsWith("/Android/obb") || p.contains("/Android/data/") || p.contains("/Android/obb/")
    }

    private fun runGlobalSearch(query: String, category: String) {
        val gen = searchGen.incrementAndGet()
        showingSearch = true
        val tokens = query.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val wantDirs = category == categoriesForMode().first() && extFilter.isEmpty()
        val roots = searchRoots()
        scanProgress?.visibility = View.VISIBLE
        scanStatus?.apply { text = "Searching the whole phone storage…"; visibility = View.VISIBLE }
        shownFiles.clear()
        notifyRowsChanged()
        pathLabel.text = "Search · whole storage …"
        emptyLabel.text = "Searching…"
        try {
            searchExecutor.execute {
                val found = ArrayList<File>()
                var lastPublish = 0L
                var truncated = false
                fun publish(done: Boolean) {
                    val snapshot = ArrayList(found)
                    val trunc = truncated
                    runOnUiThread {
                        if (gen == searchGen.get() && !isFinishing && !isDestroyed) applySearchResults(snapshot, done, trunc)
                    }
                }
                try {
                    loop@ for (rootDir in roots) {
                        val walk = rootDir.walkTopDown().onEnter { d ->
                            gen == searchGen.get() && (d == rootDir || (!d.name.startsWith(".") && !isProtectedDir(d) && !isInsideAndroidDir(d))) && d.canRead()
                        }
                        for (f in walk) {
                            if (gen != searchGen.get()) return@execute
                            if (f == rootDir) continue
                            val name = f.name
                            if (name.startsWith(".")) continue
                            val lower = name.lowercase(Locale.ROOT)
                            var all = true
                            for (t in tokens) if (!lower.contains(t)) { all = false; break }
                            if (!all) continue
                            if (f.isDirectory) {
                                if (!wantDirs) continue
                                if (sinceMs > 0L && f.lastModified() < sinceMs) continue
                            } else if (!passesFilters(f, category)) continue
                            found.add(f)
                            if (found.size >= MAX_SEARCH_RESULTS) { truncated = true; break@loop }
                            val now = System.currentTimeMillis()
                            if (now - lastPublish > 400L) { lastPublish = now; publish(false) }
                        }
                    }
                } catch (_: Throwable) { }
                if (gen == searchGen.get()) publish(true)
            }
        } catch (_: Exception) {
            scanProgress?.visibility = View.GONE
            emptyLabel.text = "Search could not start."
        }
    }

    private fun applySearchResults(list: List<File>, done: Boolean, truncated: Boolean) {
        if (!showingSearch || !::listAdapter.isInitialized) return
        val dirFlags = HashMap<File, Boolean>(list.size * 2)
        for (f in list) dirFlags[f] = f.isDirectory
        val sorted = ArrayList(list)
        sortFiles(sorted, dirFlags)
        shownFiles.clear()
        shownFiles.addAll(sorted)
        notifyRowsChanged()
        val n = sorted.size
        pathLabel.text = "Search · $n " + (if (n == 1) "result" else "results") + (if (truncated) "+" else "") + (if (done) "" else " …")
        emptyLabel.text = if (done) "Nothing matches your search." else "Searching…"
        if (done) {
            scanProgress?.visibility = View.GONE
            scanStatus?.apply {
                text = if (truncated) "Showing the first $MAX_SEARCH_RESULTS matches — type more letters to narrow down" else "Search finished · $n found"
                visibility = View.VISIBLE
                postDelayed({ if (!scanInProgress && !isFinishing) visibility = View.GONE }, 2600)
            }
        }
    }

    private fun sortFiles(list: MutableList<File>, dirFlags: Map<File, Boolean>) {
        val asc = sortIndex == 0 || sortIndex == 3 || sortIndex == 5 || sortIndex == 6
        val key = when (sortIndex) { 0, 1 -> "name"; 2, 3 -> "date"; 4, 5 -> "size"; else -> "type" }
        val dates = HashMap<File, Long>()
        val sizes = HashMap<File, Long>()
        if (key == "date") for (f in list) dates[f] = f.lastModified()
        if (key == "size") for (f in list) if (dirFlags[f] != true) sizes[f] = f.length()
        val cmp = Comparator<File> { a, b ->
            val da = dirFlags[a] == true
            val db = dirFlags[b] == true
            if (da != db) return@Comparator if (da) -1 else 1
            var r = when (key) {
                "date" -> (dates[a] ?: 0L).compareTo(dates[b] ?: 0L)
                "size" -> (sizes[a] ?: 0L).compareTo(sizes[b] ?: 0L)
                "type" -> a.extension.lowercase(Locale.ROOT).compareTo(b.extension.lowercase(Locale.ROOT))
                else -> a.name.lowercase(Locale.ROOT).compareTo(b.name.lowercase(Locale.ROOT))
            }
            // "newest first" / "largest first" are the descending versions of the date / size keys.
            val naturalAsc = when (key) { "date", "size" -> sortIndex == 3 || sortIndex == 5; else -> asc }
            if (!naturalAsc) r = -r
            if (r != 0) r else {
                val n = a.name.lowercase(Locale.ROOT).compareTo(b.name.lowercase(Locale.ROOT))
                if (n != 0) n else a.absolutePath.compareTo(b.absolutePath)
            }
        }
        try { Collections.sort(list, cmp) } catch (_: Exception) { }
    }

    private fun computeSince() {
        val cal = Calendar.getInstance()
        sinceMs = when (dateIndex) {
            1 -> { cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0); cal.timeInMillis }
            2 -> System.currentTimeMillis() - 7L * 86_400_000L
            3 -> System.currentTimeMillis() - 30L * 86_400_000L
            4 -> { cal.set(Calendar.DAY_OF_YEAR, 1); cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0); cal.timeInMillis }
            else -> 0L
        }
    }

    private fun passesFilters(file: File, category: String): Boolean {
        if (!passesBaseFilter(file) || !passesCategory(file, category)) return false
        val exts = extSetCache
        if (exts.isNotEmpty() && file.extension.lowercase(Locale.ROOT) !in exts) return false
        val since = sinceMs
        if (since > 0L && file.lastModified() < since) return false
        return true
    }

    private fun updateFilterButtons() {
        sortButton?.apply {
            text = "⇅ " + SORT_SHORT[sortIndex]
            backgroundTintList = ColorStateList.valueOf(if (sortIndex != 0) accent else panelAlt)
            setTextColor(if (sortIndex != 0) bg else textColor)
        }
        dateButton?.apply {
            text = "📅 " + DATE_LABELS[dateIndex]
            backgroundTintList = ColorStateList.valueOf(if (dateIndex != 0) accent else panelAlt)
            setTextColor(if (dateIndex != 0) bg else textColor)
        }
        typeButton?.apply {
            text = if (extFilter.isEmpty()) "⛃ Any type" else "⛃ ." + extFilter.replace(",", " .")
            backgroundTintList = ColorStateList.valueOf(if (extFilter.isNotEmpty()) accent else panelAlt)
            setTextColor(if (extFilter.isNotEmpty()) bg else textColor)
        }
        showHiddenButton?.apply {
            text = getString(if (showHiddenFiles) R.string.hide_hidden_files else R.string.show_hidden_files)
            contentDescription = text
            backgroundTintList = ColorStateList.valueOf(if (showHiddenFiles) accent else panelAlt)
            setTextColor(if (showHiddenFiles) bg else textColor)
        }
    }

    private fun showSortDialog() {
        AlertDialog.Builder(this).setTitle("Sort by")
            .setSingleChoiceItems(SORT_LABELS, sortIndex) { d, which ->
                sortIndex = which
                d.dismiss()
                updateFilterButtons()
                refreshEntries()
            }.show()
    }

    private fun showDateDialog() {
        AlertDialog.Builder(this).setTitle("Modified")
            .setSingleChoiceItems(DATE_LABELS, dateIndex) { d, which ->
                dateIndex = which
                d.dismiss()
                updateFilterButtons()
                refreshEntries()
            }.show()
    }

    private fun showTypeDialog() {
        val input = EditText(this).apply {
            setText(extFilter.replace(",", ", "))
            hint = "e.g. mp4, mkv  or  pdf"
            setSingleLine(true)
            setPadding(dp(18), dp(12), dp(18), dp(12))
        }
        AlertDialog.Builder(this).setTitle("File type (extension)")
            .setMessage("Show only these extensions. Leave empty for all types.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Clear") { _, _ -> setExtFilter("") }
            .setPositiveButton("Apply") { _, _ -> setExtFilter(input.text.toString()) }
            .show()
    }

    private fun setExtFilter(raw: String) {
        val parts = raw.lowercase(Locale.ROOT).split(',', ' ', ';').map { it.trim().trimStart('.') }.filter { it.isNotEmpty() }.distinct()
        extFilter = parts.joinToString(",")
        extSetCache = parts.toSet()
        updateFilterButtons()
        refreshEntries()
    }

    private fun resetFilters() {
        sortIndex = 0
        dateIndex = 0
        extFilter = ""
        extSetCache = emptySet()
        updateFilterButtons()
        refreshEntries()
    }

    private fun passesBaseFilter(file: File): Boolean {
        val mime = mimeForFile(file)
        if (mode == "recent") return true
        if (mode == "text") return isTextFile(file) && (selectedExtension.isBlank() || file.extension.equals(selectedExtension, true))
        if (mode == "media") return isMediaFile(file)
        if (mode == "browse") {
            if (browseFilterMode == "text" && !isTextFile(file)) return false
            if (browseFilterMode == "media" && !isMediaFile(file)) return false
            if (browseFilterMode == "text" && selectedExtension.isNotBlank() && !file.extension.equals(selectedExtension, true)) return false
        }
        if (mimeConstraint == "*/*" || mimeConstraint == "") return true
        return if (mimeConstraint.endsWith("/*")) mime.startsWith(mimeConstraint.removeSuffix("*")) else mime == mimeConstraint
    }

    private fun passesCategory(file: File, category: String): Boolean {
        val mime = mimeForFile(file)
        return when (category) {
            "Audio" -> mime.startsWith("audio/")
            "Video" -> mime.startsWith("video/")
            "Images" -> mime.startsWith("image/")
            "Text / Code", "All text" -> isTextFile(file)
            "Documents" -> file.extension.lowercase(Locale.ROOT) in DOC_EXTS
            "Archives" -> ArchiveManager.isArchive(file) || file.extension.lowercase(Locale.ROOT) in ARCHIVE_EXTS
            "APK" -> file.extension.equals("apk", true)
            else -> true
        }
    }

    private fun isMediaFile(file: File): Boolean {
        val mime = mimeForFile(file)
        return mime.startsWith("audio/") || mime.startsWith("video/") || mime.startsWith("image/")
    }

    private fun isTextFile(file: File): Boolean {
        val ext = file.extension.lowercase(Locale.ROOT)
        return ext in setOf("txt", "html", "htm", "css", "js", "mjs", "json", "xml", "csv", "md", "markdown", "yaml", "yml", "log", "ini", "kt", "java", "py", "c", "h", "cpp", "sh", "sql", "svg", "gradle", "properties", "ts", "tsx", "jsx", "php", "rb", "go", "rs", "toml", "xmls") || mimeForFile(file).startsWith("text/")
    }

    private val mimeByExt = java.util.concurrent.ConcurrentHashMap<String, String>()
    private fun mimeForFile(file: File): String {
        val name = file.name
        val dot = name.lastIndexOf('.')
        val ext = if (dot < 0 || dot == name.length - 1) "" else name.substring(dot + 1).lowercase(Locale.ROOT)
        mimeByExt[ext]?.let { return it }
        return mimeForExt(ext).also { mimeByExt[ext] = it }
    }

    private fun mimeForExt(ext: String): String {
        val known = when (ext) {
            "mkv" -> "video/x-matroska"
            "flv" -> "video/x-flv"
            "m4v" -> "video/x-m4v"
            "avi" -> "video/x-msvideo"
            "wmv" -> "video/x-ms-wmv"
            "mov" -> "video/quicktime"
            "mpg", "mpeg", "mpe" -> "video/mpeg"
            "3gp", "3gpp" -> "video/3gpp"
            "ts", "m2ts", "mts" -> "video/mp2t"
            "vob" -> "video/dvd"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "flac" -> "audio/flac"
            "opus" -> "audio/opus"
            "ogg", "oga" -> "audio/ogg"
            "amr" -> "audio/amr"
            "wma" -> "audio/x-ms-wma"
            "aiff", "aif" -> "audio/aiff"
            "mid", "midi" -> "audio/midi"
            "mka" -> "audio/x-matroska"
            "webm" -> "video/webm"
            "f4v" -> "video/x-flv"
            "asf" -> "video/x-ms-asf"
            "ogv" -> "video/ogg"
            "divx", "rm", "rmvb", "mxf", "dv", "3g2" -> "video/x-generic"
            "ac3", "eac3" -> "audio/ac3"
            "dts", "ape", "wv", "mp2", "m4b", "weba", "caf", "3ga", "awb" -> "audio/x-generic"
            "heic" -> "image/heic"
            "heif" -> "image/heif"
            "avif" -> "image/avif"
            "jfif", "jpe" -> "image/jpeg"
            "ico" -> "image/x-icon"
            "wbmp" -> "image/vnd.wap.wbmp"
            "dng" -> "image/x-adobe-dng"
            "svg" -> "image/svg+xml"
            "apk" -> "application/vnd.android.package-archive"
            else -> null
        }
        return known ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun goParent() {
        navDirection = -1
        val rootDir = Environment.getExternalStorageDirectory()
        if (globalIndexMode) {
            if (openFolder != null) {
                openFolder = null
                if (::searchInput.isInitialized) searchInput.setText("")
                refreshEntries()
                return
            }
            if (currentDir.absolutePath != rootDir.absolutePath) {
                currentDir = rootDir
                if (::searchInput.isInitialized) searchInput.setText("")
                refreshEntries()
                return
            }
            setResult(RESULT_CANCELED)
            finish()
            return
        }
        val parent = currentDir.parentFile
        if (parent != null && searchRoots().any { parent.absolutePath.startsWith(it.absolutePath) }) {
            currentDir = parent
            if (::searchInput.isInitialized) searchInput.setText("")
            refreshEntries()
        } else {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    fun openFileInsideOmniHub(file: File) {
        try {
            val mime = mimeForFile(file)
            val uri = Uri.fromFile(file)
            when {
                ArchiveManager.isArchive(file) -> ArchiveDialogs.showArchivePreview(this, file)
                mime.startsWith("video/") || mime.startsWith("audio/") -> startActivity(Intent(this, MediaActivity::class.java).setDataAndType(uri, mime).putExtra("mime", mime).putExtra("name", file.name).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                mime.startsWith("image/") -> startActivity(Intent(this, ImagePreviewActivity::class.java).setData(uri).putExtra("name", file.name))
                file.extension.equals("html", true) || file.extension.equals("htm", true) -> startActivity(Intent(this, HtmlRunnerActivity::class.java).putExtra("html_path", file.absolutePath))
                else -> {
                    startActivity(Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra(MainActivity.EXTRA_OPEN_PATH, file.absolutePath))
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "File could not open: ${e.localizedMessage ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun promptSaveInCurrentFolder() {
        val input = EditText(this).apply {
            setText(saveName)
            setSelection(text.length)
            setSingleLine(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setTextColor(textColor)
        }
        AlertDialog.Builder(this)
            .setTitle("Save to ${currentDir.name.ifBlank { "Internal storage" }}")
            .setMessage("Folder: " + folderLabel(currentDir))
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val name = safeFileName(input.text.toString())
                val target = File(currentDir, name)
                if (target.exists()) {
                    AlertDialog.Builder(this)
                        .setTitle("File already exists")
                        .setMessage("Replace ${target.name}?")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Replace") { _, _ -> returnSavePath(target) }
                        .show()
                } else returnSavePath(target)
            }
            .show()
    }

    private fun returnSavePath(file: File) {
        setResult(RESULT_OK, Intent().putExtra("save_path", file.absolutePath))
        finish()
    }

    private fun safeFileName(raw: String): String = raw.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120).ifBlank { "untitled.txt" }

    private fun makeButton(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(if (color == accent) bg else textColor)
        backgroundTintList = ColorStateList.valueOf(color)
        minHeight = dp(36)
        minWidth = dp(40)
        setPadding(dp(10), 0, dp(10), 0)
        stateListAnimator = null; elevation = 0f   // flat: no raised shadow on any button
        setOnClickListener { action() }
        Motion.press(this, 0.93f)
    }

    /** Borderless text/icon button used in the clean toolbar. */
    private fun makeFlatButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 13f
        isAllCaps = false
        setTextColor(accent)
        background = android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(38, 102, 80, 196)), null, android.graphics.drawable.ColorDrawable(Color.rgb(252, 251, 254)))
        stateListAnimator = null; elevation = 0f
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { action() }
    }

    private inner class FileRowsAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount(): Int = displayRows.size
        override fun getItemViewType(position: Int): Int = when (displayRows[position]) {
            is DisplayRow.DateHeader -> TYPE_DATE_HEADER
            is DisplayRow.FileItem -> TYPE_FILE_ITEM
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return if (viewType == TYPE_DATE_HEADER) {
                val label = TextView(this@FileManagerActivity).apply {
                    setTextColor(mutedColor)
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(9), dp(6), dp(9), dp(5))
                    minHeight = dp(31)
                    setBackgroundColor(Color.rgb(232, 229, 241))
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                HeaderHolder(label)
            } else {
                // Explicit match_parent width: without it RecyclerView wraps each row to its content (narrow cards).
                FileHolder(FrameLayout(this@FileManagerActivity).apply { setBackgroundColor(Color.TRANSPARENT); layoutParams = RecyclerView.LayoutParams(-1, -2) })
            }
        }
        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val row = displayRows[position]) {
                is DisplayRow.DateHeader -> (holder as HeaderHolder).label.text = row.label
                is DisplayRow.FileItem -> {
                    val file = row.file
                    val itemView = holder.itemView
                    if (holder is FileHolder) {
                        val bindKey = fileSig(file) + "|" + gridMode + "|" + showingSearch + "|" + (folderMeta[file.absolutePath] ?: "")
                        if (holder.container.tag == bindKey && holder.container.childCount > 0) {
                            updateSelectedPresentation(holder.container, file)
                            return
                        }
                        cancelThumbnailsInView(holder.container)
                        holder.container.removeAllViews()
                        val content = if (gridMode) createGridTile(file) else if (mode == "browse" || globalIndexMode) createFlatRow(file) else createListRow(file)
                        holder.container.tag = bindKey
                        holder.container.addView(content, FrameLayout.LayoutParams(-1, -2))
                        holder.container.setOnClickListener { openOrSelectFile(file) }
                        Motion.press(holder.container, if (gridMode) 0.95f else 0.985f)
                        holder.container.setOnLongClickListener {
                            itemView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                            toggleSelectedPath(file)
                            true
                        }
                    }
                }
            }
        }
        override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
            if (holder is FileHolder) cancelThumbnailsInView(holder.container)
            super.onViewRecycled(holder)
        }
        inner class HeaderHolder(val label: TextView) : RecyclerView.ViewHolder(label)
        inner class FileHolder(val container: FrameLayout) : RecyclerView.ViewHolder(container)
    }

    private fun updateSelectedPresentation(container: FrameLayout, file: File) {
        val selected = selectedPaths.contains(file.absolutePath)
        container.findViewWithTag<View>(FLAT_ROW_TAG)?.let { flat ->
            flat.background = flatRowBackground(selected)
            flat.findViewWithTag<CheckBox>(FLAT_CHECK_TAG)?.let { cb ->
                if (cb.isChecked != selected) { cb.isChecked = selected; if (selected) Motion.pop(cb) }
            }
            return
        }
        if (gridMode) {
            val tile = container.getChildAt(0) as? SquareFrameLayout ?: return
            tile.setBackground(roundedDrawable(Color.rgb(252, 251, 254), dp(12), if (selected) dp(2) else 0, if (selected) accent else Color.TRANSPARENT))
            tile.findViewWithTag<TextView>(GRID_SELECTED_BADGE_TAG)?.visibility = if (selected) View.VISIBLE else View.GONE
        } else {
            val outer = container.getChildAt(0) as? FrameLayout ?: return
            val row = outer.getChildAt(0) as? LinearLayout ?: return
            val shape = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(252, 251, 254))
                setStroke(if (selected) dp(2) else dp(1), if (selected) accent else Color.rgb(218, 213, 230))
            }
            row.background = android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(38, 102, 80, 196)), shape, null)
            (row.getChildAt(row.childCount - 1) as? TextView)?.text =
                if (selected) "✓" else if (file.isDirectory) "›" else if (mode == "save") "" else "Select"
        }
    }

    private fun openOrSelectFile(file: File) {
        if (selectedPaths.isNotEmpty()) {
            toggleSelectedPath(file)
            return
        }
        if (file.isDirectory) {
            val ext = Environment.getExternalStorageDirectory().absolutePath
            val protectedRoots = listOf("$ext/Android/data", "$ext/Android/obb")
            if (protectedRoots.any { file.absolutePath == it || file.absolutePath.startsWith("$it/") }) {
                // Android blocks these folders for normal apps: open them through Shizuku.
                startActivity(Intent(this, ShizukuFileActivity::class.java).putExtra("path", file.absolutePath))
                return
            }
            if (!file.canRead()) Toast.makeText(this, "Android cannot read this folder", Toast.LENGTH_SHORT).show()
            else if (globalIndexMode) {
                navDirection = 1
                openFolder = file
                if (::searchInput.isInitialized) searchInput.setText("")
                refreshEntries()
            } else {
                navDirection = 1
                currentDir = file
                if (::searchInput.isInitialized) searchInput.setText("")
                refreshEntries()
            }
        } else if (mode == "browse" || (mode != "save" && callingActivity == null)) {
            // Opened from the Library tiles / launcher (not as a file picker): there is nobody to return a
            // result to, so actually open the file instead of silently closing the screen.
            openFileInsideOmniHub(file)
        } else if (mode != "save") {
            setResult(RESULT_OK, Intent().putExtra("selected_path", file.absolutePath))
            finish()
        }
    }

    private fun flatRowBackground(selected: Boolean) = android.graphics.drawable.RippleDrawable(
        ColorStateList.valueOf(Color.argb(38, 102, 80, 196)),
        android.graphics.drawable.ColorDrawable(if (selected) Color.rgb(228, 233, 252) else Color.TRANSPARENT), null
    )

    /** Simple yellow folder glyph (no border / card), like a classic file manager. */
    private class FolderDrawable : android.graphics.drawable.Drawable() {
        private val body = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(236, 201, 75) }
        private val tab = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(222, 178, 52) }
        override fun draw(canvas: android.graphics.Canvas) {
            val b = bounds
            val w = b.width().toFloat(); val h = b.height().toFloat()
            val r = h * 0.12f
            canvas.drawRoundRect(b.left + w * 0.02f, b.top + h * 0.10f, b.left + w * 0.45f, b.top + h * 0.40f, r, r, tab)
            canvas.drawRoundRect(b.left + w * 0.02f, b.top + h * 0.22f, b.left + w * 0.98f, b.top + h * 0.90f, r, r, body)
        }
        override fun setAlpha(alpha: Int) { body.alpha = alpha; tab.alpha = alpha }
        override fun setColorFilter(cf: android.graphics.ColorFilter?) { body.setColorFilter(cf); tab.setColorFilter(cf) }
        @Deprecated("Deprecated in Java") override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun typeBadge(file: File, mime: String): Pair<String, Int> {
        val ext = file.extension.lowercase(Locale.ROOT)
        return when {
            mime.startsWith("audio/") -> "♫" to Color.rgb(38, 166, 154)
            ext == "apk" -> "APK" to Color.rgb(104, 159, 56)
            ArchiveManager.isArchive(file) || ext in ARCHIVE_EXTS -> "ZIP" to Color.rgb(95, 115, 112)
            ext == "pdf" -> "PDF" to Color.rgb(229, 57, 53)
            ext in DOC_EXTS -> ext.take(4).uppercase(Locale.ROOT) to Color.rgb(66, 133, 244)
            isTextFile(file) -> ext.take(4).uppercase(Locale.ROOT).ifBlank { "TXT" } to Color.rgb(120, 144, 156)
            else -> ext.take(4).uppercase(Locale.ROOT).ifBlank { "FILE" } to Color.rgb(140, 150, 165)
        }
    }

    private fun createFlatRow(file: File): View {
        val selected = selectedPaths.contains(file.absolutePath)
        val row = LinearLayout(this).apply {
            tag = FLAT_ROW_TAG
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(7), dp(0), dp(7))
            minimumHeight = dp(66)
            background = flatRowBackground(selected)
        }
        val mime = if (file.isDirectory) "" else mimeForFile(file)
        val iconSize = dp(48)
        if (file.isDirectory) {
            row.addView(ImageView(this).apply { setImageDrawable(FolderDrawable()) }, LinearLayout.LayoutParams(iconSize, iconSize))
        } else if (mime.startsWith("image/") || mime.startsWith("video/")) {
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.rgb(232, 229, 241))
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: android.graphics.Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(8).toFloat()) }
                }
                clipToOutline = true
            }
            row.addView(thumb, LinearLayout.LayoutParams(iconSize, iconSize))
            requestThumbnail(file, thumb)
        } else {
            val (label, color) = typeBadge(file, mime)
            row.addView(TextView(this).apply {
                text = label; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                textSize = if (label.length > 2) 11f else 20f
                background = roundedDrawable(color, dp(10))
            }, LinearLayout.LayoutParams(iconSize, iconSize))
        }
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        details.addView(TextView(this).apply {
            text = displayName(file); setTextColor(textColor); textSize = 16f; maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        val second = TextView(this).apply { setTextColor(mutedColor); textSize = 12f; maxLines = 1 }
        if (file.isDirectory) { val meta = folderMeta[file.absolutePath]; if (meta != null) second.text = meta else bindFolderCount(file, second) }
        else second.text = "${humanSize(file.length())}  ·  ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(file.lastModified()))}"
        details.addView(second)
        if (showingSearch) {
            val where = file.parentFile?.let { relativePath(it) } ?: ""
            details.addView(TextView(this).apply {
                text = "📁 $where"; setTextColor(mutedColor); textSize = 10f; maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            })
        }
        row.addView(details, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        val check = CheckBox(this).apply {
            tag = FLAT_CHECK_TAG
            isChecked = selected
            isClickable = false; isFocusable = false
            buttonTintList = ColorStateList.valueOf(accent)
        }
        val hit = FrameLayout(this).apply {
            isClickable = true; isFocusable = true
            contentDescription = "Select ${file.name}"
            setOnClickListener { toggleSelectedPath(file) }
            addView(check, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        row.addView(hit, LinearLayout.LayoutParams(dp(54), dp(54)))
        return row
    }

    private fun bindFolderCount(folder: File, target: TextView) {
        val key = folder.absolutePath + "|" + folder.lastModified()
        target.tag = key
        val cached = folderCountCache.get(key)
        if (cached != null) { target.text = cached; return }
        target.text = "Folder"
        try {
            thumbnailExecutor.execute {
                val n = try { folder.list()?.count { showHiddenFiles || !it.startsWith(".") } } catch (_: Throwable) { null }
                val text = if (n == null) "Folder" else if (n == 1) "1 item" else "$n items"
                folderCountCache.put(key, text)
                runOnUiThread { if (target.tag == key) target.text = text }
            }
        } catch (_: Exception) { }
    }

    private fun createListRow(file: File): View {
        val row = LinearLayout(this@FileManagerActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(9))
            minimumHeight = dp(62)
            val shape = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(252, 251, 254))
                setStroke(if (selectedPaths.contains(file.absolutePath)) dp(2) else dp(1), if (selectedPaths.contains(file.absolutePath)) accent else Color.rgb(218, 213, 230))
            }
            background = android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(38, 102, 80, 196)), shape, null)
        }
        val thumb = ImageView(this@FileManagerActivity).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(232, 229, 241))
            contentDescription = "Media thumbnail"
        }
        val thumbParams = LinearLayout.LayoutParams(dp(54), dp(48))
        val mime = if (file.isDirectory) "" else mimeForFile(file)
        val fallback = when {
            file.isDirectory -> "📁"
            mime.startsWith("audio/") -> "♫"
            mime.startsWith("video/") -> "▶"
            mime.startsWith("image/") -> "▧"
            isTextFile(file) -> "⌘"
            else -> "▤"
        }
        val fallbackLabel = TextView(this@FileManagerActivity).apply {
            text = fallback; textSize = 22f; gravity = Gravity.CENTER; setTextColor(accent)
        }
        if (file.isDirectory || (!mime.startsWith("image/") && !mime.startsWith("video/"))) {
            val tile = FrameLayout(this@FileManagerActivity)
            tile.addView(thumb, FrameLayout.LayoutParams(-1, -1))
            tile.addView(fallbackLabel, FrameLayout.LayoutParams(-1, -1))
            row.addView(tile, thumbParams)
        } else {
            row.addView(thumb, thumbParams)
            requestThumbnail(file, thumb)
        }
        val details = LinearLayout(this@FileManagerActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        details.addView(TextView(this@FileManagerActivity).apply {
            text = displayName(file); setTextColor(textColor); textSize = 14f; maxLines = 2
            typeface = if (file.isDirectory) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        })
        val second = if (file.isDirectory) (folderMeta[file.absolutePath] ?: "Folder") else "${humanSize(file.length())}  ·  ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(file.lastModified()))}"
        details.addView(TextView(this@FileManagerActivity).apply { text = second; setTextColor(mutedColor); textSize = 10f; maxLines = 1 })
        if (file.isDirectory) {
            val strip = LinearLayout(this@FileManagerActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = file.absolutePath; visibility = View.GONE
            }
            details.addView(strip, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(3) })
            loadFolderPreviewWhenAttached(file, strip) { preview ->
                if (strip.tag == file.absolutePath && !isFinishing && !isDestroyed) {
                    strip.removeAllViews()
                    preview.children.take(4).forEach { child ->
                        val box = FrameLayout(this@FileManagerActivity).apply { background = roundedDrawable(Color.rgb(232, 229, 241), dp(7)); clipToOutline = true }
                        val img = ImageView(this@FileManagerActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = child.name }
                        box.addView(img, FrameLayout.LayoutParams(-1, -1))
                        if (mimeForFile(child).startsWith("image/") || mimeForFile(child).startsWith("video/")) requestThumbnail(child, img)
                        else box.addView(TextView(this@FileManagerActivity).apply { text = if (mimeForFile(child).startsWith("audio/")) "♫" else "▤"; gravity = Gravity.CENTER; setTextColor(accent); textSize = 18f }, FrameLayout.LayoutParams(-1, -1))
                        strip.addView(box, LinearLayout.LayoutParams(dp(44), dp(38)).apply { rightMargin = dp(4) })
                    }
                    if (preview.hasMore) strip.addView(TextView(this@FileManagerActivity).apply { text = "+…"; setTextColor(accent); textSize = 11f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(34), dp(38)))
                    strip.visibility = if (preview.children.isNotEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
        if (showingSearch) {
            val where = file.parentFile?.let { relativePath(it) } ?: ""
            details.addView(TextView(this@FileManagerActivity).apply {
                text = "📁 $where"; setTextColor(Color.rgb(94, 88, 112)); textSize = 10f; maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            })
        }
        row.addView(details, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        row.addView(TextView(this@FileManagerActivity).apply {
            text = if (selectedPaths.contains(file.absolutePath)) "✓" else if (file.isDirectory) "›" else if (mode == "save") "" else "Select"
            setTextColor(accent); textSize = 11f; gravity = Gravity.CENTER; setPadding(dp(4), 0, dp(2), 0)
        })
        return FrameLayout(this@FileManagerActivity).apply {
            setPadding(0, dp(3), 0, dp(3))
            addView(row, FrameLayout.LayoutParams(-1, -2))
        }
    }

    private fun displayName(file: File): String =
        if (file.isDirectory && file.absolutePath == Environment.getExternalStorageDirectory().absolutePath) "Internal storage" else file.name

    private fun relativePath(dir: File): String {
        val rootPath = Environment.getExternalStorageDirectory().absolutePath
        val p = dir.absolutePath
        return if (p.length > rootPath.length && p.startsWith(rootPath)) p.substring(rootPath.length).trimStart('/') else folderLabel(dir)
    }

    // Show only the last folder name (not the whole /storage/emulated/0/... chain).
    private fun folderLabel(dir: File): String =
        if (dir.absolutePath == Environment.getExternalStorageDirectory().absolutePath || dir.name.isBlank()) "Internal storage" else dir.name

    private fun humanSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024.0))
        else -> String.format(Locale.ROOT, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        thumbnailFutures.values.forEach { try { it.cancel(true) } catch (_: Exception) { } }
        thumbnailFutures.clear()
        durationFutures.values.forEach { try { it.cancel(true) } catch (_: Exception) { } }
        durationFutures.clear()
        durationWaiters.clear()
        durationPendingFiles.clear()
        durationInFlight.clear()
        synchronized(durationAttachListeners) {
            durationAttachListeners.keys.toList().forEach { target ->
                durationAttachListeners.remove(target)?.let { try { target.removeOnAttachStateChangeListener(it) } catch (_: Exception) { } }
            }
        }
        synchronized(durationWaiterKeys) { durationWaiterKeys.clear() }
        synchronized(thumbnailAttachListeners) {
            thumbnailAttachListeners.keys.toList().forEach { image ->
                thumbnailAttachListeners.remove(image)?.let { try { image.removeOnAttachStateChangeListener(it) } catch (_: Exception) { } }
            }
        }
        thumbnailWaiters.clear()
        thumbnailPendingFiles.clear()
        synchronized(folderPreviewAttachListeners) {
            folderPreviewAttachListeners.keys.toList().forEach { owner ->
                folderPreviewAttachListeners.remove(owner)?.let { try { owner.removeOnAttachStateChangeListener(it) } catch (_: Exception) { } }
            }
        }
        thumbnailKeysInFlight.clear()
        try { thumbnailExecutor.shutdownNow() } catch (_: Exception) { }
        try { folderPreviewLoader.clear() } catch (_: Exception) { }
        LibraryIndex.removeListener(indexListener)
        if (isFinishing) {
            try { scanExecutor.shutdownNow() } catch (_: Exception) { }
            try { searchExecutor.shutdownNow() } catch (_: Exception) { }
        }
        searchGen.incrementAndGet()
        searchHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Deprecated("Compatibility with Android versions that use the legacy back callback")
    override fun onBackPressed() {
        if (selectedPaths.isNotEmpty()) clearSelection() else goParent()
    }

    companion object {
        private const val TYPE_FILE_ITEM = 1
        private const val TYPE_DATE_HEADER = 2
        private const val GRID_SELECTED_BADGE_TAG = "omnihub-grid-selection-badge"
        private const val FLAT_ROW_TAG = "omnihub-flat-row"
        private const val FLAT_CHECK_TAG = "omnihub-flat-check"
        private const val REQUEST_READ_STORAGE = 7201
        private const val MAX_SEARCH_RESULTS = 1500
        private val DOC_EXTS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "rtf", "epub", "txt", "csv", "md")
        private val ARCHIVE_EXTS = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "zst", "lzma", "ar", "cpio", "jar", "apk", "iso")
        private val SORT_LABELS = arrayOf("Name (A → Z)", "Name (Z → A)", "Date (newest first)", "Date (oldest first)", "Size (largest first)", "Size (smallest first)", "Type (A → Z)")
        private val SORT_SHORT = arrayOf("Name ↑", "Name ↓", "Newest", "Oldest", "Largest", "Smallest", "Type")
        private val DATE_LABELS = arrayOf("Any time", "Today", "Last 7 days", "Last 30 days", "This year")
    }
}


/** A grid cell whose measured height always follows its measured width. */
private class SquareFrameLayout(context: Context) : FrameLayout(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = View.MeasureSpec.getSize(widthMeasureSpec)
        super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY))
    }
}
