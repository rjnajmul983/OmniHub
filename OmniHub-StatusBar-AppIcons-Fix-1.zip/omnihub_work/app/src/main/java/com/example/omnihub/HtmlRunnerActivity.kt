package com.example.omnihub

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/** Runs user HTML/JS in a WebView with no native bridge and no file/content access. */
class HtmlRunnerActivity : Activity() {
    private lateinit var runner: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 16, 32)
        window.navigationBarColor = Color.rgb(11, 16, 32)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(11,16,32)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        val back = Button(this).apply { text = "‹ Back"; setOnClickListener { finish() } }
        val title = TextView(this).apply { text = "HTML Runner · Preview"; setTextColor(Color.WHITE); textSize = 16f; setPadding(dp(12), 0, 0, 0) }
        bar.addView(back)
        bar.addView(HomeNavigation.makeHomeButton(this), LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(4); rightMargin = dp(4) })
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        runner = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (android.os.Build.VERSION.SDK_INT >= 26) settings.safeBrowsingEnabled = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    // Links leave the runner rather than turning it into a general browser.
                    val scheme = request.url.scheme?.lowercase()
                    if (scheme == "http" || scheme == "https") {
                        startActivity(android.content.Intent(this@HtmlRunnerActivity, BrowserActivity::class.java).putExtra("url", request.url.toString()))
                    }
                    return true
                }
            }
        }
        root.addView(bar)
        root.addView(runner, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        InsetsUtil.apply(this, root)
        val path = intent.getStringExtra("html_path")
        val html = try { if (path != null) File(path).readText(Charsets.UTF_8) else "<h2>No HTML supplied</h2>" } catch (_: Exception) { "<h2>Could not load preview</h2>" }
        runner.loadDataWithBaseURL("https://omnihub-runner.invalid/", html, "text/html", "UTF-8", null)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Deprecated("Compatibility fallback")
    override fun onBackPressed() = finish()

    override fun onDestroy() {
        if (::runner.isInitialized) { runner.stopLoading(); runner.loadUrl("about:blank"); runner.destroy() }
        super.onDestroy()
    }
}
