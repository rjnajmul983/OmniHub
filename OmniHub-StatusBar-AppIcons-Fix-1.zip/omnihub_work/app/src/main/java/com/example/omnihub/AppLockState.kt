package com.example.omnihub

import java.util.concurrent.ConcurrentHashMap

/**
 * Process-wide App Lock session state (memory only, never saved to disk).
 *
 * A protected app stays unlocked until the screen turns off or the user dismisses it from Recents.
 * Switching to other apps, the keyboard, the fingerprint dialog or OmniHub itself never re-locks it.
 */
object AppLockState {
    private val unlocked = ConcurrentHashMap.newKeySet<String>()

    @Volatile private var grantPkg: String? = null
    @Volatile private var grantUntil: Long = 0L

    fun isUnlocked(pkg: String): Boolean = unlocked.contains(pkg)
    fun markUnlocked(pkg: String) { if (pkg.isNotBlank()) unlocked.add(pkg) }
    fun relock(pkg: String) { unlocked.remove(pkg) }
    fun anyUnlocked(): Boolean = unlocked.isNotEmpty()

    /** One-shot permission used when OmniHub itself starts a protected app right after a successful unlock. */
    fun grant(pkg: String, millis: Long = 6000L) {
        grantPkg = pkg
        grantUntil = System.currentTimeMillis() + millis
    }

    /** True once, only for the granted package and only while the grant has not expired. */
    @Synchronized
    fun consumeGrant(pkg: String): Boolean {
        val ok = grantPkg == pkg && System.currentTimeMillis() <= grantUntil
        if (ok) { grantPkg = null; grantUntil = 0L }
        return ok
    }

    fun relockAll() {
        unlocked.clear()
        grantPkg = null
        grantUntil = 0L
    }
}
