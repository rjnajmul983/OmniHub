package com.example.omnihub

import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationSet
import android.view.animation.LayoutAnimationController
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.view.animation.TranslateAnimation
import androidx.recyclerview.widget.RecyclerView

/** Shared motion language: quick start, long soft landing (Material "emphasized decelerate"). */
object Motion {
    val enter = PathInterpolator(0.2f, 0f, 0f, 1f)
    val exit = PathInterpolator(0.4f, 0f, 1f, 1f)

    private fun dp(v: View, n: Int) = n * v.resources.displayMetrics.density

    /** Springy press feedback that never steals clicks / long-clicks / scrolling. */
    fun press(view: View, scale: Float = 0.96f) {
        view.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(scale).scaleY(scale).setDuration(80).setInterpolator(enter).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(2.4f)).start()
            }
            false
        }
    }

    /** Slide-up + fade for bars (selection bar, paste bar). */
    fun toggle(v: View?, show: Boolean) {
        if (v == null) return
        if (show) {
            if (v.visibility != View.VISIBLE) { v.alpha = 0f; v.translationY = dp(v, 20); v.visibility = View.VISIBLE }
            v.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(enter).start()
        } else {
            if (v.visibility != View.VISIBLE) return
            v.animate().alpha(0f).translationY(dp(v, 14)).setDuration(170).setInterpolator(exit)
                .withEndAction { v.visibility = View.GONE; v.alpha = 1f; v.translationY = 0f }.start()
        }
    }

    /** Rows cascade in from the side we are navigating towards (+1 deeper / -1 back). */
    fun cascade(list: RecyclerView, direction: Int) {
        val set = AnimationSet(true).apply {
            addAnimation(TranslateAnimation(Animation.ABSOLUTE, direction * dp(list, 30), Animation.ABSOLUTE, 0f, Animation.ABSOLUTE, 0f, Animation.ABSOLUTE, 0f))
            addAnimation(AlphaAnimation(0f, 1f))
            duration = 260
            interpolator = enter
        }
        list.layoutAnimation = LayoutAnimationController(set, 0.035f)
        list.scheduleLayoutAnimation()
    }

    /** Checkbox / badge "pop". */
    fun pop(v: View) {
        v.scaleX = 0.5f; v.scaleY = 0.5f
        v.animate().scaleX(1f).scaleY(1f).setDuration(300).setInterpolator(OvershootInterpolator(3.2f)).start()
    }
}
