package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** App manager powered by Shizuku: force stop, clear data, disable / enable, uninstall, extract APK. */
class ShizukuAppsActivity : Activity() {
    private data class App(val label: String, val pkg: String, val system: Boolean, val enabled: Boolean)

    private val bg = Color.rgb(242, 240, 247)
    private val panel = Color.rgb(252, 251, 254)
    private val accent = Color.rgb(102, 80, 196)
    private val white = Color.rgb(37, 34, 47)
    private val muted = Color.rgb(94, 88, 112)
    private val ui = Handler(Looper.getMainLooper())

    private var all: List<App> = emptyList()
    private var shown: List<App> = emptyList()
    private var query = ""
    private var showSystem = false
    private lateinit var status: TextView
    private lateinit var setupButton: Button
    private lateinit var listView: ListView
    private val adapter = Rows()
    private val serviceListener: () -> Unit = { ui.post { updateStatus() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.rgb(252, 251, 254)
        if (android.os.Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(10), dp(8), dp(10), dp(8)) }
        root.addView(TextView(this).apply { text = "Installed apps"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white) })
        status = TextView(this).apply { setTextColor(white); textSize = 13f; background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.rgb(218, 213, 230)) }; setPadding(dp(12), dp(10), dp(12), dp(10)); visibility = View.GONE }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        setupButton = Button(this).apply {
            text = "Set up Shizuku"; isAllCaps = false; setTextColor(Color.WHITE); backgroundTintList = ColorStateList.valueOf(accent); visibility = View.GONE
            setOnClickListener { startActivity(Intent(this@ShizukuAppsActivity, ShizukuFileActivity::class.java)) }
        }
        root.addView(setupButton, LinearLayout.LayoutParams(-2, dp(44)).apply { topMargin = dp(6) })
        val search = EditText(this).apply {
            hint = "Search apps"; setSingleLine(true); setTextColor(white); setHintTextColor(muted); backgroundTintList = ColorStateList.valueOf(Color.rgb(214, 209, 226)); setPadding(dp(12), dp(7), dp(12), dp(7))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s?.toString().orEmpty().trim().lowercase(Locale.ROOT); applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(CheckBox(this).apply {
            text = "Show system apps"; setTextColor(white); isChecked = true; showSystem = true
            setOnCheckedChangeListener { _, checked -> showSystem = checked; applyFilter() }
        })
        listView = ListView(this).apply {
            setBackgroundColor(bg); divider = android.graphics.drawable.ColorDrawable(Color.rgb(218, 213, 230)); dividerHeight = dp(1); adapter = this@ShizukuAppsActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> showMenu(shown[pos]) }
        }
        root.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        InsetsUtil.apply(this, root)
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply {
                isAppearanceLightStatusBars = true
                isAppearanceLightNavigationBars = true
            }
        }
        ShizukuHelper.changeListeners.add(serviceListener)
        loadApps()
    }

    override fun onResume() { super.onResume(); updateStatus() }

    override fun onDestroy() { ShizukuHelper.changeListeners.remove(serviceListener); super.onDestroy() }

    private fun updateStatus() {
        val ok = ShizukuHelper.service != null
        if (!ok) ShizukuHelper.bind(this)
        status.visibility = if (ok) View.GONE else View.VISIBLE
        setupButton.visibility = if (ok) View.GONE else View.VISIBLE
        status.text = when {
            !ShizukuHelper.running() -> "Shizuku is not running. Start Shizuku, then open Set up Shizuku."
            !ShizukuHelper.permitted() -> "OmniHub needs Shizuku permission. Open Set up Shizuku and grant it."
            else -> "Connecting to Shizuku…"
        }
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val list = pm.getInstalledApplications(0).map {
                App(pm.getApplicationLabel(it).toString(), it.packageName, (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0, it.enabled)
            }.sortedBy { it.label.lowercase(Locale.ROOT) }
            ui.post { all = list; applyFilter() }
        }.start()
    }

    private fun applyFilter() {
        shown = all.filter { (showSystem || !it.system) && (query.isEmpty() || it.label.lowercase(Locale.ROOT).contains(query) || it.pkg.contains(query)) }
        adapter.notifyDataSetChanged()
    }

    private fun showMenu(app: App) {
        val items = arrayOf("Force stop", "Clear app data", "Clear external cache", if (app.enabled) "Disable app" else "Enable app", "Uninstall", "Extract APK to Download", "Open Android/data folder", "App info")
        AlertDialog.Builder(this).setTitle("${app.label}\n${app.pkg}").setItems(items) { _, w ->
            val q = ShizukuHelper.quote(app.pkg)
            val ext = Environment.getExternalStorageDirectory().absolutePath
            when (w) {
                0 -> run("Force stop", "am force-stop $q")
                1 -> confirm("Delete ALL data of ${app.label}?") { run("Clear data", "pm clear $q") }
                2 -> run("Clear cache", "rm -rf ${ShizukuHelper.quote("$ext/Android/data/${app.pkg}/cache")}")
                3 -> run(if (app.enabled) "Disable" else "Enable", if (app.enabled) "pm disable-user --user 0 $q" else "pm enable $q") { loadApps() }
                4 -> confirm("Uninstall ${app.label}?") { run("Uninstall", if (app.system) "pm uninstall --user 0 $q" else "pm uninstall $q") { loadApps() } }
                5 -> run("Extract APK", "p=\$(pm path $q | head -n1 | cut -d: -f2); cp \"\$p\" ${ShizukuHelper.quote("$ext/Download/${app.pkg}.apk")} && echo \"Saved to Download/${app.pkg}.apk\"")
                6 -> startActivity(Intent(this, ShizukuFileActivity::class.java).putExtra("path", "$ext/Android/data/${app.pkg}"))
                7 -> try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))) } catch (_: Exception) { }
            }
        }.show()
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Yes") { _, _ -> yes() }.setNegativeButton("Cancel", null).show()
    }

    private fun run(title: String, cmd: String, after: (() -> Unit)? = null) {
        if (ShizukuHelper.service == null) { Toast.makeText(this, "Shizuku is not connected", Toast.LENGTH_LONG).show(); updateStatus(); return }
        Thread {
            val msg = try { val r = ShizukuHelper.exec(cmd); r.second.trim().ifBlank { if (r.first == 0) "$title: done" else "$title: failed (${r.first})" } } catch (t: Throwable) { t.message ?: "error" }
            ui.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); after?.invoke() }
        }.start()
    }

    private inner class Rows : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val a = shown[position]
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@ShizukuAppsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(Color.rgb(252, 251, 254))
                val icon = ImageView(context).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }
                addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(12) })
                val texts = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(context).apply {
                        setTextColor(white)
                        textSize = 14f
                        typeface = Typeface.DEFAULT_BOLD
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    })
                    addView(TextView(context).apply {
                        setTextColor(muted)
                        textSize = 11f
                        setPadding(0, dp(2), 0, 0)
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    })
                }
                addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            }
            val iconView = row.getChildAt(0) as ImageView
            val texts = row.getChildAt(1) as LinearLayout
            (texts.getChildAt(0) as TextView).text = a.label
            (texts.getChildAt(1) as TextView).text = a.pkg + (if (a.system) "  · system" else "") + (if (!a.enabled) "  · disabled" else "")
            try {
                iconView.setImageDrawable(packageManager.getApplicationIcon(a.pkg))
            } catch (_: Exception) {
                iconView.setImageResource(android.R.drawable.sym_def_app_icon)
            }
            return row
        }
    }
}
