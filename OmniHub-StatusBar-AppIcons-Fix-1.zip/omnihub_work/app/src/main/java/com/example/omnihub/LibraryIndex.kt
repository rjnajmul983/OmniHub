package com.example.omnihub

import android.content.Context
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicInteger

/**
 * Process-wide library index that is built in the background as soon as the app starts.
 *
 * Stage 1: the saved index from the previous run is read from disk (instant).
 * Stage 2: MediaStore is queried for every image / audio / video (about a second on a big phone).
 * Stage 3: the whole shared storage is walked by several threads at once, which also catches
 *          documents, code files and anything MediaStore does not know about.
 *
 * FileManagerActivity simply reads the in-memory lists, so opening Images / Audio / Videos / New files
 * no longer waits for a scan.
 */
object LibraryIndex {
    interface Listener { fun onIndexUpdated() }

    private const val MAX_FILES = 100_000
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile private var media: List<File> = emptyList()
    @Volatile private var text: List<File> = emptyList()
    @Volatile private var recent: List<File> = emptyList()
    @Volatile var ready = false; private set
    @Volatile var scanning = false; private set
    @Volatile private var lastScanMs = 0L

    private val workers = Executors.newFixedThreadPool(
        Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
    ) { r -> Thread(r, "OmniHub-Index").apply { isDaemon = true; priority = Thread.NORM_PRIORITY - 1 } }
    private val coordinator = Executors.newSingleThreadExecutor { r -> Thread(r, "OmniHub-IndexMain").apply { isDaemon = true } }

    fun list(mode: String): List<File> = when (mode) {
        "media" -> media
        "text" -> text
        else -> recent
    }

    fun addListener(l: Listener) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }

    private fun notifyChanged() {
        main.post { listeners.forEach { try { it.onIndexUpdated() } catch (_: Throwable) { } } }
    }

    /** Starts a background refresh unless one is running (or a fresh one finished recently). */
    fun warmUp(ctx: Context, force: Boolean) {
        val app = ctx.applicationContext
        if (!MediaCatalog.hasAccess(app)) return
        synchronized(this) {
            if (scanning) return
            if (!force && ready && System.currentTimeMillis() - lastScanMs < 90_000L) return
            scanning = true
        }
        try {
            coordinator.execute {
                try { runScan(app) } catch (_: Throwable) { }
                finally {
                    lastScanMs = System.currentTimeMillis()
                    scanning = false
                    notifyChanged()
                }
            }
        } catch (_: Throwable) { scanning = false }
    }

    // ------------------------------------------------------------------ scanning

    private fun cacheDir(app: Context) = File(app.filesDir, "omnihub_media_index_v4")
    private fun cacheFile(app: Context, mode: String) = File(cacheDir(app), "${mode}_paths_v4.txt")

    private fun runScan(app: Context) {
        // Stage 1 – last run's index from disk.
        if (!ready) {
            val m = readCache(cacheFile(app, "media"))
            val t = readCache(cacheFile(app, "text"))
            val r = readCache(cacheFile(app, "recent"))
            if (m.isNotEmpty() || t.isNotEmpty() || r.isNotEmpty()) {
                media = m; text = t; recent = r
                ready = true
                notifyChanged()
            }
        }
        // Stage 2 – MediaStore: every image / audio / video in a single fast query.
        val quick = queryMediaStore(app)
        if (quick.isNotEmpty()) {
            media = quick
            if (!ready) { ready = true }
            notifyChanged()
        }
        // Stage 3 – parallel walk of the whole shared storage.
        val allMedia = ArrayList<File>()
        val allText = ArrayList<File>()
        val allRecent = ArrayList<File>()
        walkStorage(allMedia, allText, allRecent)
        if (allRecent.isEmpty() && allMedia.isEmpty() && allText.isEmpty()) return // storage unreadable; keep what we have
        allRecent.sortByDescending { it.lastModified() }
        media = allMedia
        text = allText
        recent = allRecent
        ready = true
        notifyChanged()
        writeCache(app, "media", allMedia)
        writeCache(app, "text", allText)
        writeCache(app, "recent", allRecent)
    }

    private fun readCache(f: File): List<File> {
        val out = ArrayList<File>()
        try {
            if (!f.isFile) return out
            BufferedReader(InputStreamReader(FileInputStream(f), Charsets.UTF_8), 64 * 1024).use { r ->
                while (out.size < MAX_FILES) {
                    val line = r.readLine() ?: break
                    if (line.isNotEmpty() && wanted(line)) out.add(File(line))
                }
            }
        } catch (_: Throwable) { try { f.delete() } catch (_: Throwable) { } }
        return out
    }

    private fun writeCache(app: Context, mode: String, files: List<File>) {
        try {
            val dir = cacheDir(app)
            if (!dir.exists()) dir.mkdirs()
            val target = cacheFile(app, mode)
            val tmp = File(dir, target.name + ".tmp")
            BufferedWriter(OutputStreamWriter(FileOutputStream(tmp, false), Charsets.UTF_8), 64 * 1024).use { w ->
                for (f in files) { w.write(f.absolutePath); w.newLine() }
            }
            if (!tmp.renameTo(target)) { target.delete(); if (!tmp.renameTo(target)) { tmp.copyTo(target, true); tmp.delete() } }
        } catch (_: Throwable) { }
    }

    /** Libraries never list anything inside the Android folder (data, obb, media...) or any hidden (dot) folder/file. */
    // ---- "junk" media filter: app icons, UI assets, thumbnails, stickers and tiny clips never reach the libraries ----
    private const val MIN_IMAGE_BYTES = 30L * 1024          // below this a picture is an icon / chat thumbnail, not a photo
    private const val MIN_IMAGE_SIDE_PX = 200               // MediaStore only: shorter side under 200px = icon / sprite
    private const val MIN_VIDEO_BYTES = 150L * 1024         // below this a video is a sticker / 1-second loop
    private val JUNK_DIR_PARTS = listOf(
        "/res/", "/mipmap", "/drawable", "/build/", "/node_modules/", "/.git/",
        "/thumbnails/", "/thumbnail/", "/thumbs/", "/.thumbnails/", "/cache/", "/.cache/",
        "/stickers/", "/sticker/", "/whatsapp stickers/", "/emoji/", "/emojis/", "/avatars/", "/lost.dir/",
        "/assets/", "/webview/", "/sprites/", "/icons/", "/icon/"
    )
    private val JUNK_IMAGE_EXTS = setOf("ico", "svg", "wbmp", "dng")

    /** True when a media file is clutter. [size] <= 0 means unknown (no size rule applied). */
    private fun isJunkMedia(path: String, ext: String, size: Long, w: Int = 0, h: Int = 0): Boolean {
        val lower = path.lowercase(Locale.ROOT)
        for (part in JUNK_DIR_PARTS) if (lower.contains(part)) return true
        val name = lower.substringAfterLast('/')
        if (ext in MediaKinds.image) {
            if (ext in JUNK_IMAGE_EXTS) return true
            if (name.startsWith("ic_") || name.startsWith("icon") || name.startsWith("sticker") || name.contains("_thumb") || name.startsWith("thumb")) return true
            if (size in 1 until MIN_IMAGE_BYTES) return true
            if (w > 0 && h > 0 && minOf(w, h) < MIN_IMAGE_SIDE_PX) return true
        } else if (ext in MediaKinds.video) {
            if (size in 1 until MIN_VIDEO_BYTES) return true
        }
        return false
    }

    private fun wanted(path: String): Boolean =
        !path.contains("/.") && !path.contains("/Android/")

    @Suppress("DEPRECATION")
    private fun queryMediaStore(app: Context): List<File> {
        val out = ArrayList<File>()
        try {
            val uri = MediaStore.Files.getContentUri("external")
            val sel = MediaStore.Files.FileColumns.MEDIA_TYPE + " IN (" +
                MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE + "," +
                MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO + "," +
                MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO + ")"
            val cols = arrayOf(MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT)
            app.contentResolver.query(uri, cols, sel, null, MediaStore.MediaColumns.DATE_MODIFIED + " DESC")?.use { c ->
                val i = c.getColumnIndex(MediaStore.MediaColumns.DATA)
                val si = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
                val wi = c.getColumnIndex(MediaStore.MediaColumns.WIDTH)
                val hi = c.getColumnIndex(MediaStore.MediaColumns.HEIGHT)
                if (i < 0) return out
                while (c.moveToNext() && out.size < MAX_FILES) {
                    val p = c.getString(i) ?: continue
                    if (!wanted(p)) continue
                    val ext = p.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    val size = if (si >= 0) c.getLong(si) else 0L
                    val w = if (wi >= 0) c.getInt(wi) else 0
                    val h = if (hi >= 0) c.getInt(hi) else 0
                    if (isJunkMedia(p, ext, size, w, h)) continue
                    out.add(File(p))
                }
            }
        } catch (_: Throwable) { }
        return out
    }

    private fun classify(file: File, media: MutableList<File>, text: MutableList<File>, recent: MutableList<File>, recentCount: AtomicInteger) {
        val name = file.name
        if (name.startsWith(".")) return
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if ((ext in MediaKinds.video || ext in MediaKinds.audio || ext in MediaKinds.image) && media.size < MAX_FILES) {
            val junk = (ext in MediaKinds.image || ext in MediaKinds.video) && isJunkMedia(file.absolutePath, ext, file.length())
            if (!junk) media.add(file)
        }
        if (ext in TEXT_EXTS && text.size < MAX_FILES) text.add(file)
        if (recentCount.get() < MAX_FILES) { recent.add(file); recentCount.incrementAndGet() }
    }

    private fun walkStorage(outMedia: MutableList<File>, outText: MutableList<File>, outRecent: MutableList<File>) {
        val base = Environment.getExternalStorageDirectory()
        val recentCount = AtomicInteger(0)
        val rootMedia = ArrayList<File>(); val rootText = ArrayList<File>(); val rootRecent = ArrayList<File>()
        val tasks = ArrayList<File>()

        fun skipDir(dir: File): Boolean {
            val n = dir.name
            if (n.startsWith(".")) return true
            val rel = try { dir.relativeTo(base).path.replace('\\', '/') } catch (_: Exception) { "" }
            return rel == "Android" || rel.startsWith("Android/")
        }

        // Levels 0 and 1 are handled here; every directory at level 2 becomes its own parallel task.
        fun expand(dir: File, depth: Int) {
            val kids = try { dir.listFiles() } catch (_: Throwable) { null } ?: return
            for (k in kids) {
                try {
                    if (k.isDirectory) {
                        if (skipDir(k)) continue
                        if (depth >= 1) tasks.add(k) else expand(k, depth + 1)
                    } else classify(k, rootMedia, rootText, rootRecent, recentCount)
                } catch (_: Throwable) { }
            }
        }
        expand(base, 0)

        val futures = ArrayList<Future<Triple<List<File>, List<File>, List<File>>>>()
        for (dir in tasks) {
            futures.add(workers.submit<Triple<List<File>, List<File>, List<File>>> {
                val m = ArrayList<File>(); val t = ArrayList<File>(); val r = ArrayList<File>()
                val stack = ArrayDeque<File>()
                stack.addLast(dir)
                while (stack.isNotEmpty()) {
                    val d = stack.removeLast()
                    val kids = try { d.listFiles() } catch (_: Throwable) { null } ?: continue
                    for (k in kids) {
                        try {
                            if (k.isDirectory) { if (!skipDir(k)) stack.addLast(k) }
                            else classify(k, m, t, r, recentCount)
                        } catch (_: Throwable) { }
                    }
                }
                Triple(m, t, r)
            })
        }
        outMedia.addAll(rootMedia); outText.addAll(rootText); outRecent.addAll(rootRecent)
        for (f in futures) {
            try {
                val (m, t, r) = f.get()
                if (outMedia.size < MAX_FILES) outMedia.addAll(m)
                if (outText.size < MAX_FILES) outText.addAll(t)
                if (outRecent.size < MAX_FILES) outRecent.addAll(r)
            } catch (_: Throwable) { }
        }
    }

    private val TEXT_EXTS = setOf(
        "txt", "html", "htm", "css", "js", "mjs", "json", "xml", "csv", "md", "markdown", "yaml", "yml",
        "log", "ini", "kt", "java", "py", "c", "h", "cpp", "sh", "sql", "svg", "gradle", "properties",
        "ts", "tsx", "jsx", "php", "rb", "go", "rs", "toml", "xmls"
    )
}
