package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.os.Looper
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.CheckBox
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Toast
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Small, reusable archive dialogs. Heavy archive work must never run on the main thread. */
object ArchiveDialogs {
    data class PasswordAnswer(val password: String?, val cancelled: Boolean = false)

    fun requestPassword(context: Context, attempt: Int, onAnswer: (PasswordAnswer) -> Unit) {
        val input = EditText(context).apply {
            hint = context.getString(R.string.archive_password_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        val message = if (attempt > 1) "${context.getString(R.string.archive_password_wrong)} (${attempt}/3)" else context.getString(R.string.archive_password_message)
        AlertDialog.Builder(context)
            .setTitle(context.getString(R.string.archive_password_title))
            .setMessage(message)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ -> onAnswer(PasswordAnswer(input.text?.toString().orEmpty())) }
            .setNegativeButton(context.getString(R.string.action_cancel)) { _, _ -> onAnswer(PasswordAnswer(null, true)) }
            .setOnCancelListener { onAnswer(PasswordAnswer(null, true)) }
            .show()
        input.requestFocus()
    }

    enum class Choice { MERGE, REPLACE, KEEP_BOTH, SKIP, CANCEL }
    data class ConflictAnswer(val choice: Choice, val applyToAll: Boolean)

    /** Stacked-button conflict dialog (UI thread). Back / outside tap counts as Cancel. */
    fun showChoiceDialog(
        activity: Activity, message: String, detail: String?, applyAllLabel: String?,
        options: List<Pair<String, Choice>>, onAnswer: (ConflictAnswer) -> Unit
    ) {
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 22), dp(activity, 20), dp(activity, 22), dp(activity, 14))
        }
        box.addView(TextView(activity).apply { text = message; textSize = 17f; setTextColor(android.graphics.Color.rgb(37, 34, 47)) })
        if (!detail.isNullOrBlank()) box.addView(TextView(activity).apply {
            text = detail; textSize = 12f; setTextColor(android.graphics.Color.GRAY); setPadding(0, dp(activity, 6), 0, 0)
        })
        val all = applyAllLabel?.let { CheckBox(activity).apply { text = it; minHeight = dp(activity, 48) } }
        if (all != null) box.addView(all, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(activity, 8) })
        val dialog = AlertDialog.Builder(activity).setView(box).create()
        dialog.setCanceledOnTouchOutside(false)
        var answered = false
        fun answer(c: Choice) {
            if (answered) return
            answered = true
            val a = ConflictAnswer(c, all?.isChecked == true && c != Choice.CANCEL)
            try { dialog.dismiss() } catch (_: Exception) { }
            onAnswer(a)
        }
        options.forEach { (label, choice) ->
            val cancel = choice == Choice.CANCEL
            val button = Button(activity).apply {
                text = label
                setTextColor(if (cancel) android.graphics.Color.rgb(37, 34, 47) else android.graphics.Color.WHITE)
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(activity, 6).toFloat()
                    setColor(if (cancel) android.graphics.Color.rgb(214, 209, 226) else android.graphics.Color.rgb(80, 102, 245))
                }
                setOnClickListener { answer(choice) }
            }
            box.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 48)).apply { topMargin = dp(activity, 10) })
        }
        dialog.setOnCancelListener { answer(Choice.CANCEL) }
        dialog.show()
    }

    /**
     * Asks what to do about an item that already exists. Folders: Merge / Skip / Cancel. Files: Replace / Keep both / Skip / Cancel.
     * Call from a worker thread; blocks until the user answers.
     */
    fun askConflict(activity: Activity, existing: File, incomingIsDir: Boolean, incomingSize: Long, allowReplace: Boolean = true): ConflictAnswer {
        if (Looper.myLooper() == Looper.getMainLooper() || activity.isFinishing || activity.isDestroyed) {
            return ConflictAnswer(if (incomingIsDir) Choice.MERGE else Choice.KEEP_BOTH, false)
        }
        val latch = CountDownLatch(1)
        val result = AtomicReference(ConflictAnswer(Choice.CANCEL, false))
        activity.runOnUiThread {
            if (activity.isFinishing || activity.isDestroyed) { latch.countDown(); return@runOnUiThread }
            val cancel = activity.getString(R.string.action_cancel) to Choice.CANCEL
            val skip = activity.getString(R.string.archive_conflict_skip) to Choice.SKIP
            if (incomingIsDir) {
                showChoiceDialog(activity, activity.getString(R.string.conflict_folder_msg, existing.name), null,
                    activity.getString(R.string.conflict_apply_folders),
                    listOf(activity.getString(R.string.conflict_merge) to Choice.MERGE, skip, cancel)) { result.set(it); latch.countDown() }
            } else {
                val fmt = { n: Long -> android.text.format.Formatter.formatShortFileSize(activity, n) }
                val detail = if (incomingSize >= 0 && existing.isFile) activity.getString(R.string.conflict_file_detail, fmt(existing.length()), fmt(incomingSize)) else null
                val options = mutableListOf<Pair<String, Choice>>()
                if (allowReplace) options += activity.getString(R.string.archive_conflict_replace) to Choice.REPLACE
                options += activity.getString(R.string.archive_conflict_keep_both) to Choice.KEEP_BOTH
                options += skip; options += cancel
                showChoiceDialog(activity, activity.getString(R.string.conflict_file_msg, existing.name), detail,
                    activity.getString(R.string.conflict_apply_files), options) { result.set(it); latch.countDown() }
            }
        }
        try {
            while (!latch.await(1, TimeUnit.SECONDS)) {
                if (activity.isFinishing || activity.isDestroyed) return ConflictAnswer(Choice.CANCEL, false)
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            return ConflictAnswer(Choice.CANCEL, false)
        }
        return result.get()
    }

    /** Invoke this resolver only from a worker thread; it synchronously asks the UI for the conflict policy. */
    fun conflictResolver(activity: Activity): (File, ArchiveManager.Entry) -> ArchiveManager.ConflictDecision = { existing, incoming ->
        val ans = askConflict(activity, existing, incoming.isDirectory, incoming.size, allowReplace = existing.isFile)
        val all = ans.applyToAll
        when (ans.choice) {
            Choice.CANCEL -> ArchiveManager.ConflictDecision(ArchiveManager.ConflictAction.SKIP, cancelled = true)
            Choice.MERGE -> ArchiveManager.ConflictDecision(ArchiveManager.ConflictAction.KEEP_BOTH, all, merge = true)
            Choice.REPLACE -> ArchiveManager.ConflictDecision(ArchiveManager.ConflictAction.REPLACE, all)
            Choice.KEEP_BOTH -> ArchiveManager.ConflictDecision(ArchiveManager.ConflictAction.KEEP_BOTH, all)
            Choice.SKIP -> ArchiveManager.ConflictDecision(ArchiveManager.ConflictAction.SKIP, all)
        }
    }

    /**
     * On-screen progress for a background ArchiveService job. "Hide" closes the dialog and leaves
     * the job running in the notification panel; "Cancel" stops the job.
     */
    fun showServiceProgress(activity: Activity) {
        val layout = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 24), dp(activity, 10), dp(activity, 24), dp(activity, 6))
        }
        val label = TextView(activity).apply { text = activity.getString(R.string.archive_starting) }
        val percent = TextView(activity).apply { text = "0%"; gravity = android.view.Gravity.END }
        val bar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = true }
        layout.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 8)).apply { topMargin = dp(activity, 14) })
        layout.addView(percent, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(activity, 6) })

        val dialog = AlertDialog.Builder(activity)
            .setTitle(R.string.archive_progress_title)
            .setView(layout)
            .setNeutralButton(R.string.archive_hide, null)
            .setNegativeButton(R.string.archive_cancel, null)
            .create()
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)

        lateinit var myListener: (ArchiveService.Companion.State) -> Unit
        fun detach() { if (ArchiveService.listener === myListener) ArchiveService.listener = null }
        myListener = { st ->
            if (activity.isFinishing || activity.isDestroyed) detach()
            else if (st.running) {
                label.text = st.message
                if (st.percent > 0) { bar.isIndeterminate = false; bar.progress = st.percent }
                percent.text = "${st.percent}%"
            } else {
                detach()
                try { dialog.dismiss() } catch (_: Exception) { }
                Toast.makeText(activity, st.message, Toast.LENGTH_LONG).show()
                (activity as? FileManagerActivity)?.onArchiveJobFinished()
            }
        }
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
                detach(); dialog.dismiss()
                Toast.makeText(activity, R.string.archive_hidden_notification, Toast.LENGTH_SHORT).show()
            }
            dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener {
                label.text = activity.getString(R.string.archive_cancel_requested)
                try { activity.startService(android.content.Intent(activity, ArchiveService::class.java).setAction(ArchiveService.ACTION_CANCEL)) } catch (_: Exception) { }
            }
        }
        dialog.setOnDismissListener { detach() }
        ArchiveService.listener = myListener
        dialog.show()
    }

    /** Progress dialog helper for light jobs. Use ArchiveService for larger or long-running operations. */
    fun <T> runWithProgress(
        activity: Activity,
        title: String,
        work: (ArchiveManager.CancelToken, (ArchiveManager.Progress) -> Unit) -> T,
        onDone: (value: T?, error: Throwable?) -> Unit
    ) {
        val token = ArchiveManager.CancelToken()
        val layout = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 24), dp(activity, 10), dp(activity, 24), dp(activity, 6))
        }
        val label = TextView(activity).apply { text = title; contentDescription = title }
        val progress = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = true }
        layout.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 8)).apply { topMargin = dp(activity, 14) })
        val dialog = AlertDialog.Builder(activity)
            .setTitle(R.string.archive_progress_title)
            .setView(layout)
            .setNegativeButton(R.string.archive_cancel, null)
            .create()
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnShowListener { dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener { token.cancel(); label.text = activity.getString(R.string.archive_cancel_requested) } }
        dialog.show()
        Thread({
            var value: T? = null
            var error: Throwable? = null
            try {
                value = work(token) { p ->
                    activity.runOnUiThread {
                        val total = p.totalBytes
                        if (total > 0) { progress.isIndeterminate = false; progress.progress = ((p.completedBytes * 100) / total).toInt().coerceIn(0, 100) }
                        label.text = p.currentEntry.ifBlank { title }
                    }
                }
            } catch (t: Throwable) { error = t }
            activity.runOnUiThread {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    dialog.dismiss()
                    onDone(value, error)
                }
            }
        }, "OmniHub-ArchiveDialogWorker").apply { isDaemon = true; start() }
    }



    /** Folder name used by "Extract to <name>/": the archive name without its extension (".tar.gz" etc. included). */
    fun namedFolderFor(activity: Activity, archive: File): String {
        var n = archive.name
        n = n.substringBeforeLast('.', n)
        if (n.endsWith(".tar", ignoreCase = true)) n = n.dropLast(4)
        return safeName(n.ifBlank { activity.getString(R.string.archive_extract_folder_default) })
    }

    /** Extracts straight into a new folder named after the archive, next to it. */
    fun extractToNamedFolder(activity: Activity, archive: File, destination: File = archive.parentFile ?: activity.filesDir) {
        loadEntries(activity, archive, attempt = 0, password = null) { password, entries, error ->
            if (activity.isFinishing || activity.isDestroyed) return@loadEntries
            if (entries == null) { attemptOrMessage(activity, archive, destination, error); return@loadEntries }
            runExtract(activity, archive, File(destination, namedFolderFor(activity, archive)), password)
        }
    }

    /** APK files get a compact action sheet first; their internal entries are shown only on request. */
    fun showArchivePreview(
        activity: Activity,
        archive: File,
        destination: File = archive.parentFile ?: activity.filesDir,
        showApkActions: Boolean = true
    ) {
        // One tap shows every action at once (no intermediate "Extract / View data" dialog, no long entry list to scroll past).
        val isApk = archive.isFile && archive.extension.equals("apk", ignoreCase = true)
        loadEntries(activity, archive, attempt = 0, password = null) { password, entries, error ->
            if (activity.isFinishing || activity.isDestroyed) return@loadEntries
            if (entries == null) {
                if (attemptOrMessage(activity, archive, destination, error)) return@loadEntries
                return@loadEntries
            }
            showArchiveExplorer(activity, archive, entries, password, destination, isApk)
        }
    }

    /**
     * Installs an APK. On Android 8+ the user must first allow "Install unknown apps" for OmniHub;
     * when it is not allowed yet we explain it and jump straight to that Settings page, then continue
     * the installation automatically when the user comes back.
     */
    fun installApk(activity: Activity, apk: File) {
        if (!apk.isFile) {
            Toast.makeText(activity, "APK file not found", Toast.LENGTH_LONG).show()
            return
        }
        val allowed = try {
            android.os.Build.VERSION.SDK_INT < 26 || activity.packageManager.canRequestPackageInstalls()
        } catch (_: Throwable) { true }
        if (allowed) { startInstall(activity, apk); return }
        AlertDialog.Builder(activity)
            .setTitle("Allow app installs")
            .setMessage("To install this APK, Android needs your permission for OmniHub.\n\nTap \"Open settings\", turn on \"Allow from this source\", then press Back. The installation will continue automatically.")
            .setPositiveButton("Open settings") { _, _ -> openUnknownSourcesSettings(activity, apk) }
            .setNegativeButton(R.string.action_cancel, null)
            .show()
    }

    private fun openUnknownSourcesSettings(activity: Activity, apk: File) {
        val app = activity.application
        val callbacks = object : android.app.Application.ActivityLifecycleCallbacks {
            private var leftToSettings = false
            override fun onActivityPaused(a: Activity) { if (a === activity) leftToSettings = true }
            override fun onActivityResumed(a: Activity) {
                if (a !== activity || !leftToSettings) return
                app.unregisterActivityLifecycleCallbacks(this)
                val ok = try { activity.packageManager.canRequestPackageInstalls() } catch (_: Throwable) { false }
                if (ok) startInstall(activity, apk)
                else Toast.makeText(activity, "Install permission was not granted", Toast.LENGTH_LONG).show()
            }
            override fun onActivityCreated(a: Activity, b: android.os.Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: android.os.Bundle) {}
            override fun onActivityDestroyed(a: Activity) { if (a === activity) app.unregisterActivityLifecycleCallbacks(this) }
        }
        app.registerActivityLifecycleCallbacks(callbacks)
        try {
            activity.startActivity(
                android.content.Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, android.net.Uri.parse("package:" + activity.packageName))
            )
        } catch (_: Exception) {
            try {
                activity.startActivity(android.content.Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS))
            } catch (_: Exception) {
                app.unregisterActivityLifecycleCallbacks(callbacks)
                Toast.makeText(activity, "Could not open the install permission settings", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startInstall(activity: Activity, apk: File) {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                activity,
                activity.packageName + ".fileprovider",
                apk
            )
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                putExtra(android.content.Intent.EXTRA_NOT_UNKNOWN_SOURCE, true)
            }
            activity.startActivity(intent)
        } catch (e: android.content.ActivityNotFoundException) {
            Toast.makeText(activity, "No package installer is available on this device.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(activity, "Could not start APK installer: ${e.localizedMessage ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadEntries(
        activity: Activity,
        archive: File,
        attempt: Int,
        password: String?,
        callback: (String?, List<ArchiveManager.Entry>?, Throwable?) -> Unit
    ) {
        Thread({
            try {
                val result = ArchiveManager.listEntries(archive, password)
                activity.runOnUiThread { callback(password, result, null) }
            } catch (t: Throwable) {
                activity.runOnUiThread {
                    val message = generateSequence(t as Throwable?) { it.cause }.mapNotNull { it.message }.joinToString(" ").lowercase()
                    val passwordFailure = listOf("password", "decrypt", "encrypted", "aes", "authentication", "wrong pass", "crypt").any { message.contains(it) }
                    if (passwordFailure && attempt < 3 && !activity.isFinishing && !activity.isDestroyed) {
                        requestPassword(activity, attempt + 1) { answer ->
                            if (answer.cancelled) callback(null, null, t)
                            else loadEntries(activity, archive, attempt + 1, answer.password, callback)
                        }
                    } else callback(password, null, t)
                }
            }
        }, "OmniHub-ArchiveListing").apply { isDaemon = true; start() }
    }

    private fun attemptOrMessage(activity: Activity, archive: File, destination: File, error: Throwable?): Boolean {
        AlertDialog.Builder(activity)
            .setTitle(R.string.archive_failed_title)
            .setMessage(error?.localizedMessage ?: activity.getString(R.string.archive_failed_generic))
            .setPositiveButton(android.R.string.ok, null).show()
        return false
    }

    // ---------------------------------------------------------------------------------------------
    // Archive explorer: shows the inside of any archive (zip/apk/rar/7z/tar...) as a normal folder
    // tree - folders first, tap a folder to enter it, Back goes up one level - instead of a flat
    // paged list of full paths.
    // ---------------------------------------------------------------------------------------------
    private class ArcNode(val name: String, val path: String, var isDir: Boolean, var size: Long = -1L) {
        val children = linkedMapOf<String, ArcNode>()
        var parent: ArcNode? = null
        var cachedTotal: Long = -2L
    }

    private fun buildArchiveTree(entries: List<ArchiveManager.Entry>): ArcNode {
        val root = ArcNode("", "", true)
        for (e in entries) {
            val parts = e.name.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
            if (parts.isEmpty()) continue
            var cur = root
            for ((i, part) in parts.withIndex()) {
                val last = i == parts.lastIndex
                var child = cur.children[part]
                if (child == null) {
                    child = ArcNode(part, parts.take(i + 1).joinToString("/"), !last || e.isDirectory)
                    child.parent = cur
                    cur.children[part] = child
                }
                if (last) {
                    if (e.isDirectory) child.isDir = true
                    else if (child.children.isEmpty()) { child.isDir = false; child.size = e.size }
                }
                cur = child
            }
        }
        return root
    }

    private fun arcTotalSize(n: ArcNode): Long {
        if (!n.isDir) return n.size.coerceAtLeast(0L)
        if (n.cachedTotal >= -1L) return n.cachedTotal
        var t = 0L
        n.children.values.forEach { t += arcTotalSize(it) }
        n.cachedTotal = t
        return t
    }

    private fun arcIcon(n: ArcNode): String {
        if (n.isDir) return "📁"
        return when (n.name.substringAfterLast('.', "").lowercase(java.util.Locale.ROOT)) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "ico" -> "🖼"
            "mp4", "mkv", "avi", "mov", "webm", "3gp" -> "🎞"
            "mp3", "wav", "ogg", "flac", "m4a", "aac" -> "🎵"
            "apk" -> "🤖"
            "zip", "rar", "7z", "tar", "gz", "jar" -> "🗜"
            "dex", "so", "arsc", "bin" -> "⚙"
            else -> "📄"
        }
    }

    private fun showArchiveExplorer(
        activity: Activity,
        archive: File,
        entries: List<ArchiveManager.Entry>,
        password: String?,
        destination: File,
        isApk: Boolean
    ) {
        // Always the File Manager's light look (white + soft indigo), independent of the phone's dark mode.
        val bg = android.graphics.Color.rgb(242, 240, 247)
        val panel = android.graphics.Color.rgb(252, 251, 254)
        val fg = android.graphics.Color.rgb(37, 34, 47)
        val sub = android.graphics.Color.rgb(94, 88, 112)
        val accent = android.graphics.Color.rgb(102, 80, 196)
        val accentSoft = android.graphics.Color.rgb(230, 225, 247)
        val danger = android.graphics.Color.rgb(194, 79, 91)
        val line = android.graphics.Color.rgb(218, 213, 230)

        var root = buildArchiveTree(entries)
        var current = root
        val selected = linkedSetOf<String>()
        var items: List<ArcNode> = emptyList()
        var totalEntries = entries.size

        val dialog = android.app.Dialog(activity, android.R.style.Theme_Material_Light_NoActionBar)
        val page = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }

        fun tap(tv: TextView, color: Int = accent) = tv.apply {
            isClickable = true; isFocusable = true
            background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(android.graphics.Color.argb(40, android.graphics.Color.red(color), android.graphics.Color.green(color), android.graphics.Color.blue(color))),
                null, android.graphics.drawable.ColorDrawable(android.graphics.Color.rgb(252, 251, 254)))
        }

        // ---- top bar
        val topBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(activity, 4), 0, dp(activity, 4), 0)
        }
        val backBtn = tap(TextView(activity).apply {
            text = "←"; textSize = 22f; setTextColor(fg); gravity = android.view.Gravity.CENTER; contentDescription = "Back"
        })
        val titleBox = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val titleView = TextView(activity).apply {
            text = archive.name; textSize = 17f; setTextColor(fg); setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }
        val subtitleView = TextView(activity).apply { textSize = 12f; setTextColor(sub); setSingleLine(true) }
        fun updateSubtitle() { subtitleView.text = activity.getString(R.string.archive_preview_summary, totalEntries, formatBytes(archive.length())) }
        titleBox.addView(titleView); titleBox.addView(subtitleView)
        val moreBtn = tap(TextView(activity).apply {
            text = "⋮"; textSize = 22f; setTextColor(fg); gravity = android.view.Gravity.CENTER; contentDescription = "More"
        })
        topBar.addView(backBtn, LinearLayout.LayoutParams(dp(activity, 48), dp(activity, 56)))
        topBar.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(moreBtn, LinearLayout.LayoutParams(dp(activity, 48), dp(activity, 56)))
        page.addView(topBar, LinearLayout.LayoutParams(-1, dp(activity, 56)))

        // ---- breadcrumb
        val crumbScroll = android.widget.HorizontalScrollView(activity).apply { isHorizontalScrollBarEnabled = false; setBackgroundColor(panel) }
        val crumbRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(activity, 12), 0, dp(activity, 12), 0)
        }
        crumbScroll.addView(crumbRow, FrameLayout.LayoutParams(-2, -1))
        page.addView(crumbScroll, LinearLayout.LayoutParams(-1, dp(activity, 40)))
        page.addView(android.view.View(activity).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, 1))

        // ---- list
        val listView = android.widget.ListView(activity).apply {
            divider = android.graphics.drawable.ColorDrawable(line); dividerHeight = 1
            selector = android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)
            setBackgroundColor(bg)
            isVerticalScrollBarEnabled = true
        }
        val emptyView = TextView(activity).apply {
            text = "This folder is empty."; setTextColor(sub); gravity = android.view.Gravity.CENTER; visibility = android.view.View.GONE
        }
        val listFrame = FrameLayout(activity)
        listFrame.addView(listView, FrameLayout.LayoutParams(-1, -1))
        listFrame.addView(emptyView, FrameLayout.LayoutParams(-1, -1))
        page.addView(listFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- selection bar: Extract / Copy to / Delete work on anything selected at any depth
        page.addView(android.view.View(activity).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, 1))
        val selBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(activity, 12), dp(activity, 4), dp(activity, 4), dp(activity, 4))
            visibility = android.view.View.GONE
        }
        val selLabel = TextView(activity).apply { textSize = 14f; setTextColor(fg); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        fun barButton(label: String, color: Int) = tap(TextView(activity).apply {
            text = label; textSize = 14f; setTextColor(color); gravity = android.view.Gravity.CENTER
            setPadding(dp(activity, 10), 0, dp(activity, 10), 0); minHeight = dp(activity, 44)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, color)
        val selClear = barButton("✕", sub)
        val selCopy = barButton("Copy", accent)
        val selDelete = barButton("Delete", danger)
        selBar.addView(selLabel, LinearLayout.LayoutParams(0, -2, 1f))
        listOf(selCopy, selDelete, selClear).forEach { selBar.addView(it, LinearLayout.LayoutParams(-2, dp(activity, 44))) }
        page.addView(selBar, LinearLayout.LayoutParams(-1, -2))

        lateinit var adapter: android.widget.BaseAdapter

        fun refreshSelectionBar() {
            selBar.visibility = if (selected.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
            selLabel.text = "${selected.size} selected"
        }

        fun reload() {
            items = current.children.values.sortedWith(
                compareByDescending<ArcNode> { it.isDir }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            )
            adapter.notifyDataSetChanged()
            listView.setSelection(0)
            emptyView.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            crumbRow.removeAllViews()
            val chain = generateSequence(current) { it.parent }.toList().reversed()
            chain.forEachIndexed { i, node ->
                if (i > 0) crumbRow.addView(TextView(activity).apply { text = "  ›  "; setTextColor(sub); textSize = 13f })
                crumbRow.addView(tap(TextView(activity).apply {
                    text = if (node === root) archive.name else node.name
                    textSize = 13f
                    setTextColor(if (node === current) fg else accent)
                    if (node === current) setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(0, dp(activity, 8), 0, dp(activity, 8))
                    setOnClickListener { if (node !== current) { current = node; reload() } }
                }))
            }
            crumbScroll.post { crumbScroll.fullScroll(android.view.View.FOCUS_RIGHT) }
        }

        fun toggle(node: ArcNode) {
            if (!selected.add(node.path)) selected.remove(node.path)
            refreshSelectionBar(); adapter.notifyDataSetChanged()
        }

        adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int) = items[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: android.view.View?, parent: ViewGroup?): android.view.View {
                val node = items[position]
                val isSel = selected.contains(node.path)
                val row = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding(dp(activity, 14), dp(activity, 8), dp(activity, 6), dp(activity, 8))
                    minimumHeight = dp(activity, 64)
                    setBackgroundColor(if (isSel) accentSoft else panel)
                    descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                }
                row.addView(TextView(activity).apply {
                    text = arcIcon(node); textSize = 26f; gravity = android.view.Gravity.CENTER
                }, LinearLayout.LayoutParams(dp(activity, 44), dp(activity, 44)))
                val texts = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(activity, 12), 0, dp(activity, 8), 0) }
                texts.addView(TextView(activity).apply {
                    text = node.name; textSize = 16f; setTextColor(fg); maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                })
                texts.addView(TextView(activity).apply {
                    textSize = 12f; setTextColor(sub)
                    text = if (node.isDir) {
                        val n = node.children.size
                        val total = arcTotalSize(node)
                        (if (n == 1) "1 item" else "$n items") + if (total > 0) "  ·  ${formatBytes(total)}" else ""
                    } else if (node.size >= 0) formatBytes(node.size) else ""
                })
                row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(CheckBox(activity).apply {
                    isChecked = isSel
                    isFocusable = false
                    buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                    contentDescription = "Select ${node.name}"
                    setOnClickListener { toggle(node) }
                }, LinearLayout.LayoutParams(dp(activity, 48), dp(activity, 48)))
                return row
            }
        }
        listView.adapter = adapter

        // Extracts one entry to the cache and opens it. Nested archives open as a new explorer (any depth).
        fun openEntry(node: ArcNode) {
            val viewRoot = File(activity.cacheDir, "archive_view")
            try { viewRoot.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 24L * 3600_000L }?.forEach { it.deleteRecursively() } } catch (_: Exception) { }
            val temp = File(viewRoot, System.nanoTime().toString())
            runWithProgress(activity, node.name, { token, progress ->
                ArchiveManager.extract(archive, temp, password, progress, token, null, setOf(node.path))
                File(temp, node.path.replace('\\', '/'))
            }) { file, error ->
                if (error != null || file == null || !file.isFile) {
                    Toast.makeText(activity, error?.localizedMessage ?: activity.getString(R.string.archive_failed_generic), Toast.LENGTH_LONG).show()
                } else if (ArchiveManager.isArchive(file)) {
                    showArchivePreview(activity, file, destination)
                } else if (activity is FileManagerActivity) {
                    activity.openFileInsideOmniHub(file)
                } else try {
                    val uri = androidx.core.content.FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", file)
                    val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase(java.util.Locale.ROOT)) ?: "*/*"
                    activity.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (e: Exception) { Toast.makeText(activity, "No app can open this file", Toast.LENGTH_LONG).show() }
            }
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            val node = items.getOrNull(position) ?: return@setOnItemClickListener
            when {
                selected.isNotEmpty() -> toggle(node)
                node.isDir -> { current = node; reload() }
                else -> openEntry(node)
            }
        }
        listView.setOnItemLongClickListener { _, _, position, _ ->
            items.getOrNull(position)?.let { toggle(it) }; true
        }

        fun goUpOrClose() {
            if (selected.isNotEmpty()) { selected.clear(); refreshSelectionBar(); adapter.notifyDataSetChanged(); return }
            val up = current.parent
            if (up != null) { current = up; reload() } else dialog.dismiss()
        }
        backBtn.setOnClickListener { goUpOrClose() }
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK) { if (event.action == android.view.KeyEvent.ACTION_UP) goUpOrClose(); true }
            else false
        }

        val namedTarget = { File(destination, namedFolderFor(activity, archive)) }
        selClear.setOnClickListener { selected.clear(); refreshSelectionBar(); adapter.notifyDataSetChanged() }
        selCopy.setOnClickListener {
            val chosen = selected.toSet()
            if (chosen.isEmpty()) return@setOnClickListener
            FileClipboard.setArchiveEntries(archive, chosen, password)
            dialog.dismiss()
            if (activity is FileManagerActivity) activity.refreshPasteBar()
            Toast.makeText(activity, "Copied ${chosen.size} item(s). Open any folder and tap \"Paste here\".", Toast.LENGTH_LONG).show()
        }
        selDelete.setOnClickListener {
            val chosen = selected.toSet()
            if (chosen.isEmpty()) return@setOnClickListener
            if (!ArchiveManager.canEditInPlace(archive)) {
                Toast.makeText(activity, "Deleting inside an archive works for ZIP files. Extract it, delete, then compress again.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            AlertDialog.Builder(activity, android.R.style.Theme_Material_Light_Dialog_Alert)
                .setTitle("Delete from archive?")
                .setMessage("${chosen.size} item(s) will be permanently removed from ${archive.name}.")
                .setNegativeButton(R.string.action_cancel, null)
                .setPositiveButton("Delete") { _, _ ->
                    runWithProgress(activity, "Deleting…", { _, _ ->
                        ArchiveManager.deleteEntries(archive, chosen, password)
                        ArchiveManager.listEntries(archive, password)
                    }) { fresh, error ->
                        if (error != null || fresh == null) {
                            Toast.makeText(activity, error?.localizedMessage ?: activity.getString(R.string.archive_failed_generic), Toast.LENGTH_LONG).show()
                        } else {
                            val here = current.path
                            root = buildArchiveTree(fresh); totalEntries = fresh.size
                            var node = root
                            for (part in here.split('/').filter { it.isNotEmpty() }) node = node.children[part] ?: break
                            current = node
                            selected.clear(); refreshSelectionBar(); updateSubtitle(); reload()
                            (activity as? FileManagerActivity)?.onArchiveJobFinished()
                            Toast.makeText(activity, "Deleted", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.show()
        }

        moreBtn.setOnClickListener { v ->
            val menu = android.widget.PopupMenu(activity, v, 0, 0, android.R.style.Widget_Material_Light_PopupMenu)
            var id = 0
            val actions = mutableListOf<() -> Unit>()
            fun add(label: String, action: () -> Unit) { menu.menu.add(0, id++, 0, label); actions += action }
            if (isApk) add("Install") { dialog.dismiss(); installApk(activity, archive) }
            add("Select all in this folder") { items.forEach { selected.add(it.path) }; refreshSelectionBar(); adapter.notifyDataSetChanged() }
            add(activity.getString(R.string.archive_extract_here)) { runExtract(activity, archive, destination, password) }
            add("Extract to ${namedFolderFor(activity, archive)}/") { runExtract(activity, archive, namedTarget(), password) }
            add(activity.getString(R.string.archive_extract_to)) { promptDestination(activity, destination) { target -> runExtract(activity, archive, target, password) } }
            add(activity.getString(R.string.archive_test)) { runTest(activity, archive, password) }
            menu.setOnMenuItemClickListener { item -> actions.getOrNull(item.itemId)?.invoke(); true }
            menu.show()
        }

        dialog.setContentView(page)
        dialog.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(bg))
            statusBarColor = panel
            navigationBarColor = panel
            // Light system bars (dark icons) + draw around punch-hole / curved AMOLED screens.
            androidx.core.view.WindowCompat.getInsetsController(this, decorView).apply {
                isAppearanceLightStatusBars = true
                isAppearanceLightNavigationBars = true
            }
            if (android.os.Build.VERSION.SDK_INT >= 28) attributes = attributes.apply {
                layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(page) { v, insets ->
            val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        updateSubtitle()
        reload()
        refreshSelectionBar()
        dialog.show()
        val big = entries.sumOf { it.size.coerceAtLeast(0L) }
        if (archive.length() > 0L && big > 64L * 1024L * 1024L && big / archive.length().coerceAtLeast(1L) > ArchiveManager.ZIP_BOMB_RATIO_WARNING) {
            Toast.makeText(activity, R.string.archive_bomb_warning, Toast.LENGTH_LONG).show()
        }
    }

    /** Extracts [archive] into [destination] (used by the File Manager "Extract here" paste bar). */
    fun extractTo(activity: Activity, archive: File, destination: File) = runExtract(activity, archive, destination, null)

    /** Pastes items copied from inside an archive: each lands directly in [destination]. */
    fun extractEntriesTo(activity: Activity, archive: File, destination: File, password: String?, entries: Set<String>) =
        runExtract(activity, archive, destination, password, 0, entries, true)

    private fun runExtract(activity: Activity, archive: File, destination: File, password: String?, passwordAttempt: Int = 0, selectedEntryNames: Set<String>? = null, flatten: Boolean = false) {
        val free = try { destination.absoluteFile.parentFile?.usableSpace ?: archive.parentFile?.usableSpace ?: Long.MAX_VALUE } catch (_: Exception) { Long.MAX_VALUE }
        if (!destination.exists() && destination.parentFile?.exists() != true && destination.parentFile?.mkdirs() != true) {
            Toast.makeText(activity, R.string.archive_destination_invalid, Toast.LENGTH_LONG).show(); return
        }
        if (selectedEntryNames == null && (archive.length() > 50L * 1024 * 1024 || free < archive.length() * 2L)) {
            fun startService(policy: String) {
                val i = android.content.Intent(activity, ArchiveService::class.java)
                    .setAction(ArchiveService.ACTION_EXTRACT)
                    .putExtra(ArchiveService.EXTRA_ARCHIVE, archive.absolutePath)
                    .putExtra(ArchiveService.EXTRA_DEST, destination.absolutePath)
                    .putExtra(ArchiveService.EXTRA_PASSWORD, password)
                    .putExtra(ArchiveService.EXTRA_CONFLICT, policy)
                try {
                    if (android.os.Build.VERSION.SDK_INT >= 26) activity.startForegroundService(i) else activity.startService(i)
                    showServiceProgress(activity)
                } catch (e: Exception) { Toast.makeText(activity, e.localizedMessage ?: activity.getString(R.string.archive_failed_generic), Toast.LENGTH_LONG).show() }
            }
            if (destination.isDirectory && destination.list()?.isNotEmpty() == true) {
                // Big archives run in the background and cannot ask per file, so ask once up front.
                showChoiceDialog(activity, activity.getString(R.string.conflict_policy_msg, destination.name), null, null, listOf(
                    activity.getString(R.string.archive_conflict_replace) to Choice.REPLACE,
                    activity.getString(R.string.archive_conflict_keep_both) to Choice.KEEP_BOTH,
                    activity.getString(R.string.archive_conflict_skip) to Choice.SKIP,
                    activity.getString(R.string.action_cancel) to Choice.CANCEL
                )) { ans ->
                    when (ans.choice) {
                        Choice.REPLACE -> startService("replace")
                        Choice.SKIP -> startService("skip")
                        Choice.KEEP_BOTH -> startService("keep_both")
                        else -> { }
                    }
                }
            } else startService("keep_both")
            return
        }
        runWithProgress(activity, activity.getString(R.string.archive_extracting), { token, progress ->
            ArchiveManager.extract(archive, destination, password, progress, token, conflictResolver(activity), selectedEntryNames, flatten)
        }) { value, error ->
            if (error != null) {
                val message = error.localizedMessage.orEmpty().lowercase()
                val likelyPassword = message.contains("password") || message.contains("decrypt") || message.contains("aes") || message.contains("authentication")
                if (likelyPassword && passwordAttempt < 3 && !activity.isFinishing && !activity.isDestroyed) {
                    requestPassword(activity, passwordAttempt + 1) { answer ->
                        if (!answer.cancelled) runExtract(activity, archive, destination, answer.password, passwordAttempt + 1, selectedEntryNames, flatten)
                    }
                } else Toast.makeText(activity, error.localizedMessage ?: activity.getString(R.string.archive_failed_generic), Toast.LENGTH_LONG).show()
            } else {
                RecentFolders.changed(activity, destination)
                Toast.makeText(activity, activity.getString(R.string.archive_extract_complete, value?.completedEntries ?: 0, destination.absolutePath), Toast.LENGTH_LONG).show()
            }
        }
    }

    fun showCompressDialog(activity: Activity, files: List<File>, destination: File, onComplete: ((File) -> Unit)? = null) {
        if (files.isEmpty()) return
        val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(activity, 20), dp(activity, 8), dp(activity, 20), dp(activity, 4)) }
        val name = EditText(activity).apply {
            hint = activity.getString(R.string.archive_name)
            setSingleLine(true)
            val seed = if (files.size == 1) files.first().name.substringBeforeLast('.', files.first().name) else files.first().name.substringBeforeLast('.', files.first().name) + "_archive"
            setText(seed + ".zip")
            contentDescription = activity.getString(R.string.archive_name)
        }
        val format = Spinner(activity).apply {
            adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_dropdown_item, listOf("ZIP", "7z", "TAR.GZ"))
            contentDescription = activity.getString(R.string.archive_format)
        }
        val level = Spinner(activity).apply {
            adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_dropdown_item, listOf(
                activity.getString(R.string.archive_store), activity.getString(R.string.archive_fast), activity.getString(R.string.archive_normal), activity.getString(R.string.archive_maximum)
            ))
            setSelection(2); contentDescription = activity.getString(R.string.archive_level)
        }
        val password = EditText(activity).apply {
            hint = activity.getString(R.string.archive_password_optional)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true); contentDescription = hint
        }
        val showPassword = CheckBox(activity).apply { text = activity.getString(R.string.archive_show_password); minHeight = dp(activity, 48) }
        showPassword.setOnCheckedChangeListener { _, checked ->
            password.inputType = if (checked) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            password.setSelection(password.text?.length ?: 0)
        }
        val split = CheckBox(activity).apply { text = activity.getString(R.string.archive_split_parts); minHeight = dp(activity, 48); contentDescription = text }
        val splitSize = EditText(activity).apply {
            hint = activity.getString(R.string.archive_split_size_mb)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText("100")
            visibility = android.view.View.GONE
            contentDescription = hint
        }
        split.setOnCheckedChangeListener { _, checked -> splitSize.visibility = if (checked) android.view.View.VISIBLE else android.view.View.GONE }
        val destLabel = TextView(activity).apply { text = activity.getString(R.string.archive_destination) + ":\n" + destination.absolutePath; textSize = 12f }
        listOf(name, format, level, password, showPassword, split, splitSize, destLabel).forEach { box.addView(it, LinearLayout.LayoutParams(-1, if (it is CheckBox || it is Spinner || it === splitSize) dp(activity, 48) else -2).apply { topMargin = dp(activity, 4) }) }
        AlertDialog.Builder(activity)
            .setTitle(R.string.archive_compress)
            .setView(box)
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.action_confirm) { _, _ ->
                val ext = listOf("zip", "7z", "tar.gz")[format.selectedItemPosition]
                if (split.isChecked && ext != "zip") { Toast.makeText(activity, R.string.archive_split_zip_only, Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val splitSizeBytes = if (split.isChecked) {
                    val mb = splitSize.text?.toString()?.toLongOrNull()
                    if (mb == null || mb < 1L || mb > 4096L) { Toast.makeText(activity, R.string.archive_split_size_invalid, Toast.LENGTH_LONG).show(); return@setPositiveButton }
                    mb * 1024L * 1024L
                } else null
                var fileName = safeName(name.text.toString().trim().ifBlank { "archive.$ext" })
                if (!fileName.lowercase().endsWith(".$ext")) fileName += ".$ext"
                val output = File(destination, fileName)
                val pass = password.text?.toString()?.takeIf { it.isNotEmpty() }
                if (pass != null && ext != "zip") { Toast.makeText(activity, R.string.archive_password_zip_only, Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val bytes = files.sumOf { runCatching { it.length() }.getOrDefault(0L) }
                if (files.any { it.isDirectory } || bytes > 50L * 1024 * 1024) {
                    val i = android.content.Intent(activity, ArchiveService::class.java)
                        .setAction(ArchiveService.ACTION_COMPRESS)
                        .putStringArrayListExtra(ArchiveService.EXTRA_SOURCES, ArrayList(files.map { it.absolutePath }))
                        .putExtra(ArchiveService.EXTRA_ARCHIVE, output.absolutePath)
                        .putExtra(ArchiveService.EXTRA_FORMAT, ext)
                        .putExtra(ArchiveService.EXTRA_LEVEL, intArrayOf(0, 2, 5, 9)[level.selectedItemPosition])
                        .putExtra(ArchiveService.EXTRA_PASSWORD, pass)
                        .putExtra(ArchiveService.EXTRA_SPLIT_SIZE, splitSizeBytes ?: -1L)
                    try { if (android.os.Build.VERSION.SDK_INT >= 26) activity.startForegroundService(i) else activity.startService(i); showServiceProgress(activity) }
                    catch (e: Exception) { Toast.makeText(activity, e.localizedMessage ?: activity.getString(R.string.archive_failed_generic), Toast.LENGTH_LONG).show() }
                    return@setPositiveButton
                }
                runWithProgress(activity, activity.getString(R.string.archive_compressing), { token, progress ->
                    ArchiveManager.compress(files, output, ext, intArrayOf(0, 2, 5, 9)[level.selectedItemPosition], pass, progress, token, splitSizeBytes)
                }) { value, error ->
                    if (error != null) Toast.makeText(activity, error.localizedMessage ?: activity.getString(R.string.archive_failed_generic), Toast.LENGTH_LONG).show()
                    else { Toast.makeText(activity, activity.getString(R.string.archive_compress_complete, output.absolutePath), Toast.LENGTH_LONG).show(); onComplete?.invoke(output) }
                }
            }
            .show()
    }

    private fun runTest(activity: Activity, archive: File, password: String?) {
        runWithProgress(activity, activity.getString(R.string.archive_testing), { token, progress ->
            val temp = File(activity.cacheDir, "archive_test_${System.nanoTime()}")
            try { ArchiveManager.extract(archive, temp, password, progress, token) } finally { temp.deleteRecursively() }
            true
        }) { _, error ->
            Toast.makeText(activity, if (error == null) activity.getString(R.string.archive_test_ok) else activity.getString(R.string.archive_test_failed, error.localizedMessage ?: "unknown"), Toast.LENGTH_LONG).show()
        }
    }

    private fun promptDestination(activity: Activity, current: File, onChosen: (File) -> Unit) {
        val edit = EditText(activity).apply { setSingleLine(true); setText(current.absolutePath); setSelection(text.length); hint = activity.getString(R.string.archive_destination) }
        AlertDialog.Builder(activity).setTitle(R.string.archive_destination).setView(edit)
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.action_confirm) { _, _ ->
                val path = edit.text?.toString()?.trim().orEmpty()
                if (path.isBlank()) Toast.makeText(activity, R.string.archive_destination_invalid, Toast.LENGTH_LONG).show()
                else onChosen(File(path))
            }.show()
    }

    private fun safeName(raw: String): String = raw.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").take(150).ifBlank { "archive" }
    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(java.util.Locale.ROOT, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> String.format(java.util.Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024.0))
        else -> String.format(java.util.Locale.ROOT, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    }


    private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
}
