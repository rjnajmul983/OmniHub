package com.example.omnihub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/** Foreground worker used by archive jobs expected to last longer than a few seconds. */
class ArchiveService : Service() {
    companion object {
        const val ACTION_EXTRACT = "com.example.omnihub.archive.EXTRACT"
        const val ACTION_COMPRESS = "com.example.omnihub.archive.COMPRESS"
        const val ACTION_CANCEL = "com.example.omnihub.archive.CANCEL"
        const val EXTRA_ARCHIVE = "archive_path"
        const val EXTRA_DEST = "dest_path"
        const val EXTRA_SOURCES = "source_paths"
        const val EXTRA_FORMAT = "archive_format"
        const val EXTRA_LEVEL = "archive_level"
        const val EXTRA_PASSWORD = "archive_password"
        const val EXTRA_CONFLICT = "archive_conflict_policy" // replace | keep_both | skip (applies to existing files)
        const val EXTRA_SPLIT_SIZE = "archive_split_size_bytes"
        private const val CHANNEL = "omnihub_archive_jobs"
        private const val NOTIFICATION_ID = 3982

        /** Live job state for the on-screen progress dialog (null listener = dialog hidden / notification only). */
        data class State(val message: String, val percent: Int, val running: Boolean, val success: Boolean)

        @Volatile var lastState: State? = null
        @Volatile var listener: ((State) -> Unit)? = null
        private val mainHandler = Handler(Looper.getMainLooper())

        private fun publish(state: State) {
            lastState = state
            val l = listener ?: return
            mainHandler.post { l(state) }
        }
    }

    private val canceled = AtomicBoolean(false)
    private var token: ArchiveManager.CancelToken? = null
    private var worker: Thread? = null
    private var lastDestination: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            canceled.set(true)
            token?.cancel()
            worker?.interrupt()
            updateNotification(getString(R.string.archive_cancel_requested), 0, ongoing = true)
            return START_NOT_STICKY
        }
        if (worker?.isAlive == true) return START_NOT_STICKY
        canceled.set(false)
        token = ArchiveManager.CancelToken()
        createChannel()
        publish(State(getString(R.string.archive_starting), 0, true, false))
        startAsForeground(buildNotification(getString(R.string.archive_starting), 0, true))
        val task = intent ?: run { stopSelf(startId); return START_NOT_STICKY }
        worker = Thread({ runArchive(task, startId) }, "OmniHub-ArchiveService").apply { isDaemon = false; start() }
        return START_NOT_STICKY
    }

    private fun runArchive(intent: Intent, startId: Int) {
        val activeToken = token ?: ArchiveManager.CancelToken()
        try {
            val kind = intent.action
            val password = intent.getStringExtra(EXTRA_PASSWORD)
            val policy = intent.getStringExtra(EXTRA_CONFLICT).orEmpty()
            when (kind) {
                ACTION_EXTRACT -> {
                    val archive = File(intent.getStringExtra(EXTRA_ARCHIVE).orEmpty())
                    val destination = File(intent.getStringExtra(EXTRA_DEST).orEmpty())
                    lastDestination = destination.absolutePath
                    ArchiveManager.extract(archive, destination, password, { progress ->
                        activeToken.throwIfCancelled()
                        val pct = if (progress.totalBytes > 0) ((progress.completedBytes * 100) / progress.totalBytes).toInt().coerceIn(0, 100) else 0
                        updateNotification(progress.currentEntry.ifBlank { getString(R.string.archive_extracting) }, pct, true)
                    }, activeToken, { _, incoming ->
                        // Background job cannot show dialogs: folders always merge, files follow the policy chosen before starting.
                        if (incoming.isDirectory) ArchiveManager.ConflictDecision(ArchiveManager.ConflictAction.KEEP_BOTH, true, merge = true)
                        else ArchiveManager.ConflictDecision(when (policy) {
                            "replace" -> ArchiveManager.ConflictAction.REPLACE
                            "skip" -> ArchiveManager.ConflictAction.SKIP
                            else -> ArchiveManager.ConflictAction.KEEP_BOTH
                        }, true)
                    })
                }
                ACTION_COMPRESS -> {
                    val sources = intent.getStringArrayListExtra(EXTRA_SOURCES).orEmpty().map(::File)
                    val destination = File(intent.getStringExtra(EXTRA_ARCHIVE).orEmpty())
                    lastDestination = destination.parentFile?.absolutePath
                    ArchiveManager.compress(sources, destination, intent.getStringExtra(EXTRA_FORMAT).orEmpty(), intent.getIntExtra(EXTRA_LEVEL, 5), password, { progress ->
                        activeToken.throwIfCancelled()
                        val pct = if (progress.totalBytes > 0) ((progress.completedBytes * 100) / progress.totalBytes).toInt().coerceIn(0, 100) else 0
                        updateNotification(progress.currentEntry.ifBlank { getString(R.string.archive_compressing) }, pct, true)
                    }, activeToken, intent.getLongExtra(EXTRA_SPLIT_SIZE, -1L).takeIf { it > 0L })
                }
                else -> throw IllegalArgumentException("Unknown archive operation")
            }
            if (!canceled.get()) updateNotification(getString(R.string.archive_complete), 100, false, allowOpen = true)
        } catch (_: InterruptedException) {
            updateNotification(getString(R.string.archive_cancelled), 0, false)
        } catch (e: Exception) {
            updateNotification(getString(R.string.archive_failed, e.localizedMessage ?: e.javaClass.simpleName), 0, false)
        } finally {
            if (Build.VERSION.SDK_INT >= 24) {
                stopForeground(STOP_FOREGROUND_DETACH)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(false)
            }
            stopSelf(startId)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.archive_notification_channel), NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun startAsForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NOTIFICATION_ID, notification)
    }

    private fun updateNotification(title: String, progress: Int, ongoing: Boolean, allowOpen: Boolean = false) {
        publish(State(title, progress, ongoing, allowOpen))
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(title, progress, ongoing, allowOpen))
    }

    private fun buildNotification(title: String, progress: Int, ongoing: Boolean, allowOpen: Boolean = false): Notification {
        val cancelIntent = PendingIntent.getService(this, 1, Intent(this, ArchiveService::class.java).setAction(ACTION_CANCEL), pendingFlags())
        val builder = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(getString(R.string.archive_notification_title))
            .setContentText(title.take(110))
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setProgress(100, progress, progress == 0 && ongoing)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (ongoing) builder.addAction(0, getString(R.string.archive_cancel), cancelIntent)
        if (allowOpen && !lastDestination.isNullOrBlank()) {
            val openIntent = PendingIntent.getActivity(
                this, 2,
                Intent(this, FileManagerActivity::class.java).putExtra("mode", "browse").putExtra("browse_path", lastDestination),
                pendingFlags()
            )
            builder.setContentIntent(openIntent).addAction(0, getString(R.string.archive_open), openIntent).setAutoCancel(true)
        }
        return builder.build()
    }

    private fun pendingFlags(): Int = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
}
