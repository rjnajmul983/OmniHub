package com.example.omnihub

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.MimeTypeMap
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.Locale
import java.nio.charset.Charset
import org.json.JSONArray
import org.json.JSONObject
import android.database.sqlite.SQLiteDatabase
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var latestInsetScript = "(function(){})();"
    private var pendingHomeAfterLoad = false
    private var pendingOpenPath = ""
    private var pendingMode = "any"
    private var pendingSaveText = ""
    private var pendingSaveName = "untitled.txt"
    private var pendingSaveMime = "text/plain"
    private val io = java.util.concurrent.Executors.newFixedThreadPool(2)
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var musicPaths: List<String> = emptyList()
    private val ticker = object : Runnable {
        override fun run() {
            pushMusicState()
            if (player?.isPlaying == true) ui.postDelayed(this, 500)
        }
    }

    companion object {
        const val EXTRA_OPEN_PATH = "omnihub_open_file_path"
        private const val REQ_OPEN = 4101
        private const val REQ_SAVE = 4102
        private const val MAX_TEXT_BYTES = 4 * 1024 * 1024
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(242, 240, 247))
        webView.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        webView.isVerticalScrollBarEnabled = false
        webView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // This WebView only loads bundled assets; do not allow file-URL scripts to cross origins.
        webView.settings.allowFileAccess = true
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(OmniBridge(), "OmniBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                // The bridge is only for this bundled page. Web browsing happens in an isolated Activity.
                if (url.startsWith("file:///android_asset/")) return false
                openBrowser(url)
                return true
            }
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                view.evaluateJavascript(latestInsetScript, null)
                if (pendingHomeAfterLoad) {
                    pendingHomeAfterLoad = false
                    view.evaluateJavascript("if(typeof showTab==='function'){showTab('home')}else if(typeof showPage==='function'){showPage('home')};", null)
                }
                val path = pendingOpenPath
                if (path.isNotBlank()) {
                    pendingOpenPath = ""
                    routeSelectedFile(Uri.fromFile(File(path)), "browse")
                }
            }
        }
        setContentView(webView)
        InsetsUtil.applyWebView(this, webView) { script ->
            latestInsetScript = script
            if (webView.url?.startsWith("file:///android_asset/") == true) webView.evaluateJavascript(script, null)
        }
        webView.loadUrl("file:///android_asset/index.html")
        // Start indexing the whole library right away so folders open instantly later.
        LibraryIndex.warmUp(this, false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(HomeNavigation.EXTRA_SHOW_HOME, false)) {
            if (::webView.isInitialized && webView.url?.startsWith("file:///android_asset/index.html") == true) {
                webView.post {
                    webView.evaluateJavascript("if(typeof showTab==='function'){showTab('home')}else if(typeof showPage==='function'){showPage('home')};", null)
                }
            } else pendingHomeAfterLoad = true
        }
        val requestedPath = intent.getStringExtra(EXTRA_OPEN_PATH).orEmpty()
        if (requestedPath.isNotBlank()) {
            if (::webView.isInitialized && webView.url?.startsWith("file:///android_asset/") == true) {
                webView.post { routeSelectedFile(Uri.fromFile(File(requestedPath)), "browse") }
            } else pendingOpenPath = requestedPath
        }
    }

    inner class OmniBridge {
        /** Called by the page: home has a purple hero (white icons), other pages are light (dark icons). */
        @JavascriptInterface
        fun setStatusBarLight(light: Boolean) {
            runOnUiThread { InsetsUtil.setStatusBarIcons(this@MainActivity, light) }
        }

        @JavascriptInterface
        fun openFile(mode: String, mime: String, extension: String) {
            runOnUiThread {
                try {
                    pendingMode = mode.ifBlank { "any" }
                    val intent = Intent(this@MainActivity, FileManagerActivity::class.java)
                        .putExtra("mode", pendingMode)
                        .putExtra("mime", mime.ifBlank { "*/*" })
                        .putExtra("extension", extension.trim().lowercase().removePrefix("."))
                    startActivityForResult(intent, REQ_OPEN)
                } catch (e: Exception) {
                    toast("File browser could not open: ${e.localizedMessage ?: "unknown error"}")
                }
            }
        }

        /** Opens the in-app File Manager directly; unlike openFile this is not a picker result flow. */
        @JavascriptInterface
        fun openBrowse(query: String, filterMode: String, mime: String, extension: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(this@MainActivity, FileManagerActivity::class.java)
                        .putExtra("mode", "browse")
                        .putExtra("query", query)
                        .putExtra("browse_filter_mode", filterMode)
                        .putExtra("mime", mime.ifBlank { "*/*" })
                        .putExtra("extension", extension.trim().lowercase().removePrefix(".")))
                } catch (e: Exception) { toast("File browser could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun saveText(name: String, content: String, mime: String) {
            runOnUiThread {
                try {
                    pendingSaveName = safeFileName(name.ifBlank { "untitled.txt" })
                    pendingSaveText = content
                    pendingSaveMime = mime.ifBlank { mimeForName(pendingSaveName) }
                    val intent = Intent(this@MainActivity, FileManagerActivity::class.java)
                        .putExtra("mode", "save")
                        .putExtra("mime", pendingSaveMime)
                        .putExtra("save_name", pendingSaveName)
                    startActivityForResult(intent, REQ_SAVE)
                } catch (e: Exception) {
                    toast("Save browser could not open: ${e.localizedMessage ?: "unknown error"}")
                }
            }
        }

        /** Execute Python locally in the embedded CPython runtime. */
        @JavascriptInterface
        fun runPython(source: String): String {
            return try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this@MainActivity))
                Python.getInstance().getModule("code_runner").callAttr("execute", source).toString()
            } catch (e: Exception) { "Python runtime error: ${e.message ?: e.javaClass.simpleName}" }
        }

        /** Execute SQL against a fresh, temporary in-memory SQLite database. */
        @JavascriptInterface
        fun runSql(source: String): String {
            val db = SQLiteDatabase.create(null)
            val out = StringBuilder()
            return try {
                source.split(';').map { it.trim() }.filter { it.isNotEmpty() }.forEach { statement ->
                    val keyword = statement.substringBefore(' ').uppercase()
                    if (keyword in setOf("SELECT", "PRAGMA", "WITH", "EXPLAIN")) {
                        val cursor = db.rawQuery(statement, null)
                        cursor.use { c ->
                            val cols = (0 until c.columnCount).joinToString(" | ") { c.getColumnName(it) }
                            out.append(cols).append('\n')
                            while (c.moveToNext()) out.append((0 until c.columnCount).joinToString(" | ") { i -> if (c.isNull(i)) "NULL" else c.getString(i) }).append('\n')
                        }
                    } else {
                        db.execSQL(statement)
                        out.append("Statement executed.\n")
                    }
                }
                if (out.isEmpty()) "SQL finished. Database is temporary and resets each run." else out.toString()
            } catch (e: Exception) { "SQL error: ${e.message ?: e.javaClass.simpleName}" }
            finally { db.close() }
        }

        /** Kotlin uses an explicitly consented online compiler; source is sent to Piston. */
        @JavascriptInterface
        fun runKotlin(source: String): String {
            return try {
                val conn = URL("https://emkc.org/api/v2/piston/execute").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 30000
                conn.doOutput = true; conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                val payload = JSONObject().put("language", "kotlin").put("version", "*")
                    .put("files", org.json.JSONArray().put(JSONObject().put("name", "main.kt").put("content", source))).toString()
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                conn.disconnect()
                val json = JSONObject(response)
                val run = json.optJSONObject("run")
                val compile = json.optJSONObject("compile")
                val result = buildString {
                    if (compile != null && compile.optString("stderr").isNotBlank()) append(compile.optString("stderr")).append('\n')
                    if (run != null) { append(run.optString("stdout")); if (run.optString("stderr").isNotBlank()) append(run.optString("stderr")) }
                    if (isBlank()) append("Kotlin compiler returned no output.")
                }
                result
            } catch (e: Exception) { "Kotlin online compiler unavailable: ${e.message ?: e.javaClass.simpleName}. Check internet and try again." }
        }

        @JavascriptInterface
        fun runHtml(html: String) {
            runOnUiThread {
                try {
                    val file = File(cacheDir, "omnihub_preview.html")
                    file.writeText(html, Charsets.UTF_8)
                    startActivity(Intent(this@MainActivity, HtmlRunnerActivity::class.java).putExtra("html_path", file.absolutePath))
                } catch (_: Exception) {
                    toast("HTML preview তৈরি করা যায়নি")
                }
            }
        }

        @JavascriptInterface
        fun openStorageFolder(relativePath: String, newestFirst: Boolean) {
            runOnUiThread {
                try {
                    val base = android.os.Environment.getExternalStorageDirectory()
                    val target = if (relativePath.isBlank()) base else File(base, relativePath.trim().trimStart('/'))
                    startActivity(Intent(this@MainActivity, FileManagerActivity::class.java)
                        .putExtra("mode", "browse")
                        .putExtra("browse_path", target.absolutePath)
                        .putExtra("sort_recent", newestFirst))
                } catch (e: Exception) { toast("File Manager could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun openLibrary(kind: String) {
            runOnUiThread {
                try {
                    val k = kind.lowercase(Locale.ROOT)
                    val intent = Intent(this@MainActivity, FileManagerActivity::class.java)
                    when (k) {
                        "images" -> intent.putExtra("mode", "media").putExtra("mime", "image/*")
                        "audio" -> intent.putExtra("mode", "media").putExtra("mime", "audio/*")
                        "videos" -> intent.putExtra("mode", "media").putExtra("mime", "video/*")
                        "documents" -> intent.putExtra("mode", "browse").putExtra("initial_category", "Documents")
                        "new", "recent" -> intent.putExtra("mode", "recent")
                        else -> intent.putExtra("mode", "browse")
                    }
                    startActivity(intent)
                } catch (e: Exception) { toast("Library could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun openStorageTools(mode: String) {
            runOnUiThread {
                try { startActivity(Intent(this@MainActivity, StorageToolsActivity::class.java).putExtra("mode", mode)) }
                catch (e: Exception) { toast("Storage tools could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun openGlobalSearch(query: String) {
            runOnUiThread {
                try { startActivity(Intent(this@MainActivity, GlobalSearchActivity::class.java).putExtra("query", query)) }
                catch (e: Exception) { toast("Global Search could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun openDuplicateCleaner() {
            runOnUiThread {
                try { startActivity(Intent(this@MainActivity, DuplicateCleanerActivity::class.java)) }
                catch (e: Exception) { toast("Duplicate Cleaner could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun openRecycleBin() {
            runOnUiThread {
                try { startActivity(Intent(this@MainActivity, RecycleBinActivity::class.java)) }
                catch (e: Exception) { toast("Recycle Bin could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun openShizukuSetup() {
            runOnUiThread {
                try {
                    startActivity(Intent(this@MainActivity, ShizukuFileActivity::class.java)
                        .putExtra("path", android.os.Environment.getExternalStorageDirectory().absolutePath)
                        .putExtra("action", "files"))
                } catch (e: Exception) { toast("Shizuku setup could not open") }
            }
        }

        @JavascriptInterface
        fun getStorageSummary(): String {
            return try {
                val base = android.os.Environment.getExternalStorageDirectory()
                val total = base.totalSpace.coerceAtLeast(0L)
                val free = base.usableSpace.coerceAtLeast(0L)
                val used = (total - free).coerceAtLeast(0L)
                val percent = if (total > 0L) ((used.toDouble() / total.toDouble()) * 100.0).toInt().coerceIn(0, 100) else 0
                JSONObject().put("total", total).put("free", free).put("used", used).put("percent", percent).toString()
            } catch (_: Throwable) { "{\"total\":0,\"free\":0,\"used\":0,\"percent\":0}" }
        }

        @JavascriptInterface
        fun openBrowser(address: String) {
            runOnUiThread { this@MainActivity.openBrowser(address) }
        }

        @JavascriptInterface
        fun openSettings(key: String) {
            runOnUiThread { this@MainActivity.openSettings(key) }
        }

        @JavascriptInterface
        fun openShizuku(rel: String, action: String) {
            runOnUiThread {
                try {
                    val base = android.os.Environment.getExternalStorageDirectory().absolutePath
                    startActivity(Intent(this@MainActivity, ShizukuFileActivity::class.java)
                        .putExtra("path", if (rel.isBlank()) base else "$base/$rel")
                        .putExtra("action", action))
                } catch (_: Exception) { }
            }
        }

        @JavascriptInterface
        fun openShizukuApps() {
            runOnUiThread { try { startActivity(Intent(this@MainActivity, ShizukuAppsActivity::class.java)) } catch (_: Exception) { } }
        }

        @JavascriptInterface
        fun openAppLocker() {
            runOnUiThread {
                try { startActivity(Intent(this@MainActivity, AppLockerActivity::class.java)) }
                catch (_: Exception) { toast("App Locker could not open on this device") }
            }
        }

        @JavascriptInterface
        fun openSecureVault() {
            runOnUiThread {
                try { startActivity(Intent(this@MainActivity, SecureVaultActivity::class.java)) }
                catch (e: Exception) { toast("Secure Vault could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun requestMedia(kind: String, limit: Int) {
            io.execute {
                val json = try {
                    MediaCatalog.list(this@MainActivity, kind, limit.coerceIn(1, 2000)).toString()
                } catch (e: Exception) { "{\"access\":true,\"items\":[],\"total\":0}" }
                val safe = json.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
                runOnUiThread { js("window.onMediaList && window.onMediaList(${JSONObject.quote(kind)}, $safe)") }
            }
        }

        @JavascriptInterface
        fun requestThumb(key: String, kind: String, id: String, path: String, albumId: String) {
            io.execute {
                val uri = try {
                    MediaCatalog.thumb(this@MainActivity, kind, id.toLongOrNull() ?: 0L, path, albumId.toLongOrNull() ?: 0L)
                } catch (_: Throwable) { null }
                runOnUiThread { js("window.onThumb && window.onThumb(${JSONObject.quote(key)}, ${JSONObject.quote(uri ?: "")})") }
            }
        }

        @JavascriptInterface
        fun openMedia(path: String) {
            runOnUiThread {
                try {
                    player?.pause()
                    routeSelectedFile(Uri.fromFile(File(path)), "media")
                } catch (e: Exception) { toast("Could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun musicPlay(pathsJson: String, index: Int, shuffle: Boolean) {
            runOnUiThread {
                try {
                    val arr = JSONArray(pathsJson)
                    val list = ArrayList<String>()
                    for (i in 0 until arr.length()) list.add(arr.getString(i))
                    if (list.isEmpty()) return@runOnUiThread
                    musicPaths = list
                    val p = ensurePlayer()
                    p.setMediaItems(list.map { MediaItem.fromUri(Uri.fromFile(File(it))) }, index.coerceIn(0, list.size - 1), 0L)
                    p.shuffleModeEnabled = shuffle
                    p.prepare()
                    p.play()
                    attachMusicBackground(p)
                } catch (e: Exception) { toast("Could not play: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun musicToggle() {
            runOnUiThread {
                val p = player ?: return@runOnUiThread
                if (p.isPlaying) p.pause() else {
                    if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
                    p.play()
                    attachMusicBackground(p)
                }
            }
        }

        @JavascriptInterface
        fun musicNext() { runOnUiThread { player?.seekToNextMediaItem() } }

        @JavascriptInterface
        fun musicPrev() {
            runOnUiThread {
                val p = player ?: return@runOnUiThread
                if (p.currentPosition > 3000L) p.seekTo(0L) else p.seekToPreviousMediaItem()
            }
        }

        @JavascriptInterface
        fun musicSeek(ms: Int) { runOnUiThread { player?.seekTo(ms.toLong()); pushMusicState() } }

        @JavascriptInterface
        fun musicShuffle(on: Boolean) { runOnUiThread { player?.shuffleModeEnabled = on; pushMusicState() } }

        @JavascriptInterface
        fun musicRepeat(mode: Int) {
            runOnUiThread {
                player?.repeatMode = when (mode) { 1 -> Player.REPEAT_MODE_ALL; 2 -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                pushMusicState()
            }
        }

        @JavascriptInterface
        fun requestApps() {
            io.execute {
                val json = try { AppCatalog.list(this@MainActivity).toString() } catch (_: Throwable) { "[]" }
                runOnUiThread { js("window.onAppList && window.onAppList($json)") }
            }
        }

        @JavascriptInterface
        fun requestAppIcon(pkg: String) {
            io.execute {
                val uri = try { AppCatalog.icon(this@MainActivity, pkg) } catch (_: Throwable) { null }
                runOnUiThread { js("window.onAppIcon && window.onAppIcon(${JSONObject.quote(pkg)}, ${JSONObject.quote(uri ?: "")})") }
            }
        }

        @JavascriptInterface
        fun requestAppMenu(pkg: String) {
            io.execute {
                val shortcuts = try { AppCatalog.shortcuts(this@MainActivity, pkg) } catch (_: Throwable) { JSONArray() }
                val locked = (getSharedPreferences("omnihub_app_locker", MODE_PRIVATE).getStringSet("locked_packages", emptySet()) ?: emptySet()).contains(pkg)
                val o = JSONObject().put("shortcuts", shortcuts).put("locked", locked)
                runOnUiThread { js("window.onAppMenu && window.onAppMenu(${JSONObject.quote(pkg)}, $o)") }
            }
        }

        @JavascriptInterface
        fun launchApp(pkg: String) {
            runOnUiThread {
                try {
                    if (askLockFirst(pkg, null)) return@runOnUiThread
                    val i = packageManager.getLaunchIntentForPackage(pkg)
                    if (i == null) toast("This app can't be opened") else startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { toast("Could not open app: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun launchShortcut(pkg: String, id: String) {
            runOnUiThread {
                if (askLockFirst(pkg, id)) return@runOnUiThread
                if (!AppCatalog.launchShortcut(this@MainActivity, pkg, id)) toast("This shortcut can't be opened from here")
            }
        }

        @JavascriptInterface
        fun appAction(pkg: String, action: String) {
            runOnUiThread {
                try {
                    when (action) {
                        "info" -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
                        "notifications" -> {
                            if (android.os.Build.VERSION.SDK_INT >= 26) startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg))
                            else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
                        }
                        "uninstall" -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
                        "lock" -> toggleAppLock(pkg)
                    }
                } catch (e: Exception) { toast("Could not open: ${e.localizedMessage ?: "unknown error"}") }
            }
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("OmniHub", text))
                toast("কপি হয়েছে")
            }
        }

        @JavascriptInterface
        fun pasteClipboard() {
            runOnUiThread {
                val text = try {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    val clip = cm.primaryClip
                    if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this@MainActivity).toString() else ""
                } catch (_: Exception) { "" }
                val safe = JSONObject.quote(text).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
                js("window.onClipboardText && window.onClipboardText($safe)")
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                try { startActivity(Intent.createChooser(share, "Share from OmniHub")) }
                catch (_: Exception) { toast("No sharing app is available") }
            }
        }

        @JavascriptInterface
        fun showMessage(message: String) {
            runOnUiThread { toast(message.take(180)) }
        }
    }

    @Deprecated("Handled for broad Android project compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OPEN) {
            if (resultCode != RESULT_OK) return
            val path = data?.getStringExtra("selected_path")
            if (path.isNullOrBlank()) {
                toast("ফাইলের অবস্থান পাওয়া যায়নি")
                return
            }
            routeSelectedFile(Uri.fromFile(File(path)), pendingMode)
            return
        }
        if (requestCode == REQ_SAVE) {
            if (resultCode != RESULT_OK) return
            val path = data?.getStringExtra("save_path")
            if (path.isNullOrBlank()) {
                toast("সেভ করার ফোল্ডার পাওয়া যায়নি")
                return
            }
            try {
                val target = File(path)
                target.parentFile?.let { parent ->
                    if (!parent.exists() || !parent.isDirectory) throw IllegalStateException("Folder does not exist")
                }
                target.outputStream().use { it.write(pendingSaveText.toByteArray(Charsets.UTF_8)) }
                toast("ফাইল সেভ হয়েছে: ${target.name}")
                webView.evaluateJavascript("window.onNativeSaved && window.onNativeSaved(${JSONObject.quote(target.name)})", null)
            } catch (e: Exception) {
                toast("Save করা যায়নি: ${e.localizedMessage ?: "অজানা সমস্যা"}")
            }
            return
        }
    }

    /** A protected app must ask for PIN / fingerprint BEFORE it opens, so it never shows even for a moment. */
    private fun askLockFirst(pkg: String, shortcutId: String?): Boolean {
        val prefs = getSharedPreferences("omnihub_app_locker", MODE_PRIVATE)
        if (prefs.getString("pin_hash", null).isNullOrBlank()) return false
        val locked = prefs.getStringSet("locked_packages", emptySet()) ?: emptySet()
        if (pkg !in locked) return false
        val i = Intent(this, AppLockScreenActivity::class.java)
            .putExtra("locked_package", pkg)
            .putExtra("launch_after_unlock", true)
        if (!shortcutId.isNullOrBlank()) i.putExtra("launch_shortcut_id", shortcutId)
        startActivity(i)
        return true
    }

    private fun toggleAppLock(pkg: String) {
        val prefs = getSharedPreferences("omnihub_app_locker", MODE_PRIVATE)
        if (prefs.getString("pin_hash", null).isNullOrBlank()) {
            toast("Set a PIN in App Locker first")
            startActivity(Intent(this, AppLockerActivity::class.java))
            return
        }
        val set = (prefs.getStringSet("locked_packages", emptySet()) ?: emptySet()).toMutableSet()
        val nowLocked = if (set.contains(pkg)) { set.remove(pkg); false } else { set.add(pkg); true }
        prefs.edit().putStringSet("locked_packages", set).apply()
        toast(if (nowLocked) "Locked. Keep the auto-lock service ON in App Locker." else "Unlocked")
        js("window.onAppLock && window.onAppLock(${JSONObject.quote(pkg)}, $nowLocked)")
    }

    private fun js(code: String) {
        try { webView.evaluateJavascript(code, null) } catch (_: Exception) { }
    }

    private fun attachMusicBackground(p: ExoPlayer) {
        val open = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        PlaybackHub.attach(this, p, open) { musicPaths.getOrNull(p.currentMediaItemIndex)?.let { File(it).nameWithoutExtension } ?: "OmniHub music" }
    }

    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val p = ExoPlayer.Builder(this).build()
        try { p.setWakeMode(C.WAKE_MODE_LOCAL) } catch (_: Throwable) { }
        p.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
        p.setHandleAudioBecomingNoisy(true)
        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { ui.removeCallbacks(ticker); ui.post(ticker) }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { pushMusicState() }
            override fun onPlaybackStateChanged(playbackState: Int) { pushMusicState() }
            override fun onPlayerError(error: PlaybackException) {
                toast("This track can't be played")
                if (p.hasNextMediaItem()) { p.seekToNextMediaItem(); p.prepare(); p.play() }
            }
        })
        player = p
        return p
    }

    private fun pushMusicState() {
        val p = player ?: return
        try {
            val dur = p.duration
            val o = JSONObject()
            o.put("playing", p.isPlaying)
            o.put("index", p.currentMediaItemIndex)
            o.put("pos", p.currentPosition)
            o.put("dur", if (dur == C.TIME_UNSET) 0L else dur)
            o.put("shuffle", p.shuffleModeEnabled)
            o.put("repeat", when (p.repeatMode) { Player.REPEAT_MODE_ALL -> 1; Player.REPEAT_MODE_ONE -> 2; else -> 0 })
            o.put("path", musicPaths.getOrNull(p.currentMediaItemIndex) ?: "")
            js("window.onMusicState && window.onMusicState($o)")
        } catch (_: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        js("window.onAppResume && window.onAppResume()")
        LibraryIndex.warmUp(this, false)
    }

    override fun onDestroy() {
        ui.removeCallbacks(ticker)
        try { player?.let { PlaybackHub.detach(it) } } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        io.shutdown()
        super.onDestroy()
    }

    private fun routeSelectedFile(uri: Uri, mode: String) {
        val localFile = if (uri.scheme == "file") uri.path?.let { File(it) } else null
        val name = localFile?.name ?: queryDisplayName(uri) ?: "selected_file"
        val mime = localFile?.let { mimeForFile(it) } ?: contentResolver.getType(uri) ?: mimeForName(name)
        if (uri.scheme == "content") {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
                // Some providers do not support persistable permissions; this open session can still work.
            }
        }

        if (mode == "browse" && localFile != null && localFile.extension.lowercase(Locale.ROOT) in setOf("html", "htm")) {
            startActivity(Intent(this, HtmlRunnerActivity::class.java).putExtra("html_path", localFile.absolutePath))
            return
        }

        if (mode == "text" || (mode != "media" && isTextLike(name, mime))) {
            if (!isTextLike(name, mime)) {
                toast("এই ফাইলটি টেক্সট/কোড ফরম্যাট নয়। Media/File অপশন ব্যবহার করো।")
                return
            }
            try {
                val input = localFile?.inputStream() ?: contentResolver.openInputStream(uri)
                val bytes = input?.use { readLimited(it, MAX_TEXT_BYTES) }
                    ?: throw IllegalStateException("ফাইল পড়া যায়নি")
                if (bytes.size > MAX_TEXT_BYTES) throw IllegalStateException("৪ MB-এর বড় ফাইল এই editor-এ নিরাপদে খোলা যাচ্ছে না")
                val text = String(bytes, Charsets.UTF_8)
                webView.evaluateJavascript(
                    "window.onNativeFileOpened && window.onNativeFileOpened(${JSONObject.quote(name)}, ${JSONObject.quote(mime)}, ${JSONObject.quote(text)})",
                    null
                )
                return
            } catch (e: Exception) {
                toast("ফাইল খোলা যায়নি: ${e.localizedMessage ?: "অজানা সমস্যা"}")
                return
            }
        }

        try {
            when {
                localFile != null && localFile.extension.equals("apk", true) -> ArchiveDialogs.showArchivePreview(this, localFile)
                mime.startsWith("video/") || mime.startsWith("audio/") -> {
                    startActivity(Intent(this, MediaActivity::class.java).setDataAndType(uri, mime).putExtra("mime", mime).putExtra("name", name).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }
                mime.startsWith("image/") -> {
                    startActivity(Intent(this, ImagePreviewActivity::class.java).setData(uri).putExtra("name", name).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }
                mode == "media" -> openExternalFile(uri, mime)
                else -> openExternalFile(uri, mime)
            }
        } catch (e: Exception) {
            toast("ফাইল খোলা যায়নি: ${e.localizedMessage ?: "অজানা সমস্যা"}")
        }
    }

    private fun openExternalFile(uri: Uri, mime: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).setDataAndType(MediaShare.shareableUri(this, uri), mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Open with"))
        } catch (_: Exception) {
            toast("এই ফাইল খোলার উপযুক্ত অ্যাপ পাওয়া যায়নি")
        }
    }

    private fun openBrowser(address: String) {
        val raw = address.trim().ifBlank { "https://www.google.com" }
        val url = when {
            raw.startsWith("https://", true) || raw.startsWith("http://", true) -> raw
            raw.contains(" ") || !raw.contains(".") -> "https://www.google.com/search?q=" + Uri.encode(raw)
            else -> "https://$raw"
        }
        val scheme = Uri.parse(url).scheme?.lowercase()
        if (scheme != "http" && scheme != "https") {
            toast("শুধু http/https ওয়েব ঠিকানা খোলা যাবে")
            return
        }
        startActivity(Intent(this, BrowserActivity::class.java).putExtra("url", url))
    }

    private fun openSettings(key: String) {
        val action = when (key.lowercase()) {
            "developer" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "allapps" -> Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "security" -> Settings.ACTION_SECURITY_SETTINGS
            "privacy" -> Settings.ACTION_PRIVACY_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "keyboard" -> Settings.ACTION_INPUT_METHOD_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "network" -> Settings.ACTION_DATA_USAGE_SETTINGS
            "notifications" -> Settings.ACTION_SETTINGS
            "device" -> Settings.ACTION_DEVICE_INFO_SETTINGS
            "home" -> Settings.ACTION_HOME_SETTINGS
            "system" -> Settings.ACTION_SETTINGS
            "thisapp" -> Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val intent = Intent(action)
        if (key.lowercase() == "thisapp") intent.data = Uri.parse("package:$packageName")
        try {
            startActivity(intent)
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { toast("এই Settings পেজটি ডিভাইসে নেই") }
        }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun isTextLike(name: String, mime: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        val extensions = setOf("txt", "html", "htm", "css", "js", "mjs", "json", "xml", "csv", "md", "markdown", "yaml", "yml", "log", "ini", "kt", "java", "py", "c", "h", "cpp", "sh", "sql", "svg", "gradle", "properties", "ts", "tsx", "jsx", "php", "rb", "go", "rs", "toml")
        return ext in extensions || mime.startsWith("text/") || mime in setOf("application/json", "application/xml", "application/javascript", "application/x-javascript", "application/x-yaml", "application/sql")
    }

    private fun mimeForFile(file: File): String {
        val ext = file.extension.lowercase()
        if (ext in MediaKinds.video) return when (ext) {
            "mkv" -> "video/x-matroska"; "flv", "f4v" -> "video/x-flv"; "m4v" -> "video/x-m4v"; "avi" -> "video/x-msvideo"
            "wmv", "asf" -> "video/x-ms-wmv"; "mov" -> "video/quicktime"; "mpg", "mpeg", "mpe" -> "video/mpeg"
            "3gp", "3gpp", "3g2" -> "video/3gpp"; "ts", "m2ts", "mts" -> "video/mp2t"; "webm" -> "video/webm"; "ogv" -> "video/ogg"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "video/*"
        }
        if (ext in MediaKinds.audio) return when (ext) {
            "m4a", "m4b" -> "audio/mp4"; "aac" -> "audio/aac"; "flac" -> "audio/flac"; "opus" -> "audio/opus"
            "oga", "ogg" -> "audio/ogg"; "wma" -> "audio/x-ms-wma"; "mka" -> "audio/x-matroska"; "ac3" -> "audio/ac3"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "audio/*"
        }
        if (ext in MediaKinds.image) return when (ext) {
            "heic" -> "image/heic"; "heif" -> "image/heif"; "avif" -> "image/avif"; "svg" -> "image/svg+xml"
            "jpg", "jpeg", "jpe", "jfif" -> "image/jpeg"; "webp" -> "image/webp"; "ico" -> "image/x-icon"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "image/*"
        }
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: mimeForName(file.name)
    }

    private fun mimeForName(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js", "mjs" -> "text/javascript"
        "json" -> "application/json"
        "xml", "svg" -> "application/xml"
        "csv" -> "text/csv"
        "md", "markdown" -> "text/markdown"
        "kt", "java", "py", "txt", "log", "ini", "sh", "sql", "gradle", "properties" -> "text/plain"
        else -> "application/octet-stream"
    }

    private fun safeFileName(value: String): String = value.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120).ifBlank { "untitled.txt" }

    private fun readLimited(input: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > limit) return ByteArray(limit + 1)
            out.write(buffer, 0, count)
        }
        return out.toByteArray()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    @Deprecated("Fallback for older activity lifecycle")
    override fun onBackPressed() {
        webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : false") { result ->
            if (result != "true") super.onBackPressed()
        }
    }
}
