package com.example.omnihub

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.MotionEvent
import android.view.View
import android.widget.ImageButton
import androidx.core.widget.ImageViewCompat

object HomeNavigation {
    const val EXTRA_SHOW_HOME = "omnihub_show_home"

    fun makeHomeButton(activity: Activity): ImageButton = makeIconButton(
        activity,
        R.drawable.ic_home,
        activity.getString(R.string.home_go_to_app_home)
    ) { goHome(activity) }

    fun makeStorageRootButton(activity: Activity, onClick: () -> Unit): ImageButton = makeIconButton(
        activity,
        R.drawable.ic_storage_root,
        activity.getString(R.string.storage_root_description),
        onClick
    )

    private fun makeIconButton(activity: Activity, icon: Int, description: String, onClick: () -> Unit): ImageButton {
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density + .5f).toInt()
        val shape = GradientDrawable().apply {
            setColor(Color.rgb(252, 251, 254))
            setStroke(dp(1), Color.rgb(218, 213, 230))
            cornerRadius = dp(14).toFloat()
        }
        return ImageButton(activity).apply {
            setImageResource(icon)
            ImageViewCompat.setImageTintList(this, ColorStateList.valueOf(Color.rgb(102, 80, 196)))
            background = RippleDrawable(ColorStateList.valueOf(0x265365E1), shape, shape.constantState?.newDrawable()?.mutate())
            contentDescription = description
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setPadding(dp(9), dp(9), dp(9), dp(9))
            isClickable = true
            isFocusable = true
            minimumWidth = dp(40)
            minimumHeight = dp(40)
            layoutParams = android.widget.LinearLayout.LayoutParams(dp(40), dp(40))
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> view.animate().scaleX(.95f).scaleY(.95f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }
                false
            }
            setOnClickListener { onClick() }
        }
    }

    fun goHome(activity: Activity) {
        val intent = Intent(activity, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_SHOW_HOME, true)
        }
        activity.startActivity(intent)
        activity.overridePendingTransition(R.anim.splash_main_enter, R.anim.splash_exit)
    }
}
