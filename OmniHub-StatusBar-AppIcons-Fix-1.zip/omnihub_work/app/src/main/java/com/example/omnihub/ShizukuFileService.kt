package com.example.omnihub

import android.os.Binder
import android.os.Parcel
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.IOException
import kotlin.system.exitProcess

/**
 * Runs INSIDE Shizuku's process (shell / root uid), started through Shizuku.bindUserService.
 * Hand-written Binder (no AIDL tool needed). Talks to [ShizukuHelper] on the app side.
 */
class ShizukuFileService() : Binder() {
    companion object {
        const val DESTROY = 16777114          // transaction id Shizuku uses to stop a user service
        const val LIST = 1
        const val MKDIRS = 2
        const val DELETE = 3
        const val RENAME = 4
        const val COPY = 5
        const val OPEN = 6
        const val EXEC = 7
        const val STAT = 8
        const val SEP = '\u0001'
    }

    override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
        if (code == DESTROY) exitProcess(0)
        if (code !in LIST..STAT || reply == null) return super.onTransact(code, data, reply, flags)
        try {
            when (code) {
                LIST -> {
                    val pfd = listPipe(data.readString().orEmpty())
                    reply.writeInt(0); pfd.writeToParcel(reply, 0)
                }
                MKDIRS -> {
                    val f = File(data.readString().orEmpty())
                    val ok = f.isDirectory || f.mkdirs() || sh("mkdir -p ${q(f.path)}").first == 0
                    reply.writeInt(0); reply.writeInt(if (ok) 1 else 0)
                }
                DELETE -> {
                    val f = File(data.readString().orEmpty())
                    val ok = f.deleteRecursively() || sh("rm -rf ${q(f.path)}").first == 0
                    reply.writeInt(0); reply.writeInt(if (ok) 1 else 0)
                }
                RENAME -> {
                    val from = File(data.readString().orEmpty()); val to = File(data.readString().orEmpty())
                    var ok = from.renameTo(to)
                    if (!ok) ok = sh("mv ${q(from.path)} ${q(to.path)}").first == 0
                    reply.writeInt(0); reply.writeInt(if (ok) 1 else 0)
                }
                COPY -> {
                    val from = File(data.readString().orEmpty()); val to = File(data.readString().orEmpty())
                    var ok = try { from.copyRecursively(to, overwrite = false) } catch (_: Throwable) { false }
                    if (!ok) ok = sh("cp -a ${q(from.path)} ${q(to.path)}").first == 0
                    reply.writeInt(0); reply.writeInt(if (ok) 1 else 0)
                }
                OPEN -> {
                    val f = File(data.readString().orEmpty())
                    val mode = when (data.readString()) {
                        "w" -> ParcelFileDescriptor.MODE_WRITE_ONLY or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
                        "rw" -> ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE
                        else -> ParcelFileDescriptor.MODE_READ_ONLY
                    }
                    val pfd = ParcelFileDescriptor.open(f, mode)
                    reply.writeInt(0); pfd.writeToParcel(reply, 0)
                }
                EXEC -> {
                    val r = sh(data.readString().orEmpty())
                    reply.writeInt(0); reply.writeInt(r.first); reply.writeString(r.second)
                }
                STAT -> {
                    val f = File(data.readString().orEmpty())
                    reply.writeInt(0)
                    reply.writeInt(if (f.exists()) 1 else 0); reply.writeInt(if (f.isDirectory) 1 else 0)
                    reply.writeLong(f.length()); reply.writeLong(f.lastModified())
                }
            }
        } catch (t: Throwable) {
            reply.setDataSize(0); reply.setDataPosition(0)
            reply.writeInt(1); reply.writeString(t.message ?: t.javaClass.simpleName)
        }
        return true
    }

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun sh(cmd: String): Pair<Int, String> {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        return code to (if (out.length > 200_000) out.take(200_000) + "\n…(truncated)" else out)
    }

    /** Streams the listing through a pipe so huge folders are not limited by the 1 MB binder size. */
    private fun listPipe(path: String): ParcelFileDescriptor {
        val dir = File(path)
        val lines = ArrayList<String>()
        val files = dir.listFiles()
        if (files != null) {
            for (f in files) {
                val link = try { f.canonicalPath != f.absolutePath } catch (_: Throwable) { false }
                val type = if (f.isDirectory) 'd' else 'f'
                lines.add("$type$SEP${f.length()}$SEP${f.lastModified()}$SEP${if (link) 1 else 0}$SEP${f.name}")
            }
        } else {
            // Fallback for folders File.listFiles() refuses but the shell can still list.
            val r = sh("ls -A1p ${q(path)}")
            if (r.first != 0) throw IOException(r.second.trim().ifBlank { "Cannot read $path" })
            for (n in r.second.lines()) {
                if (n.isBlank()) continue
                val isDir = n.endsWith("/")
                lines.add("${if (isDir) 'd' else 'f'}${SEP}0${SEP}0${SEP}0$SEP${n.removeSuffix("/")}")
            }
        }
        val pipe = ParcelFileDescriptor.createPipe()
        Thread {
            try {
                ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]).bufferedWriter().use { w ->
                    for (l in lines) { w.write(l); w.write("\n") }
                }
            } catch (_: Throwable) { }
        }.start()
        return pipe[0]
    }
}
