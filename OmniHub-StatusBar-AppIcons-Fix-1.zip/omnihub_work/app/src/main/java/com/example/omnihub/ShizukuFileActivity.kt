package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import rikka.shizuku.Shizuku
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/**
 * File manager that runs through Shizuku: browse and modify Android/data, Android/obb and other
 * folders normal apps cannot access (root-only folders too when Shizuku runs as root).
 */
class ShizukuFileActivity : Activity() {
    private val bg = Color.rgb(11, 16, 32)
    private val panel = Color.rgb(23, 35, 59)
    private val accent = Color.rgb(98, 228, 211)
    private val white = Color.rgb(244, 247, 255)
    private val muted = Color.rgb(150, 162, 190)
    private val ui = Handler(Looper.getMainLooper())

    private val storage: String = Environment.getExternalStorageDirectory().absolutePath
    private var cwd = storage
    private var entries: List<ShizukuHelper.Entry> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var clipboard: List<String> = emptyList()
    private var clipMove = false
    private var loadToken = 0
    private var pendingAction: String? = null

    private lateinit var banner: LinearLayout
    private lateinit var bannerText: TextView
    private lateinit var bannerButton: Button
    private lateinit var pathLabel: TextView
    private lateinit var listView: ListView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var emptyLabel: TextView
    private lateinit var selectionBar: LinearLayout
    private lateinit var selectionLabel: TextView
    private lateinit var pasteButton: Button
    private val adapter = RowsAdapter()

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, _ -> ui.post { refreshStatus() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { ui.post { refreshStatus() } }
    private val deadListener = Shizuku.OnBinderDeadListener { ui.post { refreshStatus() } }
    private val serviceListener: () -> Unit = { ui.post { refreshStatus() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("omnihub_shizuku", MODE_PRIVATE)
        cwd = intent.getStringExtra("path") ?: prefs.getString("last_path", null) ?: storage
        pendingAction = intent.getStringExtra("action")?.takeIf { it == "shell" }
        buildUi()
        try {
            Shizuku.addRequestPermissionResultListener(permissionListener)
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (_: Throwable) { }
        ShizukuHelper.changeListeners.add(serviceListener)
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permissionListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (_: Throwable) { }
        ShizukuHelper.changeListeners.remove(serviceListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, color: Int = panel, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false
        setTextColor(if (color == accent) bg else white)
        backgroundTintList = ColorStateList.valueOf(color)
        minHeight = dp(36); minimumHeight = dp(36); minWidth = dp(40); minimumWidth = dp(40)
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(10), dp(8), dp(10), dp(8)) }

        root.addView(TextView(this).apply { text = "Shizuku Files"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white) })

        banner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(dp(12), dp(10), dp(12), dp(10)); visibility = View.GONE
        }
        bannerText = TextView(this).apply { setTextColor(white); textSize = 13f }
        bannerButton = btn("", accent) { }
        banner.addView(bannerText)
        banner.addView(bannerButton, LinearLayout.LayoutParams(-2, dp(40)).apply { topMargin = dp(8) })
        root.addView(banner, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        pathLabel = TextView(this).apply {
            setTextColor(accent); textSize = 12f; typeface = Typeface.MONOSPACE; setPadding(dp(4), dp(8), dp(4), dp(6))
            setOnClickListener { promptPath() }
        }
        root.addView(pathLabel)

        val quick = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "Internal" to storage,
            "Android/data" to "$storage/Android/data",
            "Android/obb" to "$storage/Android/obb",
            "Android/media" to "$storage/Android/media",
            "/data/local/tmp" to "/data/local/tmp",
            "/data/data (root)" to "/data/data",
            "/ (root)" to "/"
        ).forEach { (l, p) -> quickRow.addView(btn(l) { goTo(p) }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) }) }
        quick.addView(quickRow)
        root.addView(quick)

        val tools = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val toolRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(6)) }
        toolRow.addView(btn("↑ Up") { goUp() }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        toolRow.addView(btn("＋ Folder") { promptNew(true) }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        toolRow.addView(btn("＋ File") { promptNew(false) }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        pasteButton = btn("Paste") { paste() }.apply { visibility = View.GONE }
        toolRow.addView(pasteButton, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        toolRow.addView(btn("Shell") { promptShell() }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        toolRow.addView(btn("↻") { load() }, LinearLayout.LayoutParams(-2, dp(38)))
        tools.addView(toolRow)
        root.addView(tools)

        listView = ListView(this).apply {
            divider = null; adapter = this@ShizukuFileActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> onTap(entries[pos]) }
            setOnItemLongClickListener { _, _, pos, _ -> toggle(entries[pos]); true }
        }
        emptyLabel = TextView(this).apply { text = "This folder is empty"; setTextColor(muted); gravity = Gravity.CENTER; visibility = View.GONE }
        val box = android.widget.FrameLayout(this)
        box.addView(listView, android.widget.FrameLayout.LayoutParams(-1, -1))
        box.addView(emptyLabel, android.widget.FrameLayout.LayoutParams(-1, -1))
        swipe = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(accent); setProgressBackgroundColorSchemeColor(panel)
            setOnChildScrollUpCallback { _, _ -> listView.canScrollVertically(-1) }
            setOnRefreshListener { load() }
            addView(box, ViewGroup.LayoutParams(-1, -1))
        }
        root.addView(swipe, LinearLayout.LayoutParams(-1, 0, 1f))

        selectionBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(panel); setPadding(dp(6), dp(4), dp(6), dp(4)); visibility = View.GONE }
        selectionLabel = TextView(this).apply { setTextColor(white); textSize = 12f; setPadding(dp(6), 0, dp(8), 0) }
        selectionBar.addView(selectionLabel)
        val selScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val selRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        selRow.addView(btn("Copy", accent) { setClipboard(false) }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        selRow.addView(btn("Cut") { setClipboard(true) }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        selRow.addView(btn("Delete") { confirmDelete(selected.toList()) }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        selRow.addView(btn("Rename") { selected.singleOrNull()?.let { promptRename(it) } ?: toast("Select one item") }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        selRow.addView(btn("Info") { selected.singleOrNull()?.let { showInfo(it) } ?: toast("Select one item") }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        selRow.addView(btn("All") { selected.clear(); entries.forEach { selected.add(path(it.name)) }; updateSelection() }, LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) })
        selRow.addView(btn("✕") { clearSelection() }, LinearLayout.LayoutParams(-2, dp(38)))
        selScroll.addView(selRow)
        selectionBar.addView(selScroll)
        root.addView(selectionBar, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
        InsetsUtil.apply(this, root)
    }

    // ----------------------------------------------------------------------------------------- status

    private fun refreshStatus() {
        if (!::banner.isInitialized) return
        val installed = ShizukuHelper.installed(this)
        when {
            !ShizukuHelper.running() && !installed -> showBanner("Shizuku is not installed. Install it, start it, then come back.", "Get Shizuku") { ShizukuHelper.openDownloadPage(this) }
            !ShizukuHelper.running() -> showBanner("Shizuku is installed but not running. Open Shizuku and start it (Wireless debugging or root).", "Open Shizuku") {
                if (!ShizukuHelper.openShizukuApp(this)) toast("Cannot open Shizuku")
            }
            !ShizukuHelper.permitted() -> showBanner("OmniHub needs Shizuku permission to access protected folders.", "Grant permission") {
                if (ShizukuHelper.deniedForever()) {
                    toast("Permission was denied. Open Shizuku → Authorized apps and allow OmniHub.")
                    ShizukuHelper.openShizukuApp(this)
                } else ShizukuHelper.requestPermission()
            }
            ShizukuHelper.service == null -> { showBanner("Connecting to Shizuku…", null) { }; ShizukuHelper.bind(this) }
            else -> {
                banner.visibility = View.GONE
                if (entries.isEmpty() && !swipe.isRefreshing) load()
                if (pendingAction == "shell") { pendingAction = null; promptShell() }
            }
        }
        pathLabel.text = cwd + if (ShizukuHelper.service != null) (if (ShizukuHelper.isRoot()) "   · root" else "   · adb shell") else ""
    }

    private fun showBanner(text: String, button: String?, action: () -> Unit) {
        banner.visibility = View.VISIBLE
        bannerText.text = text
        if (button == null) bannerButton.visibility = View.GONE
        else { bannerButton.visibility = View.VISIBLE; bannerButton.text = button; bannerButton.setOnClickListener { action() } }
    }

    private fun ready(): Boolean {
        if (ShizukuHelper.service != null) return true
        toast("Shizuku is not connected yet"); refreshStatus(); return false
    }

    // ------------------------------------------------------------------------------------- navigation

    private fun path(name: String) = if (cwd == "/") "/$name" else "$cwd/$name"

    private fun goTo(p: String) {
        cwd = p; entries = emptyList(); adapter.notifyDataSetChanged(); clearSelection()
        getSharedPreferences("omnihub_shizuku", MODE_PRIVATE).edit().putString("last_path", cwd).apply()
        pathLabel.text = cwd
        if (ShizukuHelper.service != null) load() else refreshStatus()
    }

    private fun goUp(): Boolean {
        if (cwd == "/") return false
        goTo(cwd.substringBeforeLast('/', "").ifEmpty { "/" }); return true
    }

    override fun onBackPressed() {
        if (selected.isNotEmpty()) clearSelection()
        else if (cwd != storage && cwd != "/" && goUp()) { }
        else finish()
    }

    private fun load() {
        if (ShizukuHelper.service == null) { swipe.isRefreshing = false; return }
        val token = ++loadToken
        val dir = cwd
        swipe.isRefreshing = true
        Thread {
            val result = try { Result.success(ShizukuHelper.list(dir)) } catch (t: Throwable) { Result.failure(t) }
            ui.post {
                if (token != loadToken || isFinishing || isDestroyed) return@post
                swipe.isRefreshing = false
                result.onSuccess { list ->
                    entries = list.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase(Locale.ROOT) }))
                    selected.retainAll(entries.map { path(it.name) }.toSet())
                    adapter.notifyDataSetChanged(); updateSelection()
                    emptyLabel.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
                    emptyLabel.text = "This folder is empty"
                }.onFailure {
                    entries = emptyList(); adapter.notifyDataSetChanged()
                    emptyLabel.visibility = View.VISIBLE
                    emptyLabel.text = "Cannot open this folder:\n${it.message}"
                }
                pathLabel.text = cwd + (if (ShizukuHelper.isRoot()) "   · root" else "   · adb shell")
            }
        }.start()
    }

    private fun promptPath() {
        val input = EditText(this).apply { setText(cwd); setSingleLine(true); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Go to path").setView(input)
            .setPositiveButton("Go") { _, _ -> input.text.toString().trim().ifEmpty { null }?.let { goTo(if (it.length > 1) it.trimEnd('/') else it) } }
            .setNegativeButton("Cancel", null).show()
    }

    // ----------------------------------------------------------------------------------- selection

    private fun onTap(e: ShizukuHelper.Entry) {
        val p = path(e.name)
        if (selected.isNotEmpty()) { toggle(e); return }
        if (e.isDir) goTo(p) else showFileMenu(e)
    }

    private fun toggle(e: ShizukuHelper.Entry) {
        val p = path(e.name)
        if (!selected.add(p)) selected.remove(p)
        updateSelection()
    }

    private fun clearSelection() { selected.clear(); updateSelection() }

    private fun updateSelection() {
        selectionBar.visibility = if (selected.isEmpty()) View.GONE else View.VISIBLE
        selectionLabel.text = "${selected.size} selected"
        pasteButton.visibility = if (clipboard.isEmpty()) View.GONE else View.VISIBLE
        pasteButton.text = "Paste (${clipboard.size})"
        adapter.notifyDataSetChanged()
    }

    private fun setClipboard(move: Boolean) {
        clipboard = selected.toList(); clipMove = move
        toast(if (move) "Cut ${clipboard.size} item(s) — open a folder and tap Paste" else "Copied ${clipboard.size} item(s) — open a folder and tap Paste")
        clearSelection()
    }

    // ------------------------------------------------------------------------------------ operations

    private fun work(title: String, job: () -> String?) {
        val dialog = AlertDialog.Builder(this).setTitle(title).setMessage("Working…").setCancelable(false).create()
        dialog.show()
        Thread {
            val error = try { job() } catch (t: Throwable) { t.message ?: t.javaClass.simpleName }
            ui.post {
                try { dialog.dismiss() } catch (_: Throwable) { }
                if (error != null) toast(error)
                if (!isFinishing && !isDestroyed) load()
            }
        }.start()
    }

    private fun uniqueTarget(name: String): String {
        if (!ShizukuHelper.exists(path(name))) return path(name)
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var n = 1
        while (ShizukuHelper.exists(path("$base ($n)$ext"))) n++
        return path("$base ($n)$ext")
    }

    private fun paste() {
        if (!ready() || clipboard.isEmpty()) return
        val items = clipboard; val move = clipMove
        work(if (move) "Moving" else "Copying") {
            var failed = 0
            for (src in items) {
                val name = src.substringAfterLast('/')
                if (move && src.substringBeforeLast('/', "").ifEmpty { "/" } == cwd) continue
                if (cwd == src || cwd.startsWith("$src/")) { failed++; continue }
                val target = uniqueTarget(name)
                val ok = if (move) ShizukuHelper.rename(src, target) else ShizukuHelper.copy(src, target)
                if (!ok) failed++
            }
            if (move) clipboard = emptyList()
            ui.post { updateSelection() }
            if (failed > 0) "$failed item(s) failed" else null
        }
    }

    private fun confirmDelete(paths: List<String>) {
        if (paths.isEmpty() || !ready()) return
        AlertDialog.Builder(this).setTitle("Delete ${paths.size} item(s)?")
            .setMessage("This permanently deletes the selected items and everything inside folders.\n\n" + paths.take(5).joinToString("\n") { it.substringAfterLast('/') } + if (paths.size > 5) "\n…" else "")
            .setPositiveButton("Delete") { _, _ ->
                work("Deleting") {
                    var failed = 0
                    paths.forEach { if (!ShizukuHelper.delete(it)) failed++ }
                    ui.post { clearSelection() }
                    if (failed > 0) "$failed item(s) could not be deleted" else null
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun promptRename(p: String) {
        val input = EditText(this).apply { setText(p.substringAfterLast('/')); setSingleLine(true); setSelection(0, text.length) }
        AlertDialog.Builder(this).setTitle("Rename").setView(input).setPositiveButton("Rename") { _, _ ->
            val n = input.text.toString().trim()
            if (n.isEmpty() || n.contains('/')) { toast("Invalid name"); return@setPositiveButton }
            val target = p.substringBeforeLast('/', "") + "/" + n
            work("Renaming") {
                if (ShizukuHelper.exists(target)) "A file with that name already exists"
                else if (ShizukuHelper.rename(p, target)) null
                else "Rename failed"
            }
            clearSelection()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun promptNew(folder: Boolean) {
        if (!ready()) return
        val input = EditText(this).apply { hint = if (folder) "Folder name" else "File name"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle(if (folder) "New folder" else "New file").setView(input).setPositiveButton("Create") { _, _ ->
            val n = input.text.toString().trim()
            if (n.isEmpty() || n.contains('/')) { toast("Invalid name"); return@setPositiveButton }
            val target = path(n)
            work("Creating") {
                if (ShizukuHelper.exists(target)) "Already exists"
                else if (folder) { if (ShizukuHelper.mkdirs(target)) null else "Could not create folder" }
                else { ShizukuHelper.writeText(target, ""); null }
            }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun showInfo(p: String) {
        Thread {
            val r = try { ShizukuHelper.exec("ls -ldZ ${ShizukuHelper.quote(p)} 2>&1; echo; du -sh ${ShizukuHelper.quote(p)} 2>&1").second } catch (t: Throwable) { t.message ?: "error" }
            ui.post { showText("Properties", "$p\n\n$r") }
        }.start()
    }

    private fun showText(title: String, text: String) {
        val tv = TextView(this).apply { this.text = text; typeface = Typeface.MONOSPACE; textSize = 12f; setTextIsSelectable(true); setPadding(dp(20), dp(10), dp(20), dp(10)) }
        AlertDialog.Builder(this).setTitle(title).setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(title, text)); toast("Copied")
            }.show()
    }

    private fun promptShell() {
        if (!ready()) return
        val input = EditText(this).apply { hint = "Command (runs in this folder)"; typeface = Typeface.MONOSPACE; setSingleLine(false); minLines = 2; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS }
        AlertDialog.Builder(this).setTitle("Run as ${if (ShizukuHelper.isRoot()) "root" else "shell (adb)"}").setView(input)
            .setPositiveButton("Run") { _, _ ->
                val cmd = input.text.toString().trim()
                if (cmd.isEmpty()) return@setPositiveButton
                Thread {
                    val out = try { val r = ShizukuHelper.exec("cd ${ShizukuHelper.quote(cwd)} && $cmd"); (if (r.second.isBlank()) "(no output)" else r.second) + "\n[exit ${r.first}]" } catch (t: Throwable) { t.message ?: "error" }
                    ui.post { showText("$ $cmd", out); load() }
                }.start()
            }.setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------------------------------------- file menu

    private fun mimeFor(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase(Locale.ROOT)) ?: "*/*"

    private fun showFileMenu(e: ShizukuHelper.Entry) {
        val p = path(e.name)
        val labels = arrayListOf("Open with…", "Edit as text", "Share", "Save copy to Download", "Rename", "Delete", "Properties")
        AlertDialog.Builder(this).setTitle(e.name).setItems(labels.toTypedArray()) { _, which ->
            when (which) {
                0 -> pullAndThen(e) { MediaShare.openWithOtherApp(this, Uri.fromFile(it), mimeFor(e.name)) }
                1 -> editText(p, e)
                2 -> pullAndThen(e) { MediaShare.share(this, Uri.fromFile(it), mimeFor(e.name)) }
                3 -> work("Saving copy") {
                    val dl = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), e.name)
                    val target = if (dl.exists()) File(dl.parentFile, "${e.name.substringBeforeLast('.')}_${System.currentTimeMillis()}.${e.name.substringAfterLast('.', "bin")}") else dl
                    ShizukuHelper.pullToLocal(p, target); toastUi("Saved to Download/${target.name}"); null
                }
                4 -> promptRename(p)
                5 -> confirmDelete(listOf(p))
                6 -> showInfo(p)
            }
        }.show()
    }

    private fun pullAndThen(e: ShizukuHelper.Entry, then: (File) -> Unit) {
        val tmp = File(cacheDir, "shizuku_open/${e.name}")
        work("Preparing file") {
            tmp.parentFile?.deleteRecursively()
            ShizukuHelper.pullToLocal(path(e.name), tmp)
            ui.post { then(tmp) }
            null
        }
    }

    private fun editText(p: String, e: ShizukuHelper.Entry) {
        if (e.size > 1_000_000) { toast("File is too large to edit (limit 1 MB)"); return }
        Thread {
            val text = try { ShizukuHelper.readText(p) } catch (t: Throwable) { ui.post { toast(t.message ?: "Cannot read file") }; return@Thread }
            ui.post {
                val input = EditText(this).apply {
                    setText(text); typeface = Typeface.MONOSPACE; textSize = 12f; gravity = Gravity.TOP or Gravity.START
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    setHorizontallyScrolling(false)
                }
                AlertDialog.Builder(this).setTitle(e.name).setView(ScrollView(this).apply { addView(input) })
                    .setPositiveButton("Save") { _, _ -> work("Saving") { ShizukuHelper.writeText(p, input.text.toString()); null } }
                    .setNegativeButton("Cancel", null).show()
            }
        }.start()
    }

    private fun showPackageMenu(e: ShizukuHelper.Entry) {
        val pkg = e.name
        val labels = arrayOf("Open folder", "App info", "Force stop", "Clear app data (pm clear)", "Uninstall (pm uninstall)")
        AlertDialog.Builder(this).setTitle(pkg).setItems(labels) { _, which ->
            when (which) {
                0 -> goTo(path(e.name))
                1 -> try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) } catch (_: Exception) { toast("App not installed") }
                2 -> runPm("Force stop $pkg", "am force-stop ${ShizukuHelper.quote(pkg)}")
                3 -> confirmPm("Clear all data of $pkg?", "pm clear ${ShizukuHelper.quote(pkg)}")
                4 -> confirmPm("Uninstall $pkg?", "pm uninstall ${ShizukuHelper.quote(pkg)}")
            }
        }.show()
    }

    private fun confirmPm(msg: String, cmd: String) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Yes") { _, _ -> runPm(msg, cmd) }.setNegativeButton("Cancel", null).show()
    }

    private fun runPm(title: String, cmd: String) {
        if (!ready()) return
        work(title) { val r = ShizukuHelper.exec(cmd); toastUi(r.second.trim().ifBlank { if (r.first == 0) "Done" else "Failed" }); null }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun toastUi(m: String) { ui.post { toast(m) } }

    // --------------------------------------------------------------------------------------- adapter

    private inner class RowsAdapter : BaseAdapter() {
        override fun getCount() = entries.size
        override fun getItem(position: Int) = entries[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val e = entries[position]
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@ShizukuFileActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
                addView(TextView(context).apply { textSize = 22f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(40), -2))
                val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
                col.addView(TextView(context).apply { setTextColor(white); textSize = 14f; maxLines = 2 })
                col.addView(TextView(context).apply { setTextColor(muted); textSize = 11f })
                addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                val more = TextView(context).apply { text = "⋮"; textSize = 22f; setTextColor(muted); setPadding(dp(14), 0, dp(8), 0) }
                addView(more)
            }
            val icon = row.getChildAt(0) as TextView
            val col = row.getChildAt(1) as LinearLayout
            val more = row.getChildAt(2) as TextView
            icon.text = if (e.isDir) "📁" else "📄"
            (col.getChildAt(0) as TextView).text = e.name + if (e.link) "  →" else ""
            val date = if (e.mtime > 0) DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(e.mtime)) else ""
            (col.getChildAt(1) as TextView).text = listOf(if (e.isDir) "Folder" else formatSize(e.size), date).filter { it.isNotEmpty() }.joinToString("  ·  ")
            row.setBackgroundColor(if (path(e.name) in selected) Color.argb(70, 98, 228, 211) else Color.TRANSPARENT)
            more.setOnClickListener {
                val inApps = e.isDir && (cwd == "$storage/Android/data" || cwd == "$storage/Android/obb" || cwd == "$storage/Android/media")
                if (inApps) showPackageMenu(e) else if (e.isDir) showDirMenu(e) else showFileMenu(e)
            }
            return row
        }
    }

    private fun showDirMenu(e: ShizukuHelper.Entry) {
        val p = path(e.name)
        AlertDialog.Builder(this).setTitle(e.name).setItems(arrayOf("Open", "Copy", "Cut", "Rename", "Delete", "Properties")) { _, w ->
            when (w) {
                0 -> goTo(p)
                1 -> { clipboard = listOf(p); clipMove = false; updateSelection(); toast("Copied — open a folder and tap Paste") }
                2 -> { clipboard = listOf(p); clipMove = true; updateSelection(); toast("Cut — open a folder and tap Paste") }
                3 -> promptRename(p)
                4 -> confirmDelete(listOf(p))
                5 -> showInfo(p)
            }
        }.show()
    }

    private fun formatSize(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }
}
