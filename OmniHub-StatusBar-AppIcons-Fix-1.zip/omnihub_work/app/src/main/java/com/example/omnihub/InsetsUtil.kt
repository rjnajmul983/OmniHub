package com.example.omnihub

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.view.View
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Consistent Android 15/16 edge-to-edge configuration and system bar/cutout insets. */
object InsetsUtil {
    data class Values(val left: Int, val top: Int, val right: Int, val bottom: Int)

    fun configureWindow(activity: Activity) {
        // Edge-to-edge layout with solid status bar so system icons stay clear and
        // scrolled content never visually enters the notification/status bar region.
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        activity.window.statusBarColor = Color.rgb(242, 240, 247)
        activity.window.navigationBarColor = Color.rgb(252, 251, 254)
        if (Build.VERSION.SDK_INT >= 29) {
            activity.window.isStatusBarContrastEnforced = false
            activity.window.isNavigationBarContrastEnforced = false
        }
        WindowInsetsControllerCompat(activity.window, activity.window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
    }

    /** Pads a native content root by system bars + display cutout while preserving its existing padding. */
    fun apply(activity: Activity, root: View, onInsets: ((Values) -> Unit)? = null) {
        configureWindow(activity)
        val baseLeft = root.paddingLeft
        val baseTop = root.paddingTop
        val baseRight = root.paddingRight
        val baseBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val values = Values(insets.left, insets.top, insets.right, insets.bottom)
            view.setPadding(baseLeft + insets.left, baseTop + insets.top, baseRight + insets.right, baseBottom + insets.bottom)
            onInsets?.invoke(values)
            windowInsets
        }
        ViewCompat.requestApplyInsets(root)
    }

    /**
     * WebView variant. On Android 15+ (targetSdk 35) edge-to-edge is enforced, so the page is always
     * drawn under the status/navigation bars. Instead of fighting that, send the REAL inset sizes
     * (in CSS px) to the page so its own layout (.app padding, hero gradient) clears the bars.
     */
    fun applyWebView(activity: Activity, root: View, onCssScript: (String) -> Unit) {
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        // Transparent so the fixed CSS shield / purple hero can own the status-bar region.
        // Content is still padded by --sat so nothing important sits under the system icons.
        activity.window.statusBarColor = Color.TRANSPARENT
        activity.window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            activity.window.isStatusBarContrastEnforced = false
            activity.window.isNavigationBarContrastEnforced = false
        }
        setStatusBarIcons(activity, lightBackground = false) // home hero is purple -> white icons
        val density = activity.resources.displayMetrics.density.coerceAtLeast(0.1f)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, windowInsets ->
            val bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = windowInsets.getInsets(WindowInsetsCompat.Type.ime())
            fun css(px: Int) = String.format(java.util.Locale.US, "%.2fpx", px / density)
            val bottom = maxOf(bars.bottom, ime.bottom)
            val script = "(function(){var s=document.documentElement.style;" +
                "s.setProperty('--sat','${css(bars.top)}');s.setProperty('--sab','${css(bottom)}');" +
                "s.setProperty('--sal','${css(bars.left)}');s.setProperty('--sar','${css(bars.right)}');" +
                "if(typeof window.__omniUpdateHomeTop==='function')window.__omniUpdateHomeTop();})();"
            onCssScript(script)
            windowInsets
        }
        ViewCompat.requestApplyInsets(root)
    }

    /** lightBackground=true -> dark status/nav icons; false -> white icons (for dark/colored headers). */
    fun setStatusBarIcons(activity: Activity, lightBackground: Boolean) {
        WindowInsetsControllerCompat(activity.window, activity.window.decorView).apply {
            isAppearanceLightStatusBars = lightBackground
            isAppearanceLightNavigationBars = true
        }
    }

    /** For overlays such as a media player: keep media content edge-to-edge and inset only its controls. */
    fun applyOverlay(activity: Activity, root: View, callback: (Values) -> Unit) {
        configureWindow(activity)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, windowInsets ->
            val i = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            callback(Values(i.left, i.top, i.right, i.bottom))
            windowInsets
        }
        ViewCompat.requestApplyInsets(root)
    }
}
