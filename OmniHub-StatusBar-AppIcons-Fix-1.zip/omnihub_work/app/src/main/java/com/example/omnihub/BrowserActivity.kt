package com.example.omnihub

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.http.SslError
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/** Untrusted websites are displayed here without any Android JavaScript bridge. */
class BrowserActivity : Activity() {
    private lateinit var browser: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.rgb(242, 240, 247)
        val ink = Color.rgb(37, 34, 47)
        val muted = Color.rgb(94, 88, 112)
        window.statusBarColor = bg
        window.navigationBarColor = Color.rgb(252, 251, 254)
        if (android.os.Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(8)) }
        val back = Button(this).apply { text = "‹"; textSize = 24f; minWidth = dp(44); setOnClickListener { finish() } }
        address = EditText(this).apply {
            hint = "Search or enter website"
            setSingleLine(true)
            textSize = 14f
            setTextColor(ink)
            setHintTextColor(muted)
            setSelectAllOnFocus(false)
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(Color.rgb(252, 251, 254))
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(225, 229, 237))
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == android.view.inputmethod.EditorInfo.IME_ACTION_GO) { navigateFromAddress(); true } else false
            }
        }
        val go = Button(this).apply { text = "Go"; setOnClickListener { navigateFromAddress() } }
        top.addView(back, LinearLayout.LayoutParams(dp(42), dp(48)))
        top.addView(HomeNavigation.makeHomeButton(this), LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(6) })
        top.addView(address, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), 0, dp(6), 0) })
        top.addView(go, LinearLayout.LayoutParams(dp(60), dp(48)))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; this.progress = 0 }
        browser = WebView(this).apply {
            setBackgroundColor(Color.rgb(252, 251, 254))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (android.os.Build.VERSION.SDK_INT >= 26) settings.safeBrowsingEnabled = true
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    this@BrowserActivity.progress.progress = newProgress
                    this@BrowserActivity.progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
                }
                override fun onReceivedTitle(view: WebView, title: String?) { if (!title.isNullOrBlank()) this@BrowserActivity.title = title }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val scheme = request.url.scheme?.lowercase()
                    return scheme != "http" && scheme != "https"
                }
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    if (url != null) address.setText(url)
                }
                override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                    handler.cancel()
                }
            }
        }
        root.addView(top)
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(2)))
        root.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        InsetsUtil.apply(this, root)
        if (android.os.Build.VERSION.SDK_INT >= 23) androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply { isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true }
        browser.loadUrl(safeUrl(intent.getStringExtra("url") ?: "https://www.google.com"))
    }

    private fun navigateFromAddress() {
        val url = safeUrl(address.text?.toString().orEmpty())
        if (url.isBlank()) return
        browser.loadUrl(url)
    }

    private fun safeUrl(input: String): String {
        val text = input.trim()
        if (text.isEmpty()) return "https://www.google.com"
        if (text.contains(' ') || !text.contains('.') && !text.startsWith("http", true)) {
            return "https://www.google.com/search?q=" + Uri.encode(text)
        }
        val normalized = if (text.startsWith("https://", true) || text.startsWith("http://", true)) text else "https://$text"
        val scheme = Uri.parse(normalized).scheme?.lowercase()
        return if (scheme == "https" || scheme == "http") normalized else "https://www.google.com"
    }

    @Deprecated("Compatibility fallback")
    override fun onBackPressed() {
        if (::browser.isInitialized && browser.canGoBack()) browser.goBack() else super.onBackPressed()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (::browser.isInitialized) { browser.stopLoading(); browser.loadUrl("about:blank"); browser.destroy() }
        super.onDestroy()
    }
}
