package com.example.omnihub

import java.io.File

/**
 * Process-wide clipboard for Copy / Move / Extract. It survives Back navigation and leaving the File Manager,
 * so the user can pick files, browse to ANY folder and paste there.
 */
object FileClipboard {
    enum class Op { COPY, MOVE, EXTRACT, ARCHIVE_ENTRIES }

    @Volatile var files: List<File> = emptyList(); private set
    @Volatile var op: Op = Op.COPY; private set

    /** Items copied out of inside an archive (paste = extract them into the current folder). */
    @Volatile var archiveEntries: Set<String> = emptySet(); private set
    @Volatile var archivePassword: String? = null; private set

    val hasItems: Boolean get() = files.isNotEmpty()

    fun set(list: List<File>, operation: Op) {
        files = list.distinctBy { it.absolutePath }
        op = operation
        archiveEntries = emptySet(); archivePassword = null
    }

    fun setArchiveEntries(archive: File, entries: Set<String>, password: String?) {
        files = listOf(archive); op = Op.ARCHIVE_ENTRIES
        archiveEntries = entries.toSet(); archivePassword = password
    }

    fun clear() { files = emptyList(); archiveEntries = emptySet(); archivePassword = null }

    fun summary(): String {
        val n = files.size
        val what = if (n == 1) files.first().name else "$n items"
        if (op == Op.ARCHIVE_ENTRIES) {
            val names = archiveEntries.map { it.trimEnd('/').substringAfterLast('/') }
            val shown = if (names.size <= 2) names.joinToString(", ") else "${names.size} items"
            return "Copy · $shown (from ${files.firstOrNull()?.name ?: "archive"})"
        }
        return when (op) { Op.COPY -> "Copy · $what"; Op.MOVE -> "Move · $what"; Op.EXTRACT -> "Extract · $what"; else -> what }
    }
}
