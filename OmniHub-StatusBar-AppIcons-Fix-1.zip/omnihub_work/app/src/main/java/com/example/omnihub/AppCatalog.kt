package com.example.omnihub

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.util.Locale

/** Installed-app list, icons and static app shortcuts for the Home app drawer. */
object AppCatalog {
    private val iconCache = object : LruCache<String, String>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: String): Int = value.length
    }
    private val shortcutCache = HashMap<String, Map<String, Intent>>()

    fun list(ctx: Context): JSONArray {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val rows = ArrayList<Pair<String, String>>()
        for (ri in pm.queryIntentActivities(query, 0)) {
            val pkg = ri.activityInfo?.packageName ?: continue
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val label = try { ri.loadLabel(pm).toString() } catch (_: Exception) { pkg }
            rows.add(pkg to label)
        }
        rows.sortBy { it.second.lowercase(Locale.ROOT) }
        val arr = JSONArray()
        for (r in rows) arr.put(JSONObject().put("p", r.first).put("l", r.second))
        return arr
    }

    fun icon(ctx: Context, pkg: String): String? {
        val hit = iconCache.get(pkg)
        if (hit != null) return if (hit.isEmpty()) null else hit
        val enc = try {
            val bmp = ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96, Bitmap.Config.ARGB_8888)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (_: Throwable) { null }
        iconCache.put(pkg, enc ?: "")
        return enc
    }

    /** Static (manifest-declared) shortcuts. Dynamic shortcuts are only visible to the default launcher. */
    fun shortcuts(ctx: Context, pkg: String): JSONArray {
        val out = JSONArray()
        val map = LinkedHashMap<String, Intent>()
        try {
            val pm = ctx.packageManager
            val comp = pm.getLaunchIntentForPackage(pkg)?.component
            if (comp != null) {
                val info = pm.getActivityInfo(comp, PackageManager.GET_META_DATA)
                val resId = info.metaData?.getInt("android.app.shortcuts", 0) ?: 0
                if (resId != 0) {
                    val res = pm.getResourcesForApplication(pkg)
                    val ns = "http://schemas.android.com/apk/res/android"
                    val xml = res.getXml(resId)
                    var inShortcut = false
                    var id = ""
                    var label = ""
                    var enabled = true
                    var intent: Intent? = null
                    var ev = xml.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG) {
                            if (xml.name == "shortcut") {
                                inShortcut = true
                                intent = null
                                id = xml.getAttributeValue(ns, "shortcutId") ?: ""
                                enabled = xml.getAttributeBooleanValue(ns, "enabled", true)
                                val rid = xml.getAttributeResourceValue(ns, "shortcutShortLabel", 0)
                                label = if (rid != 0) res.getString(rid) else (xml.getAttributeValue(ns, "shortcutShortLabel") ?: "")
                            } else if (xml.name == "intent" && inShortcut && intent == null) {
                                val action = xml.getAttributeValue(ns, "action")
                                val tp = xml.getAttributeValue(ns, "targetPackage")
                                val tc = xml.getAttributeValue(ns, "targetClass")
                                val data = xml.getAttributeValue(ns, "data")
                                val i = Intent(action ?: Intent.ACTION_VIEW)
                                if (!tc.isNullOrEmpty()) i.setClassName(if (tp.isNullOrEmpty()) pkg else tp, tc)
                                else if (!tp.isNullOrEmpty()) i.setPackage(tp)
                                if (!data.isNullOrEmpty()) i.data = Uri.parse(data)
                                intent = i
                            }
                        } else if (ev == XmlPullParser.END_TAG && xml.name == "shortcut") {
                            val ready = intent
                            if (inShortcut && enabled && id.isNotEmpty() && label.isNotBlank() && ready != null && map.size < 5) map[id] = ready
                            inShortcut = false
                        }
                        ev = xml.next()
                    }
                }
            }
        } catch (_: Throwable) { }
        synchronized(shortcutCache) { shortcutCache[pkg] = map }
        return labels(ctx, pkg, map.keys)
    }

    private fun labels(ctx: Context, pkg: String, ids: Set<String>): JSONArray {
        val out = JSONArray()
        if (ids.isEmpty()) return out
        try {
            val pm = ctx.packageManager
            val comp = pm.getLaunchIntentForPackage(pkg)?.component ?: return out
            val resId = pm.getActivityInfo(comp, PackageManager.GET_META_DATA).metaData?.getInt("android.app.shortcuts", 0) ?: 0
            val res = pm.getResourcesForApplication(pkg)
            val ns = "http://schemas.android.com/apk/res/android"
            val xml = res.getXml(resId)
            var ev = xml.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && xml.name == "shortcut") {
                    val id = xml.getAttributeValue(ns, "shortcutId") ?: ""
                    if (id in ids) {
                        val rid = xml.getAttributeResourceValue(ns, "shortcutShortLabel", 0)
                        val label = if (rid != 0) res.getString(rid) else (xml.getAttributeValue(ns, "shortcutShortLabel") ?: "")
                        out.put(JSONObject().put("id", id).put("l", label))
                    }
                }
                ev = xml.next()
            }
        } catch (_: Throwable) { }
        return out
    }

    fun launchShortcut(ctx: Context, pkg: String, id: String): Boolean {
        val src = synchronized(shortcutCache) { shortcutCache[pkg]?.get(id) } ?: return false
        return try {
            ctx.startActivity(Intent(src).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (_: Exception) { false }
    }
}
