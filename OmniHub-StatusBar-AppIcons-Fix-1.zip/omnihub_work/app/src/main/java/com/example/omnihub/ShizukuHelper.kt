package com.example.omnihub

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.IBinder
import android.os.Parcel
import android.os.ParcelFileDescriptor
import rikka.shizuku.Shizuku
import java.io.File
import java.io.IOException
import java.util.concurrent.CopyOnWriteArrayList

/** App-side access to the Shizuku file service (browse / modify protected folders such as Android/data). */
object ShizukuHelper {
    const val PACKAGE = "moe.shizuku.privileged.api"
    const val PERMISSION_REQUEST = 4711

    data class Entry(val name: String, val isDir: Boolean, val size: Long, val mtime: Long, val link: Boolean)

    @Volatile var service: IBinder? = null
        private set
    private var bindArgs: Shizuku.UserServiceArgs? = null
    private var binding = false
    val changeListeners = CopyOnWriteArrayList<() -> Unit>()

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) { service = binder; binding = false; changeListeners.forEach { it() } }
        override fun onServiceDisconnected(name: ComponentName?) { service = null; binding = false; changeListeners.forEach { it() } }
    }

    fun installed(ctx: Context): Boolean = try { ctx.packageManager.getPackageInfo(PACKAGE, 0); true } catch (_: Throwable) { false }
    fun running(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    fun permitted(): Boolean = try { !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
    fun deniedForever(): Boolean = try { Shizuku.shouldShowRequestPermissionRationale() } catch (_: Throwable) { false }
    fun requestPermission() { try { Shizuku.requestPermission(PERMISSION_REQUEST) } catch (_: Throwable) { } }
    fun isRoot(): Boolean = try { Shizuku.getUid() == 0 } catch (_: Throwable) { false }

    fun openShizukuApp(ctx: Context): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return false
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
    fun openDownloadPage(ctx: Context) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Starts (or reuses) the file service inside Shizuku's process. */
    fun bind(ctx: Context) {
        if (service != null || binding || !running() || !permitted()) return
        try {
            val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShizukuFileService::class.java.name))
                .processNameSuffix("files").daemon(false).debuggable(false).version(1)
            bindArgs = args
            binding = true
            Shizuku.bindUserService(args, connection)
        } catch (_: Throwable) { binding = false }
    }

    fun unbind() {
        try { bindArgs?.let { Shizuku.unbindUserService(it, connection, true) } } catch (_: Throwable) { }
        service = null; binding = false
    }

    // ---- transport -------------------------------------------------------------------------------------------

    private fun <T> tx(code: Int, write: (Parcel) -> Unit, read: (Parcel) -> T): T {
        val b = service ?: throw IOException("Shizuku service is not connected")
        val d = Parcel.obtain(); val r = Parcel.obtain()
        try {
            write(d)
            b.transact(code, d, r, 0)
            if (r.readInt() != 0) throw IOException(r.readString() ?: "Shizuku operation failed")
            return read(r)
        } finally { d.recycle(); r.recycle() }
    }

    private fun pfd(p: Parcel): ParcelFileDescriptor = ParcelFileDescriptor.CREATOR.createFromParcel(p)

    // ---- operations (call from a background thread) ----------------------------------------------------------

    fun list(path: String): List<Entry> {
        val p = tx(ShizukuFileService.LIST, { it.writeString(path) }) { pfd(it) }
        val lines = ParcelFileDescriptor.AutoCloseInputStream(p).bufferedReader().readLines()
        return lines.mapNotNull { l ->
            val a = l.split(ShizukuFileService.SEP, limit = 5)
            if (a.size < 5) null else Entry(a[4], a[0] == "d", a[1].toLongOrNull() ?: 0, a[2].toLongOrNull() ?: 0, a[3] == "1")
        }
    }

    private fun flag(code: Int, vararg args: String): Boolean = tx(code, { d -> args.forEach { d.writeString(it) } }) { it.readInt() == 1 }

    fun mkdirs(path: String) = flag(ShizukuFileService.MKDIRS, path)
    fun delete(path: String) = flag(ShizukuFileService.DELETE, path)
    fun rename(from: String, to: String) = flag(ShizukuFileService.RENAME, from, to)
    fun copy(from: String, to: String) = flag(ShizukuFileService.COPY, from, to)

    fun exists(path: String): Boolean = tx(ShizukuFileService.STAT, { it.writeString(path) }) { it.readInt() == 1 }
    fun size(path: String): Long = tx(ShizukuFileService.STAT, { it.writeString(path) }) { it.readInt(); it.readInt(); it.readLong() }

    fun exec(cmd: String): Pair<Int, String> =
        tx(ShizukuFileService.EXEC, { it.writeString(cmd) }) { val c = it.readInt(); c to (it.readString() ?: "") }

    fun open(path: String, mode: String): ParcelFileDescriptor =
        tx(ShizukuFileService.OPEN, { it.writeString(path); it.writeString(mode) }) { pfd(it) }

    fun readText(path: String, limit: Int = 1_000_000): String =
        ParcelFileDescriptor.AutoCloseInputStream(open(path, "r")).use { ins ->
            val buf = ByteArray(limit); var n = 0
            while (n < limit) { val r = ins.read(buf, n, limit - n); if (r < 0) break; n += r }
            String(buf, 0, n, Charsets.UTF_8)
        }

    fun writeText(path: String, text: String) {
        ParcelFileDescriptor.AutoCloseOutputStream(open(path, "w")).use { it.write(text.toByteArray(Charsets.UTF_8)) }
    }

    fun pullToLocal(path: String, dest: File) {
        dest.parentFile?.mkdirs()
        ParcelFileDescriptor.AutoCloseInputStream(open(path, "r")).use { ins -> dest.outputStream().use { ins.copyTo(it) } }
    }

    fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"
}
