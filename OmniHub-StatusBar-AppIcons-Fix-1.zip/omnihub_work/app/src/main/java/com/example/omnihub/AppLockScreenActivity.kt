package com.example.omnihub

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.security.MessageDigest
import java.util.concurrent.Executor

class AppLockScreenActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("omnihub_app_locker", MODE_PRIVATE) }
    private val bg = Color.rgb(11, 16, 32); private val accent = Color.rgb(98, 228, 211); private val white = Color.rgb(244,247,255)
    private var lockedPackage = ""
    private var unlocked = false
    // Set when OmniHub itself opened this screen before launching a protected app (the app starts only after unlock).
    private var launchAfter = false
    private var shortcutId = ""
    private var cancelSignal: CancellationSignal? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lockedPackage = intent.getStringExtra("locked_package").orEmpty()
        launchAfter = intent.getBooleanExtra("launch_after_unlock", false)
        shortcutId = intent.getStringExtra("launch_shortcut_id").orEmpty()
        overridePendingTransition(0, 0)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(28), dp(24), dp(28), dp(24)); setBackgroundColor(bg) }
        val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(lockedPackage, 0)).toString() } catch (_: Exception) { "Protected app" }
        root.addView(TextView(this).apply { text = "🔒"; textSize = 52f; gravity = Gravity.CENTER; setTextColor(white) }, LinearLayout.LayoutParams(-1, dp(78)))
        root.addView(TextView(this).apply { text = "Unlock $appName"; textSize = 23f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; setTextColor(white) }, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(TextView(this).apply { text = "Enter your OmniHub App Locker PIN"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY) }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(Button(this).apply { text = "Enter PIN"; isAllCaps = false; setOnClickListener { promptPin() } }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })
        if (Build.VERSION.SDK_INT >= 28) root.addView(Button(this).apply { text = "Use fingerprint / biometrics"; isAllCaps = false; setOnClickListener { biometric() } }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        root.addView(Button(this).apply { text = "Open OmniHub App Locker"; isAllCaps = false; setOnClickListener { startActivity(Intent(this@AppLockScreenActivity, AppLockerActivity::class.java)) } }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(20) })
        setContentView(root)
        InsetsUtil.apply(this, root)
        if (!prefs.getString("pin_hash", null).isNullOrBlank() && Build.VERSION.SDK_INT >= 28) root.post { biometric() }
        if (prefs.getString("pin_hash", null).isNullOrBlank()) {
            AlertDialog.Builder(this).setTitle("PIN not configured").setMessage("Open OmniHub App Locker and set a PIN before protecting apps.").setPositiveButton("Open settings") { _, _ -> startActivity(Intent(this, AppLockerActivity::class.java)) }.setNegativeButton("Close") { _, _ -> finish() }.show()
        }
    }
    private fun promptPin() {
        val input = EditText(this).apply { hint = "PIN"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Unlock app").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Unlock") { _, _ ->
            val expected = prefs.getString("pin_hash", null)
            val actual = hash(input.text.toString())
            if (!expected.isNullOrBlank() && expected == actual) unlock() else Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
        }.show()
    }
    private fun biometric() {
        if (Build.VERSION.SDK_INT < 28) return
        try {
            val prompt = BiometricPrompt.Builder(this).setTitle("Unlock protected app").setSubtitle("Authenticate to continue").setNegativeButton("Use PIN", mainExecutor) { _, _ -> promptPin() }.build()
            try { cancelSignal?.cancel() } catch (_: Exception) { }
            val signal = CancellationSignal()
            cancelSignal = signal
            prompt.authenticate(signal, mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { runOnUiThread { unlock() } }
                override fun onAuthenticationFailed() { runOnUiThread { Toast.makeText(this@AppLockScreenActivity, "Biometric not recognized", Toast.LENGTH_SHORT).show() } }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) { runOnUiThread { if (errorCode != 13 && errorCode != 5 && errorCode != 10) Toast.makeText(this@AppLockScreenActivity, errString ?: "Authentication cancelled", Toast.LENGTH_SHORT).show() } }
            })
        } catch (_: Exception) { Toast.makeText(this, "Biometrics are not available; use PIN", Toast.LENGTH_LONG).show() }
    }
    private fun unlock() {
        if (unlocked) return
        unlocked = true
        try { cancelSignal?.cancel() } catch (_: Exception) { }
        // The unlocked session lives in memory only and ends as soon as the user leaves the protected app.
        AppLockState.markUnlocked(lockedPackage)
        if (launchAfter) AppLockState.grant(lockedPackage)
        if (launchAfter) {
            // Opened from OmniHub: the protected app starts only now, so it is never visible before unlocking.
            try {
                if (shortcutId.isNotBlank()) { if (!AppCatalog.launchShortcut(this, lockedPackage, shortcutId)) launchPlain() } else launchPlain()
            } catch (_: Exception) { }
            window.decorView.postDelayed({ finish() }, 350)
        } else {
            // Unlocked while the protected app was already open underneath: bring that app's task back to the front
            // (otherwise Android can leave OmniHub on screen instead of the app the user opened).
            try { launchPlain() } catch (_: Exception) { }
            finish()
        }
    }

    private fun launchPlain() {
        packageManager.getLaunchIntentForPackage(lockedPackage)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    // Back must never reveal the protected app underneath: send the user to the home screen instead.
    private fun goHome() {
        try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        finish()
    }

    @Deprecated("Handled for broad Android project compatibility")
    override fun onBackPressed() { if (launchAfter) finish() else goHome() }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val newPkg = intent?.getStringExtra("locked_package").orEmpty()
        // Already unlocked, or this same app is already being unlocked right now: do not restart anything.
        if (newPkg.isNotBlank() && AppLockState.isUnlocked(newPkg)) return
        if (!unlocked && newPkg == lockedPackage && intent?.getBooleanExtra("launch_after_unlock", false) != true) return
        unlocked = false
        if (newPkg.isNotBlank()) lockedPackage = newPkg
        launchAfter = intent?.getBooleanExtra("launch_after_unlock", false) ?: false
        shortcutId = intent?.getStringExtra("launch_shortcut_id").orEmpty()
        if (!prefs.getString("pin_hash", null).isNullOrBlank() && Build.VERSION.SDK_INT >= 28) window.decorView.post { biometric() }
    }

    override fun onDestroy() {
        try { cancelSignal?.cancel() } catch (_: Exception) { }
        super.onDestroy()
    }
    private fun hash(pin: String) = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
