package com.example.omnihub

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Future

/** Unified, local-only search across accessible files and installed apps. */
class GlobalSearchActivity : Activity() {
    private val bg = Color.rgb(242, 240, 247); private val white = Color.rgb(252, 251, 254)
    private val ink = Color.rgb(37, 34, 47); private val muted = Color.rgb(94, 88, 112)
    private val line = Color.rgb(218, 213, 230); private val accent = Color.rgb(102, 80, 196)
    private val worker = Executors.newSingleThreadExecutor(); private val ui = Handler(Looper.getMainLooper())
    private lateinit var query: EditText; private lateinit var results: LinearLayout; private lateinit var status: TextView; private lateinit var filterRow: LinearLayout
    private var filter = "All"; private var requestId = 0; private var searchTask: Future<*>? = null
    private data class Hit(val name:String,val detail:String,val type:String,val file:File?=null,val packageName:String?=null)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState)
        window.statusBarColor=bg; window.navigationBarColor=white
        if(android.os.Build.VERSION.SDK_INT>=23) window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(8),dp(14),dp(8));setBackgroundColor(white)}
        top.addView(button("‹",white){finish()},LinearLayout.LayoutParams(dp(44),dp(44)))
        val title=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        title.addView(text("Global Search",20f,ink,true));title.addView(text("Search files, media and installed apps",11f,muted,false))
        top.addView(title,LinearLayout.LayoutParams(0,-2,1f));root.addView(top);root.addView(View(this).apply{setBackgroundColor(line)},LinearLayout.LayoutParams(-1,dp(1)))
        query=EditText(this).apply{setSingleLine(true);hint="Search by name or app…";textSize=15f;imeOptions=EditorInfo.IME_ACTION_SEARCH;setPadding(dp(14),0,dp(14),0);background=android.graphics.drawable.GradientDrawable().apply{setColor(white);cornerRadius=dp(14).toFloat();setStroke(dp(1),line)};setTextColor(ink);setHintTextColor(muted)}
        val qwrap=LinearLayout(this).apply{setPadding(dp(14),dp(12),dp(14),dp(8));addView(query,LinearLayout.LayoutParams(-1,dp(50)))};root.addView(qwrap)
        val filters=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=false;setPadding(dp(14),0,dp(14),dp(8))}
        filterRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        renderFilters();filters.addView(filterRow);root.addView(filters)
        status=text("Type to search. Results stay on this device.",11f,muted,false).apply{setPadding(dp(16),dp(4),dp(16),dp(8))};root.addView(status)
        val scroll=ScrollView(this).apply{clipToPadding=false;setPadding(dp(14),0,dp(14),dp(18))};results=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(results);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
        query.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){ui.removeCallbacks(pending);ui.postDelayed(pending,220)};override fun afterTextChanged(s:Editable?) {}})
        query.setOnEditorActionListener{_,_,_->refresh();true}
        val initial=intent.getStringExtra("query").orEmpty()
        if(initial.isNotBlank()){query.setText(initial);query.setSelection(query.text.length)} else query.requestFocus()
    }
    private val pending=Runnable{refresh()}
    private fun renderFilters(){filterRow.removeAllViews();listOf("All","Files","Images","Videos","Audio","Documents","Archives","Apps").forEach{f->filterRow.addView(button(f,if(f==filter)accent else white){filter=f;renderFilters();refresh()},LinearLayout.LayoutParams(-2,dp(38)).apply{rightMargin=dp(6)})}}
    private fun refresh(){val q=query.text.toString().trim().lowercase(Locale.ROOT);val id=++requestId;searchTask?.cancel(true)
        if(q.isBlank()){results.removeAllViews();status.text="Type to search. Results stay on this device.";return}
        status.text="Searching locally…";searchTask=worker.submit{
            val found=ArrayList<Hit>();val base=Environment.getExternalStorageDirectory();var visited=0
            try{for(f in base.walkTopDown().onEnter{d->val rel=try{d.relativeTo(base).path.replace('\\','/')}catch(_:Throwable){""};d==base||(d.name!=".omnihub_trash"&&!d.name.startsWith(".")&&!rel.startsWith("Android/data")&&!rel.startsWith("Android/obb")&&d.canRead())}){
                if(Thread.currentThread().isInterrupted)break;visited++;if(visited>60000)break
                if(!f.isFile||!f.name.lowercase(Locale.ROOT).contains(q))continue
                val ext=f.extension.lowercase(Locale.ROOT);val type=when(ext){"jpg","jpeg","png","gif","webp","bmp","heic","heif","avif"->"Images";"mp4","mkv","mov","avi","webm","3gp","mpeg","mpg","ts","wmv","flv","m4v"->"Videos";"mp3","m4a","aac","wav","flac","ogg","opus","wma","amr"->"Audio";"pdf","doc","docx","txt","rtf","odt","xls","xlsx","ppt","pptx","csv","md","epub"->"Documents";"zip","rar","7z","tar","gz","bz2","xz","zst","apk"->"Archives";else->"Files"}
                if(filter=="All"||filter=="Files"||filter==type)found.add(Hit(f.name,"${human(f.length())} · ${f.parentFile?.absolutePath.orEmpty()}",type,file=f))
                if(found.size>=250)break
            }}catch(_:Throwable){}
            if(filter=="All"||filter=="Apps")try{val pm=packageManager;@Suppress("DEPRECATION") val apps=pm.getInstalledApplications(0);for(a in apps){val label=pm.getApplicationLabel(a).toString();if(label.lowercase(Locale.ROOT).contains(q)||a.packageName.lowercase(Locale.ROOT).contains(q))found.add(Hit(label,a.packageName,"Apps",packageName=a.packageName));if(found.size>=300)break}}catch(_:Throwable){}
            val sorted=found.sortedWith(compareBy<Hit>{if(it.type=="Apps")0 else 1}.thenBy{it.name.lowercase(Locale.ROOT)})
            runOnUiThread{if(isFinishing||id!=requestId)return@runOnUiThread;render(sorted,visited>60000)}
        }
    }
    private fun render(hits:List<Hit>,capped:Boolean){results.removeAllViews();status.text="${hits.size} result(s)${if(capped)" · scan limit reached" else ""} · local search"
        if(hits.isEmpty()){card{addView(text("No matching items",16f,ink,true));addView(text("Try another name or category. Some protected Android folders are not searchable.",12f,muted,false))};return}
        hits.forEach{h->card{val row=LinearLayout(this@GlobalSearchActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};val info=LinearLayout(this@GlobalSearchActivity).apply{orientation=LinearLayout.VERTICAL};info.addView(text(h.name,14f,ink,true));info.addView(text("${h.type} · ${h.detail}",10f,muted,false).apply{setPadding(0,dp(4),0,0)});row.addView(info,LinearLayout.LayoutParams(0,-2,1f));row.addView(button("Open",accent){if(h.file!=null)startActivity(Intent(this@GlobalSearchActivity,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra(MainActivity.EXTRA_OPEN_PATH,h.file.absolutePath))else if(h.packageName!=null){try{val i=packageManager.getLaunchIntentForPackage(h.packageName);if(i!=null)startActivity(i)else Toast.makeText(this@GlobalSearchActivity,"This app has no launch activity",Toast.LENGTH_SHORT).show()}catch(_:Throwable){Toast.makeText(this@GlobalSearchActivity,"Could not open app",Toast.LENGTH_SHORT).show()}}},LinearLayout.LayoutParams(dp(68),dp(38)));addView(row)} }
    }
    private fun card(block:LinearLayout.()->Unit){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(12),dp(13),dp(12));background=android.graphics.drawable.GradientDrawable().apply{setColor(white);cornerRadius=dp(15).toFloat();setStroke(dp(1),line)}};c.block();results.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})}
    private fun text(t:String,s:Float,c:Int,b:Boolean)=TextView(this).apply{text=t;textSize=s;setTextColor(c);if(b)typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER_VERTICAL;setLineSpacing(dp(2).toFloat(),1f)}
    private fun button(t:String,color:Int,action:()->Unit)=Button(this).apply{text=t;textSize=11f;isAllCaps=false;setTextColor(if(color==accent)Color.WHITE else ink);backgroundTintList=android.content.res.ColorStateList.valueOf(color);minHeight=dp(36);minimumHeight=dp(36);setPadding(dp(8),0,dp(8),0);setOnClickListener{action()}}
    private fun human(n:Long)=when{n<1024->"$n B";n<1024L*1024->String.format(Locale.ROOT,"%.1f KB",n/1024.0);n<1024L*1024*1024->String.format(Locale.ROOT,"%.1f MB",n/(1024.0*1024));else->String.format(Locale.ROOT,"%.2f GB",n/(1024.0*1024*1024))}
    override fun onDestroy(){ui.removeCallbacks(pending);searchTask?.cancel(true);worker.shutdownNow();super.onDestroy()}
}
