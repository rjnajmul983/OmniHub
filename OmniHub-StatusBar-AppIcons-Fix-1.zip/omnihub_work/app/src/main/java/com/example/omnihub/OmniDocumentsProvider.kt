package com.example.omnihub

import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Point
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsProvider
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileNotFoundException

/**
 * Lets OmniHub show up in the Android system file picker ("Browse files in other apps")
 * next to other file managers, so any app's "Add file / Attach" screen can browse phone storage through OmniHub.
 * Needs "All files access" (already requested by OmniHub) to list shared storage.
 */
class OmniDocumentsProvider : DocumentsProvider() {
    private val rootDir: File get() = Environment.getExternalStorageDirectory()

    companion object {
        private const val ROOT_ID = "omnihub_storage"
        private val ROOT_PROJECTION = arrayOf(Root.COLUMN_ROOT_ID, Root.COLUMN_FLAGS, Root.COLUMN_ICON, Root.COLUMN_TITLE, Root.COLUMN_SUMMARY, Root.COLUMN_DOCUMENT_ID, Root.COLUMN_AVAILABLE_BYTES, Root.COLUMN_MIME_TYPES)
        private val DOC_PROJECTION = arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_MIME_TYPE, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS, Document.COLUMN_SIZE)
    }

    override fun onCreate(): Boolean = true

    override fun queryRoots(projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: ROOT_PROJECTION)
        c.newRow().apply {
            add(Root.COLUMN_ROOT_ID, ROOT_ID)
            add(Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_CREATE or Root.FLAG_SUPPORTS_IS_CHILD or Root.FLAG_SUPPORTS_SEARCH or Root.FLAG_LOCAL_ONLY)
            add(Root.COLUMN_ICON, R.mipmap.ic_launcher)
            add(Root.COLUMN_TITLE, "OmniHub")
            add(Root.COLUMN_SUMMARY, "Phone storage")
            add(Root.COLUMN_DOCUMENT_ID, idFor(rootDir))
            add(Root.COLUMN_AVAILABLE_BYTES, try { rootDir.usableSpace } catch (_: Exception) { 0L })
            add(Root.COLUMN_MIME_TYPES, "*/*")
        }
        return c
    }

    override fun queryDocument(documentId: String, projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: DOC_PROJECTION)
        addRow(c, fileFor(documentId))
        return c
    }

    override fun queryChildDocuments(parentDocumentId: String, projection: Array<out String>?, sortOrder: String?): Cursor {
        val c = MatrixCursor(projection ?: DOC_PROJECTION)
        val parent = fileFor(parentDocumentId)
        parent.listFiles()?.sortedWith(compareByDescending<File> { it.isDirectory }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name })?.forEach { addRow(c, it) }
        return c
    }

    override fun querySearchDocuments(rootId: String, query: String, projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: DOC_PROJECTION)
        val q = query.lowercase()
        var found = 0
        rootDir.walkTopDown().onEnter { it.name != "Android" || it.parentFile != rootDir }.forEach { f ->
            if (found >= 60) return@forEach
            if (f != rootDir && f.name.lowercase().contains(q)) { addRow(c, f); found++ }
        }
        return c
    }

    override fun openDocument(documentId: String, mode: String, signal: CancellationSignal?): ParcelFileDescriptor {
        val f = fileFor(documentId)
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.parseMode(mode))
    }

    override fun openDocumentThumbnail(documentId: String, sizeHint: Point?, signal: CancellationSignal?): AssetFileDescriptor {
        val f = fileFor(documentId)
        val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        return AssetFileDescriptor(pfd, 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    override fun isChildDocument(parentDocumentId: String, documentId: String): Boolean = try {
        val p = fileFor(parentDocumentId).canonicalFile; val d = fileFor(documentId).canonicalFile
        d.path == p.path || d.path.startsWith(p.path + File.separator)
    } catch (_: Exception) { false }

    override fun createDocument(parentDocumentId: String, mimeType: String, displayName: String): String {
        val parent = fileFor(parentDocumentId)
        var target = File(parent, displayName.replace('/', '_'))
        var n = 1
        while (target.exists()) { target = File(parent, nameWithSuffix(displayName.replace('/', '_'), n++)) }
        val ok = if (mimeType == Document.MIME_TYPE_DIR) target.mkdir() else target.createNewFile()
        if (!ok) throw FileNotFoundException("Could not create $displayName")
        return idFor(target)
    }

    override fun deleteDocument(documentId: String) {
        val f = fileFor(documentId)
        if (f == rootDir) throw SecurityException("Cannot delete the storage root")
        if (!f.deleteRecursively()) throw FileNotFoundException("Could not delete ${f.name}")
    }

    override fun renameDocument(documentId: String, displayName: String): String? {
        val f = fileFor(documentId)
        val target = File(f.parentFile, displayName.replace('/', '_'))
        if (target.exists() || !f.renameTo(target)) throw FileNotFoundException("Could not rename ${f.name}")
        return idFor(target)
    }

    override fun getDocumentType(documentId: String): String = mimeFor(fileFor(documentId))

    // ---- helpers
    private fun idFor(f: File) = f.absolutePath

    /** Resolves an id back to a file and refuses anything outside shared storage (no path traversal). */
    private fun fileFor(documentId: String): File {
        val f = File(documentId)
        val root = rootDir.canonicalFile
        val canon = try { f.canonicalFile } catch (_: Exception) { throw FileNotFoundException(documentId) }
        if (canon.path != root.path && !canon.path.startsWith(root.path + File.separator)) throw SecurityException("Outside shared storage")
        if (!canon.exists()) throw FileNotFoundException(documentId)
        return canon
    }

    private fun addRow(c: MatrixCursor, f: File) {
        var flags = 0
        if (f.isDirectory) { if (f.canWrite()) flags = flags or Document.FLAG_DIR_SUPPORTS_CREATE }
        else if (f.canWrite()) flags = flags or Document.FLAG_SUPPORTS_WRITE
        if (f != rootDir && f.canWrite()) flags = flags or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME
        val mime = mimeFor(f)
        if (mime.startsWith("image/") || mime.startsWith("video/")) flags = flags or Document.FLAG_SUPPORTS_THUMBNAIL
        c.newRow().apply {
            add(Document.COLUMN_DOCUMENT_ID, idFor(f))
            add(Document.COLUMN_DISPLAY_NAME, if (f == rootDir) "Phone storage" else f.name)
            add(Document.COLUMN_SIZE, if (f.isFile) f.length() else null)
            add(Document.COLUMN_MIME_TYPE, mime)
            add(Document.COLUMN_LAST_MODIFIED, f.lastModified())
            add(Document.COLUMN_FLAGS, flags)
        }
    }

    private fun mimeFor(f: File): String {
        if (f.isDirectory) return Document.MIME_TYPE_DIR
        val ext = f.extension.lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun nameWithSuffix(name: String, n: Int): String {
        val dot = name.lastIndexOf('.')
        return if (dot > 0) name.substring(0, dot) + " ($n)" + name.substring(dot) else "$name ($n)"
    }
}
