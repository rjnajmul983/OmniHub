import io
import contextlib
import traceback

def execute(source):
    output = io.StringIO()
    scope = {"__name__": "__main__"}
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            exec(compile(source, "<OmniHub Code Studio>", "exec"), scope, scope)
    except BaseException:
        traceback.print_exc(file=output)
    result = output.getvalue()
    return result if result else "Program finished successfully (no output)."
