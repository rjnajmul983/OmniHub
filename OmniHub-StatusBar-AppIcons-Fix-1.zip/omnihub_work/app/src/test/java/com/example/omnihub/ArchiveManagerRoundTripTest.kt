package com.example.omnihub

import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ArchiveManagerRoundTripTest {
    @Test
    fun zipCompressionAndExtractionRoundTripPreservesPayload() {
        val temp = createTempDir(prefix = "omnihub-zip-roundtrip-")
        try {
            val source = File(temp, "roundtrip.txt").apply { writeText("round-trip-payload-✓") }
            val archive = File(temp, "roundtrip.zip")
            val packed = ArchiveManager.compress(listOf(source), archive, "zip")
            assertTrue(packed.completedEntries >= 1)
            assertTrue(ArchiveManager.listEntries(archive).any { it.name == "roundtrip.txt" })
            val output = File(temp, "unpacked")
            val unpacked = ArchiveManager.extract(archive, output)
            assertTrue(unpacked.completedEntries >= 1)
            assertEquals("round-trip-payload-✓", File(output, "roundtrip.txt").readText())
        } finally { temp.deleteRecursively() }
    }

    @Test
    fun sevenZipCompressionAndExtractionRoundTripPreservesPayload() {
        val temp = createTempDir(prefix = "omnihub-7z-roundtrip-")
        try {
            val source = File(temp, "roundtrip.txt").apply { writeText("seven-zip-round-trip-payload") }
            val archive = File(temp, "roundtrip.7z")
            val packed = ArchiveManager.compress(listOf(source), archive, "7z")
            assertTrue(packed.completedEntries >= 1)
            assertTrue(ArchiveManager.listEntries(archive).any { it.name == "roundtrip.txt" })
            val output = File(temp, "unpacked")
            val unpacked = ArchiveManager.extract(archive, output)
            assertTrue(unpacked.completedEntries >= 1)
            assertEquals("seven-zip-round-trip-payload", File(output, "roundtrip.txt").readText())
        } finally { temp.deleteRecursively() }
    }

    @Test(expected = InterruptedException::class)
    fun cancelledExtractionStopsBeforeWritingAnyEntry() {
        val temp = createTempDir(prefix = "omnihub-cancel-")
        try {
            val archive = File(temp, "cancel.zip")
            ZipOutputStream(archive.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("payload.txt")); zip.write("data".toByteArray()); zip.closeEntry()
            }
            val output = File(temp, "cancel-out")
            val token = ArchiveManager.CancelToken().apply { cancel() }
            ArchiveManager.extract(archive, output, cancelToken = token)
        } finally { temp.deleteRecursively() }
    }

    @Test
    fun selectiveZipExtractionWritesOnlySelectedEntry() {
        val temp = createTempDir(prefix = "omnihub-selective-zip-")
        try {
            val archive = File(temp, "selection.zip")
            ZipOutputStream(archive.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("chosen.txt")); zip.write("chosen-data".toByteArray()); zip.closeEntry()
                zip.putNextEntry(ZipEntry("ignored.txt")); zip.write("ignored-data".toByteArray()); zip.closeEntry()
                zip.putNextEntry(ZipEntry("folder/nested.txt")); zip.write("nested-data".toByteArray()); zip.closeEntry()
            }
            val destination = File(temp, "out")
            val result = ArchiveManager.extract(archive, destination, selectedEntryNames = setOf("chosen.txt"))
            assertEquals("chosen-data", File(destination, "chosen.txt").readText())
            assertFalse(File(destination, "ignored.txt").exists())
            assertFalse(File(destination, "folder/nested.txt").exists())
            assertTrue(result.completedEntries >= 1)
        } finally { temp.deleteRecursively() }
    }

    @Test
    fun selectingDirectoryExtractsDescendantsAndParentDirectory() {
        val temp = createTempDir(prefix = "omnihub-selective-dir-")
        try {
            val archive = File(temp, "tree.zip")
            ZipOutputStream(archive.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("docs/")); zip.closeEntry()
                zip.putNextEntry(ZipEntry("docs/readme.txt")); zip.write("inside".toByteArray()); zip.closeEntry()
                zip.putNextEntry(ZipEntry("other.txt")); zip.write("outside".toByteArray()); zip.closeEntry()
            }
            val destination = File(temp, "out")
            ArchiveManager.extract(archive, destination, selectedEntryNames = setOf("docs"))
            assertEquals("inside", File(destination, "docs/readme.txt").readText())
            assertFalse(File(destination, "other.txt").exists())
        } finally { temp.deleteRecursively() }
    }

    @Test
    fun iso9660BrowseAndSelectiveExtractRoundTrip() {
        val temp = createTempDir(prefix = "omnihub-iso-")
        try {
            val iso = File(temp, "sample.iso")
            makeIsoFixture(iso)
            val names = ArchiveManager.listEntries(iso).map { it.name }.toSet()
            assertTrue(names.contains("HELLO.TXT"))
            assertTrue(names.contains("DOCS"))
            assertTrue(names.contains("DOCS/NOTE.TXT"))

            val output = File(temp, "iso-out")
            ArchiveManager.extract(iso, output, selectedEntryNames = setOf("DOCS/NOTE.TXT"))
            assertEquals("note", File(output, "DOCS/NOTE.TXT").readText())
            assertFalse(File(output, "HELLO.TXT").exists())
        } finally { temp.deleteRecursively() }
    }

    @Test
    fun split7zJoinsVolumesAndExtractsSelectedEntry() {
        val temp = createTempDir(prefix = "omnihub-split7z-")
        try {
            val payload = File(temp, "payload.txt").apply { writeText("split-seven-zip-data") }
            val single = File(temp, "single.7z")
            SevenZOutputFile(single).use { seven ->
                val entry = seven.createArchiveEntry(payload, "payload.txt")
                seven.putArchiveEntry(entry)
                payload.inputStream().use { input -> input.copyTo(object : java.io.OutputStream() {
                    override fun write(b: Int) = seven.write(b)
                    override fun write(b: ByteArray, off: Int, len: Int) = seven.write(b, off, len)
                }) }
                seven.closeArchiveEntry()
            }
            val bytes = single.readBytes()
            assertTrue("Fixture 7z must be large enough to split", bytes.size > 4)
            val cut = bytes.size / 2
            File(temp, "multi.7z.001").writeBytes(bytes.copyOfRange(0, cut))
            File(temp, "multi.7z.002").writeBytes(bytes.copyOfRange(cut, bytes.size))

            val entries = ArchiveManager.listEntries(File(temp, "multi.7z.002"))
            assertTrue(entries.any { it.name == "payload.txt" })
            val output = File(temp, "split-out")
            ArchiveManager.extract(File(temp, "multi.7z.002"), output, selectedEntryNames = setOf("payload.txt"))
            assertEquals("split-seven-zip-data", File(output, "payload.txt").readText())
        } finally { temp.deleteRecursively() }
    }

    @Test
    fun zipSlipEntryIsSkippedAndCannotEscapeDestination() {
        val temp = createTempDir(prefix = "omnihub-zipslip-")
        try {
            val archive = File(temp, "zipslip.zip")
            ZipOutputStream(archive.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("../escape.txt")); zip.write("unsafe".toByteArray()); zip.closeEntry()
                zip.putNextEntry(ZipEntry("safe.txt")); zip.write("safe".toByteArray()); zip.closeEntry()
            }
            val output = File(temp, "out")
            val result = ArchiveManager.extract(archive, output)
            assertTrue(result.skippedEntries >= 1)
            assertFalse(File(temp, "escape.txt").exists())
            assertEquals("safe", File(output, "safe.txt").readText())
        } finally { temp.deleteRecursively() }
    }

    @Test
    fun split7zVolumeGapIsRejectedInsteadOfSilentlyJoiningIncompleteData() {
        val temp = createTempDir(prefix = "omnihub-split-gap-")
        try {
            File(temp, "broken.7z.001").writeBytes(byteArrayOf(1, 2, 3))
            File(temp, "broken.7z.003").writeBytes(byteArrayOf(4, 5, 6))
            var caught = false
            try { ArchiveManager.listEntries(File(temp, "broken.7z.001")) }
            catch (e: IOException) { caught = e.message.orEmpty().contains("volume gap") }
            assertTrue("A missing numbered volume must be reported", caught)
        } finally { temp.deleteRecursively() }
    }

    private fun makeIsoFixture(file: File) {
        val sectorSize = 2048
        val rootSector = 20
        val helloSector = 21
        val docsSector = 22
        val noteSector = 23
        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(25L * sectorSize)
            val pvd = ByteArray(sectorSize)
            pvd[0] = 1
            "CD001".toByteArray(StandardCharsets.US_ASCII).copyInto(pvd, 1)
            pvd[6] = 1
            isoRecord(byteArrayOf(0), rootSector, sectorSize, directory = true).copyInto(pvd, 156)
            raf.seek(16L * sectorSize); raf.write(pvd)
            val terminator = ByteArray(sectorSize)
            terminator[0] = 0xFF.toByte()
            "CD001".toByteArray(StandardCharsets.US_ASCII).copyInto(terminator, 1)
            terminator[6] = 1
            raf.seek(17L * sectorSize); raf.write(terminator)

            val root = ByteArray(sectorSize)
            var offset = 0
            for (record in listOf(
                isoRecord(byteArrayOf(0), rootSector, sectorSize, true),
                isoRecord(byteArrayOf(1), rootSector, sectorSize, true),
                isoRecord("HELLO.TXT;1".toByteArray(StandardCharsets.US_ASCII), helloSector, 5, false),
                isoRecord("DOCS".toByteArray(StandardCharsets.US_ASCII), docsSector, sectorSize, true)
            )) { record.copyInto(root, offset); offset += record.size }
            raf.seek(rootSector.toLong() * sectorSize); raf.write(root)

            val docs = ByteArray(sectorSize)
            offset = 0
            for (record in listOf(
                isoRecord(byteArrayOf(0), docsSector, sectorSize, true),
                isoRecord(byteArrayOf(1), rootSector, sectorSize, true),
                isoRecord("NOTE.TXT;1".toByteArray(StandardCharsets.US_ASCII), noteSector, 4, false)
            )) { record.copyInto(docs, offset); offset += record.size }
            raf.seek(docsSector.toLong() * sectorSize); raf.write(docs)
            raf.seek(helloSector.toLong() * sectorSize); raf.write("hello".toByteArray())
            raf.seek(noteSector.toLong() * sectorSize); raf.write("note".toByteArray())
        }
    }

    private fun isoRecord(name: ByteArray, extent: Int, size: Int, directory: Boolean): ByteArray {
        val recordLength = 33 + name.size + if (name.size % 2 == 0) 1 else 0
        val out = ByteArray(recordLength)
        out[0] = recordLength.toByte()
        putBothEndian32(out, 2, extent)
        putBothEndian32(out, 10, size)
        // Recording date: 1 Jan 2020, UTC offset 0.
        out[18] = 120.toByte(); out[19] = 1; out[20] = 1
        out[25] = if (directory) 2 else 0
        out[28] = 1; out[30] = 0; out[31] = 1
        out[32] = name.size.toByte()
        name.copyInto(out, 33)
        return out
    }

    private fun putBothEndian32(dst: ByteArray, offset: Int, value: Int) {
        dst[offset] = value.toByte()
        dst[offset + 1] = (value ushr 8).toByte()
        dst[offset + 2] = (value ushr 16).toByte()
        dst[offset + 3] = (value ushr 24).toByte()
        dst[offset + 4] = (value ushr 24).toByte()
        dst[offset + 5] = (value ushr 16).toByte()
        dst[offset + 6] = (value ushr 8).toByte()
        dst[offset + 7] = value.toByte()
    }
}
