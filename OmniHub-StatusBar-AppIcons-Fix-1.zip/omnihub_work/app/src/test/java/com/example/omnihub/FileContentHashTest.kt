package com.example.omnihub

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class FileContentHashTest {
    @Test fun identicalContentHasIdenticalHashRegardlessOfFilename() {
        val dir = createTempDir(prefix = "omnihub-hash-")
        try {
            val first = File(dir, "first.bin").apply { writeBytes(byteArrayOf(1, 2, 3, 4, 5)) }
            val second = File(dir, "renamed.dat").apply { writeBytes(byteArrayOf(1, 2, 3, 4, 5)) }
            assertEquals(FileContentHash.sha256(first), FileContentHash.sha256(second))
            assertNotNull(FileContentHash.sha256(first))
        } finally { dir.deleteRecursively() }
    }

    @Test fun sameLengthDifferentContentHasDifferentHash() {
        val dir = createTempDir(prefix = "omnihub-hash-")
        try {
            val first = File(dir, "first.bin").apply { writeBytes(byteArrayOf(1, 2, 3, 4)) }
            val second = File(dir, "second.bin").apply { writeBytes(byteArrayOf(4, 3, 2, 1)) }
            assertNotEquals(FileContentHash.sha256(first), FileContentHash.sha256(second))
        } finally { dir.deleteRecursively() }
    }

    @Test fun unreadableOrMissingFileReturnsNull() {
        val missing = File(createTempDir(prefix = "omnihub-hash-"), "missing.bin")
        assertEquals(null, FileContentHash.sha256(missing))
        missing.parentFile?.deleteRecursively()
    }
}
