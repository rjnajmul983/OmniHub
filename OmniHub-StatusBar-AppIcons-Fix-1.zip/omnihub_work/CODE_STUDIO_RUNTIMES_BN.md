# Code Studio Runtime Update

- Python: bundled CPython 3.11 via Chaquopy; executes locally on-device using `app/src/main/python/code_runner.py`.
- SQL: Android's built-in SQLite engine; each run uses an in-memory database, so tables/data reset between runs. Multiple semicolon-separated statements are supported; SELECT/PRAGMA/WITH/EXPLAIN output is shown.
- Kotlin: uses Piston online compiler (`https://emkc.org/api/v2/piston/execute`). The UI prompts before sending source code. Internet is required; do not submit secrets/private code. This is not an offline Kotlin runtime.
- HTML/JavaScript/CSS/Markdown/JSON/XML/TXT/CSV keep their existing preview behavior.

Build note: `./gradlew :app:assembleDebug` could not be verified in this environment because the Gradle distribution host was unreachable. AndroidIDE must download Gradle and the Chaquopy plugin/dependencies during the first online build.
